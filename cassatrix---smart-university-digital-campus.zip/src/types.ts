// Strictly 4 roles as specified: Student, Faculty, Parent, Administrator & Leadership
export type UserRole = 'student' | 'faculty' | 'parent' | 'admin';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  roleTitle: string;
  department: string;
  avatar?: string;
  enrollmentId?: string;
  phone?: string;
  semester?: number;
  batch?: string;
  roomNo?: string;
  wardId?: string; // for parent
}

export interface AttendanceRecord {
  id: string;
  subjectCode: string;
  subjectName: string;
  facultyName: string;
  totalClasses: number;
  attendedClasses: number;
  percentage: number;
  status: 'Good' | 'Warning' | 'Critical';
  lastUpdated: string;
}

export interface TimetableEntry {
  id: string;
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday';
  time: string;
  subject: string;
  code: string;
  faculty: string;
  room: string;
  type: 'Lecture' | 'Lab' | 'Tutorial';
  conflictDetected?: boolean;
}

export interface DigitalCertificate {
  id: string;
  title: string;
  issuedTo: string;
  enrollmentNo: string;
  issueDate: string;
  type: 'Degree' | 'Semester Grade Report' | 'Bonafide Certificate' | 'Merit Award';
  verificationHash: string;
  issuerAuthority: string;
  status: 'Verified' | 'Revoked';
  cgpa?: number;
  digiLockerSynced?: boolean;
}

export interface FeeItem {
  id: string;
  title: string;
  semester: string;
  amount: number;
  dueDate: string;
  status: 'Paid' | 'Pending' | 'Overdue';
  receiptNo?: string;
  paidDate?: string;
  category: 'Tuition' | 'Hostel & Mess' | 'Examination' | 'Library & Lab';
  digitalSignature?: string;
}

export interface GrievanceTicket {
  id: string;
  subject: string;
  category: 'Academic' | 'Hostel' | 'Ragging' | 'Mess' | 'Infrastructure';
  submittedBy: string;
  submittedByRole?: string;
  date: string;
  status: 'Open' | 'In Progress' | 'Escalated' | 'Resolved';
  priority: 'Urgent' | 'High' | 'Medium' | 'Low';
  description: string;
  slaHoursRemaining: number;
  escalationTier: 'Tier 1 - Dept Head' | 'Tier 2 - Dean Academic' | 'Tier 3 - Registrar Executive';
  resolutionRemarks?: string;
}

export interface HostelLeaveRequest {
  id: string;
  studentName: string;
  enrollmentNo: string;
  roomNo: string;
  hostelBlock: string;
  purpose: string;
  destination: string;
  fromDate: string;
  toDate: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  parentConsent: boolean;
  autoApproved?: boolean;
}

export interface BusRoute {
  id: string;
  routeNumber: string;
  routeName: string;
  driverName: string;
  driverContact: string;
  busNumber: string;
  currentStop: string;
  nextStop: string;
  etaMinutes: number;
  totalSeats: number;
  occupiedSeats: number;
  status: 'On Route' | 'At Terminal' | 'Delayed';
  stops: string[];
  currentGps: { lat: number; lng: number };
}

export interface StudentRiskProfile {
  studentId: string;
  name: string;
  enrollmentNo: string;
  branch: string;
  semester: number;
  attendanceRate: number;
  currentCgpa: number;
  predictedGpa: number;
  dropoutRiskLevel: 'Low' | 'Moderate' | 'High';
  dropoutRiskScore: number; // 0-100
  keyRiskFactors: string[];
  recommendedAction: string;
  feeDefaulter: boolean;
  internalTestScores: { subject: string; score: number; maxScore: number }[];
  counselingScheduled?: boolean;
}

export interface LearningRecommendation {
  id: string;
  topic: string;
  subject: string;
  reason: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  estimatedHours: number;
  resourceType: 'Video Lecture' | 'Practice Problems' | 'Interactive Lab' | 'Reference Notes';
  linkTitle: string;
}

export interface CourseOffering {
  code: string;
  title: string;
  credits: number;
  faculty: string;
  slot: string;
  department: string;
  enrolled: boolean;
  syllabusUrl?: string;
}

export interface ExamRegistration {
  examId: string;
  title: string;
  session: string;
  status: 'Registered' | 'Pending Fee' | 'Hall Ticket Ready';
  center: string;
  hallTicketNo: string;
  admitCardHash: string;
}

export interface RbacRoleConfig {
  roleId: string;
  roleTitle: string;
  targetGroup: string;
  canViewLedgers: boolean;
  canOverrideAttendance: boolean;
  canSignDegrees: boolean;
  canManageBuses: boolean;
  canResolveEscalations: boolean;
  activeUsersCount: number;
}
