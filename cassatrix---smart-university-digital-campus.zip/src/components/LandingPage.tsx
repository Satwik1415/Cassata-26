import React, { useState, useEffect } from 'react';
import { UserRole } from '../types';
import {
  GraduationCap,
  Briefcase,
  Users,
  ShieldCheck,
  MapPin,
  FileCheck2,
  Clock,
  Sparkles,
  ArrowRight,
  ArrowUpRight,
  Shield,
  CreditCard,
  Building2,
  Bus,
  CheckCircle2,
  Lock,
  Smartphone,
  Eye,
  Activity,
  Layers,
  Radio,
} from 'lucide-react';

interface LandingPageProps {
  onOpenRoleLogin: (role?: UserRole) => void;
  onExploreModule: (module: string) => void;
  onOpenVoiceAssistant: () => void;
  onOpenAskSarthi: () => void; // Icecream AI assistant trigger
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onOpenRoleLogin,
  onExploreModule,
  onOpenVoiceAssistant,
  onOpenAskSarthi,
}) => {
  // Interactive preview state for role prototype selector
  const [activeRolePreview, setActiveRolePreview] = useState<UserRole>('student');

  // Parallax and scroll reveal setup
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-in');
          }
        });
      },
      { threshold: 0.12 }
    );

    document.querySelectorAll('[data-reveal]').forEach((el) => observer.observe(el));

    return () => {
      observer.disconnect();
    };
  }, []);

  return (
    <div className="relative min-h-screen bg-[#FBFAF7] text-[#12281A] selection:bg-[#42A85D] selection:text-white">
      {/* ============ HERO SECTION ============ */}
      <header className="relative min-h-[92vh] overflow-hidden flex flex-col justify-end">
        {/* Cinematic Backdrop with Measured Scrim */}
        <div className="absolute inset-0 z-0">
          <img
            src="/src/assets/images/hero_smart_campus_architecture_1790955608715.jpg"
            alt="Cassatrix Smart University Architecture"
            className="w-full h-full object-cover scale-105 opacity-85 transition-transform duration-1000 ease-out"
          />
          {/* Readability scrims tailored for high legibility */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#FBFAF7] via-[#FBFAF7]/75 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-[#FBFAF7]/90 via-[#FBFAF7]/40 to-transparent"></div>
        </div>

        {/* Floating Translucent Organic Glass Forms inspired by Substance Lab */}
        <div className="absolute inset-0 pointer-events-none z-1 overflow-hidden">
          <div className="drift-a absolute top-[14%] left-[6%] w-48 h-48 sm:w-72 sm:h-72 rounded-full bg-gradient-to-br from-white/30 to-white/10 backdrop-blur-md border border-white/30 shadow-[inset_0_0_60px_rgba(255,255,255,0.3)]"></div>
          <div className="drift-b absolute top-[26%] right-[8%] w-32 h-32 sm:w-56 sm:h-56 rounded-[40%] bg-gradient-to-tl from-[#42A85D]/20 to-white/15 backdrop-blur-md border border-white/25 shadow-[inset_0_0_40px_rgba(66,168,93,0.25)]"></div>
          <div className="drift-c absolute top-[52%] left-[42%] w-24 h-24 sm:w-36 sm:h-36 rounded-full bg-gradient-to-b from-white/25 to-transparent backdrop-blur-xs border border-white/20"></div>
        </div>

        {/* Manifesto Content */}
        <div className="relative z-10 max-w-7xl mx-auto w-full px-6 sm:px-10 pb-16 sm:pb-24 pt-32">
          <div className="max-w-3xl" data-reveal>
            <div className="flex items-center gap-2 mb-6 text-xs uppercase tracking-[0.25em] text-[#1E4D33] font-semibold">
              <span className="w-2 h-2 rounded-full bg-[#42A85D] animate-ping"></span>
              <span>Event-Driven Digital Campus Infrastructure</span>
              <span aria-hidden="true">·</span>
              <span>Cassatrix 2026</span>
            </div>

            <h1 className="font-display text-5xl sm:text-7xl lg:text-8xl leading-[0.96] text-[#12281A] font-light tracking-tighter">
              Campus operations built with precision, speed and{' '}
              <em className="font-serif-accent italic font-normal text-[#1E4D33]">
                governance.
              </em>
            </h1>

            <p className="mt-8 text-base sm:text-lg text-[#12281A]/70 max-w-2xl leading-relaxed">
              Cassatrix consolidates academic lifecycles, geofenced 6-digit OTP lecture attendance, automated hostel out-passes, and predictive ML dropout prevention into a single unified window for students, faculty, parents, and executive administration.
            </p>

            <div className="mt-10 flex flex-wrap items-center gap-4 sm:gap-6">
              <button
                onClick={() => onOpenRoleLogin('student')}
                className="group inline-flex items-center gap-2.5 bg-[#1E4D33] hover:bg-[#2A6647] active:scale-95 text-white font-medium text-sm sm:text-base px-7 py-3.5 rounded-full transition-all duration-300 shadow-xl shadow-[#1E4D33]/25 hover:shadow-2xl hover:shadow-[#1E4D33]/35 cursor-pointer"
              >
                <span>Launch Student Portal</span>
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </button>

              <a
                href="#roles-capabilities"
                className="inline-flex items-center gap-1.5 text-sm font-medium text-[#12281A]/70 hover:text-[#12281A] transition-colors border-b border-[#12281A]/20 hover:border-[#12281A] pb-0.5 cursor-pointer"
              >
                <span>Explore the 4 Portals</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-[#42A85D]" />
              </a>

              <button
                onClick={onOpenVoiceAssistant}
                className="inline-flex items-center gap-2 px-5 py-3.5 text-xs font-semibold text-[#1E4D33] bg-[#E4EFDA] hover:bg-[#d8e7cb] rounded-full border border-[#42A85D]/30 transition-all shadow-sm cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-[#42A85D]" />
                <span>Voice Icecream AI</span>
              </button>
            </div>
          </div>
        </div>

        {/* Giant Cropped Wordmark in Background */}
        <div className="absolute -bottom-[2vw] left-1/2 -translate-x-1/2 w-full z-2 pointer-events-none overflow-hidden select-none opacity-40">
          <p
            className="font-display text-[19vw] leading-none text-center text-[#1E4D33]/10 whitespace-nowrap font-light tracking-tighter"
            style={{ WebkitTextStroke: '1px rgba(30, 77, 51, 0.15)' }}
          >
            CASSATRIX
          </p>
        </div>
      </header>

      {/* Subtle Animated Divider 1 */}
      <div className="subtle-animated-divider" />

      {/* ============ LIVE EVENT-DRIVEN TELEMETRY STREAM ============ */}
      <section className="relative z-10 bg-[#FBFAF7]/95 backdrop-blur-sm py-4">
        <div className="max-w-7xl mx-auto px-6 sm:px-10 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2.5 text-[#1E4D33] font-semibold whitespace-nowrap shrink-0">
            <span className="w-2 h-2 rounded-full bg-[#42A85D] animate-pulse"></span>
            <span>Real-Time Campus Telemetry:</span>
          </div>

          <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-[#12281A]/70 overflow-x-auto">
            <div className="flex items-center gap-1.5 whitespace-nowrap">
              <span className="text-[#42A85D] font-mono">11:32 AM</span>
              <span>· Smart Hall 301: 34 students geofence-verified (CS601)</span>
            </div>
            <div className="flex items-center gap-1.5 whitespace-nowrap">
              <span className="text-[#42A85D] font-mono">11:30 AM</span>
              <span>· Hostel H-3: Out-pass #142 auto-approved via guardian OTP</span>
            </div>
            <div className="flex items-center gap-1.5 whitespace-nowrap">
              <span className="text-[#42A85D] font-mono">11:28 AM</span>
              <span>· Bus #04: Board Office Square ETA 12 mins (38/52 seats occupied)</span>
            </div>
            <div className="flex items-center gap-1.5 whitespace-nowrap">
              <span className="text-[#42A85D] font-mono">11:25 AM</span>
              <span>· Treasury: ₹54,000 fee settled via UPI (SHA-256 signed invoice)</span>
            </div>
          </div>
        </div>
      </section>

      {/* Subtle Animated Divider 2 */}
      <div className="subtle-animated-divider" />

      {/* ============ ROLE CAPABILITIES & PROTOTYPES ============ */}
      <section id="roles-capabilities" className="relative pt-20 sm:pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 sm:px-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-14" data-reveal>
            <div>
              <p className="text-xs uppercase tracking-[0.25em] text-[#1E4D33] font-semibold mb-3">
                Architectural Breakdown
              </p>
              <h2 className="font-display text-4xl sm:text-6xl font-light tracking-tighter">
                The four unified{' '}
                <em className="font-serif-accent italic font-normal text-[#1E4D33]">
                  institutional portals.
                </em>
              </h2>
            </div>
            <div className="mt-4 md:mt-0 text-sm text-[#12281A]/50">
              Role-based access · Zero proxy tolerance · Event-driven
            </div>
          </div>

          {/* Interactive Role Switcher Tabs */}
          <div className="flex items-center gap-2 p-1.5 bg-[#E4EFDA]/60 rounded-full max-w-2xl mb-12 border border-black/5" data-reveal>
            <button
              onClick={() => setActiveRolePreview('student')}
              className={`flex-1 py-2.5 px-4 rounded-full text-xs font-semibold transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer ${
                activeRolePreview === 'student'
                  ? 'bg-white text-[#12281A] shadow-md shadow-black/5'
                  : 'text-[#12281A]/60 hover:text-[#12281A]'
              }`}
            >
              <GraduationCap className="w-4 h-4 text-[#42A85D]" />
              <span>1. Student</span>
            </button>
            <button
              onClick={() => setActiveRolePreview('faculty')}
              className={`flex-1 py-2.5 px-4 rounded-full text-xs font-semibold transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer ${
                activeRolePreview === 'faculty'
                  ? 'bg-white text-[#12281A] shadow-md shadow-black/5'
                  : 'text-[#12281A]/60 hover:text-[#12281A]'
              }`}
            >
              <Briefcase className="w-4 h-4 text-[#42A85D]" />
              <span>2. Faculty</span>
            </button>
            <button
              onClick={() => setActiveRolePreview('parent')}
              className={`flex-1 py-2.5 px-4 rounded-full text-xs font-semibold transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer ${
                activeRolePreview === 'parent'
                  ? 'bg-white text-[#12281A] shadow-md shadow-black/5'
                  : 'text-[#12281A]/60 hover:text-[#12281A]'
              }`}
            >
              <Users className="w-4 h-4 text-[#42A85D]" />
              <span>3. Parent</span>
            </button>
            <button
              onClick={() => setActiveRolePreview('admin')}
              className={`flex-1 py-2.5 px-4 rounded-full text-xs font-semibold transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer ${
                activeRolePreview === 'admin'
                  ? 'bg-white text-[#12281A] shadow-md shadow-black/5'
                  : 'text-[#12281A]/60 hover:text-[#12281A]'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-[#42A85D]" />
              <span>4. Leadership</span>
            </button>
          </div>

          {/* DYNAMIC ROLE PROTOTYPE VIEWER */}
          {activeRolePreview === 'student' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fade-in">
              <div className="lg:col-span-6 space-y-6">
                <div>
                  <div className="text-xs uppercase tracking-widest text-[#42A85D] font-semibold mb-2">
                    Role 01 · Scholar Experience
                  </div>
                  <h3 className="font-display text-3xl sm:text-4xl font-light tracking-tight text-[#12281A]">
                    Student Academic Lifecycle & Geofenced OTP
                  </h3>
                  <p className="mt-3 text-base text-[#12281A]/70 leading-relaxed">
                    Complete online semester enrollment, course selection, and exam registration in a single interface. Mark lecture attendance securely using instructor-projected 6-digit OTPs verified within the 50-meter classroom geofence.
                  </p>
                </div>

                <div className="space-y-3 pt-2">
                  <div className="p-4 rounded-2xl bg-white border border-black/10 flex items-start gap-3.5 shadow-2xs">
                    <Radio className="w-5 h-5 text-[#1E4D33] shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-semibold text-[#12281A]">Zero-Proxy Geofenced OTP Check-In</h4>
                      <p className="text-xs text-[#12281A]/60 mt-0.5">
                        Dual verification: Enter the rotating 6-digit lecture OTP while high-precision GPS confirms presence within the 50m classroom boundary.
                      </p>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-white border border-black/10 flex items-start gap-3.5 shadow-2xs">
                    <CreditCard className="w-5 h-5 text-[#1E4D33] shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-semibold text-[#12281A]">Financial Ledger & Instant Invoices</h4>
                      <p className="text-xs text-[#12281A]/60 mt-0.5">
                        Pay tuition, hostel, and library dues via integrated UPI / NetBanking with auto-generated SHA-256 signed tax receipts.
                      </p>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-white border border-black/10 flex items-start gap-3.5 shadow-2xs">
                    <FileCheck2 className="w-5 h-5 text-[#1E4D33] shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-semibold text-[#12281A]">Tamper-Proof Document Vault</h4>
                      <p className="text-xs text-[#12281A]/60 mt-0.5">
                        Verifiable degrees, semester transcripts, and bonafide certificates synced to National DigiLocker repository.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="pt-2 flex items-center gap-4">
                  <button
                    onClick={() => onOpenRoleLogin('student')}
                    className="inline-flex items-center gap-2 bg-[#1E4D33] hover:bg-[#2A6647] text-white px-6 py-3 rounded-full text-xs font-semibold transition-all shadow-md cursor-pointer"
                  >
                    <span>Sign In to Student Portal</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={onOpenVoiceAssistant}
                    className="inline-flex items-center gap-1.5 text-xs font-medium text-[#1E4D33] hover:underline cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-[#42A85D]" />
                    <span>Try Voice Icecream AI</span>
                  </button>
                </div>
              </div>

              {/* Informative Scholar Architecture Card */}
              <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-xl shadow-black/5 space-y-5">
                <div className="flex items-center justify-between border-b border-black/10 pb-4">
                  <div>
                    <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Module Architecture</span>
                    <h4 className="font-display font-semibold text-lg text-[#12281A]">
                      Unified Scholar Lifecycle Pipeline
                    </h4>
                  </div>
                  <span className="text-[11px] font-bold text-[#1E4D33] bg-[#E4EFDA] px-2.5 py-1 rounded-full flex items-center gap-1">
                    <Shield className="w-3 h-3 text-[#42A85D]" /> ISO/IEC 27001 Protected
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="p-3.5 rounded-2xl bg-[#FBFAF7] border border-black/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-[#1E4D33] text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      01
                    </span>
                    <div>
                      <div className="font-bold text-[#12281A]">Smart Course Registration & Electives</div>
                      <div className="text-slate-600 mt-0.5 leading-relaxed">
                        Automatic prerequisite validation and real-time lab batch capacity allocation preventing schedule clashes.
                      </div>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-[#FBFAF7] border border-black/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-[#1E4D33] text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      02
                    </span>
                    <div>
                      <div className="font-bold text-[#12281A]">Dual-Factor OTP & 50m Geofence Attendance</div>
                      <div className="text-slate-600 mt-0.5 leading-relaxed">
                        Eliminates proxy check-ins by verifying professor's rotating 6-digit OTP combined with classroom GPS radius telemetry.
                      </div>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-[#FBFAF7] border border-black/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-[#1E4D33] text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      03
                    </span>
                    <div>
                      <div className="font-bold text-[#12281A]">Digital Invoicing & Instant UPI Clearance</div>
                      <div className="text-slate-600 mt-0.5 leading-relaxed">
                        Instant semester fee reconciliation, automated scholarships deduction, and SHA-256 cryptographically stamped receipts.
                      </div>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-[#FBFAF7] border border-black/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-[#1E4D33] text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      04
                    </span>
                    <div>
                      <div className="font-bold text-[#12281A]">National DigiLocker Verified Credentials</div>
                      <div className="text-slate-600 mt-0.5 leading-relaxed">
                        Tamper-proof digital degrees, mark sheets, and bonafide outpasses with instant QR scan authenticity verification.
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-black/10 flex items-center justify-between">
                  <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-amber-600" />
                    <span>Personal marks & attendance require student sign-in</span>
                  </div>
                  <button
                    onClick={() => onOpenRoleLogin('student')}
                    className="px-4 py-2 bg-[#1E4D33] hover:bg-[#2A6647] text-white font-bold text-xs rounded-xl transition-colors cursor-pointer"
                  >
                    Launch Student Portal
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* FACULTY PREVIEW */}
          {activeRolePreview === 'faculty' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fade-in">
              <div className="lg:col-span-6 space-y-6">
                <div>
                  <div className="text-xs uppercase tracking-widest text-[#42A85D] font-semibold mb-2">
                    Role 02 · Academic Instruction
                  </div>
                  <h3 className="font-display text-3xl sm:text-4xl font-light tracking-tight text-[#12281A]">
                    Faculty & Proctor Early Intervention Cockpit
                  </h3>
                  <p className="mt-3 text-base text-[#12281A]/70 leading-relaxed">
                    Activate live classroom presence beacons for lectures, manually resolve attendance anomalies with audit logs, and record continuous assessment marks directly to the centralized ledger.
                  </p>
                </div>

                <div className="space-y-3 pt-2">
                  <div className="p-4 rounded-2xl bg-white border border-black/10 flex items-start gap-3.5 shadow-2xs">
                    <Clock className="w-5 h-5 text-[#1E4D33] shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-semibold text-[#12281A]">Classroom & Timetable Operations</h4>
                      <p className="text-xs text-[#12281A]/60 mt-0.5">
                        Automated presence beacon broadcast to lecture hall turnstiles. Automated alerts detect lab/hall collisions before schedule publication.
                      </p>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-white border border-black/10 flex items-start gap-3.5 shadow-2xs">
                    <Sparkles className="w-5 h-5 text-[#1E4D33] shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-semibold text-[#12281A]">Early Dropout Intervention Dashboard</h4>
                      <p className="text-xs text-[#12281A]/60 mt-0.5">
                        Machine learning model flags students dipping below 75% attendance or declining on quizzes. Schedule priority counseling with 1-click.
                      </p>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-white border border-black/10 flex items-start gap-3.5 shadow-2xs">
                    <Shield className="w-5 h-5 text-[#1E4D33] shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-semibold text-[#12281A]">SLA Grievance Redressal Queue</h4>
                      <p className="text-xs text-[#12281A]/60 mt-0.5">
                        Resolve departmental re-evaluation and lab maintenance requests within 24- to 48-hour enforced SLAs before automatic Dean escalation.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => onOpenRoleLogin('faculty')}
                    className="inline-flex items-center gap-2 bg-[#1E4D33] hover:bg-[#2A6647] text-white px-6 py-3 rounded-full text-xs font-semibold transition-all shadow-md cursor-pointer"
                  >
                    <span>Sign In to Faculty Portal</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Informative Faculty Architecture Card */}
              <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-xl shadow-black/5 space-y-5">
                <div className="flex items-center justify-between border-b border-black/10 pb-4">
                  <div>
                    <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Instructional Tools</span>
                    <h4 className="font-display font-semibold text-lg text-[#12281A]">
                      Faculty Cockpit & Grading Architecture
                    </h4>
                  </div>
                  <span className="text-[11px] font-bold text-[#1E4D33] bg-[#E4EFDA] px-2.5 py-1 rounded-full flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-[#42A85D]" /> Active Session Controller
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="p-3.5 rounded-2xl bg-[#FBFAF7] border border-black/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-[#1E4D33] text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      01
                    </span>
                    <div>
                      <div className="font-bold text-[#12281A]">Dynamic 6-Digit Lecture OTP Generation</div>
                      <div className="text-slate-600 mt-0.5 leading-relaxed">
                        Instructors broadcast time-limited, rotating 6-digit check-in codes with automated countdown timers and classroom geofence lock.
                      </div>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-[#FBFAF7] border border-black/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-[#1E4D33] text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      02
                    </span>
                    <div>
                      <div className="font-bold text-[#12281A]">Continuous Internal Evaluation Ledger</div>
                      <div className="text-slate-600 mt-0.5 leading-relaxed">
                        Direct spreadsheet-like recording for MST1, MST2, lab practicals, and assignment marks syncing directly to university databases.
                      </div>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-[#FBFAF7] border border-black/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-[#1E4D33] text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      03
                    </span>
                    <div>
                      <div className="font-bold text-[#12281A]">Predictive Dropout Risk Flagging (&lt;75% Attendance)</div>
                      <div className="text-slate-600 mt-0.5 leading-relaxed">
                        Machine learning pipeline proactively alerts proctors to schedule counseling interventions before students face examination debarment.
                      </div>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-[#FBFAF7] border border-black/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-[#1E4D33] text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      04
                    </span>
                    <div>
                      <div className="font-bold text-[#12281A]">24-48h Enforced Grievance SLA Queue</div>
                      <div className="text-slate-600 mt-0.5 leading-relaxed">
                        Departmental redressal workflows with audit trails for mark re-evaluation, lab adjustments, and student inquiries.
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-black/10 flex items-center justify-between">
                  <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-amber-600" />
                    <span>Faculty authentication required for OTP broadcast & grading</span>
                  </div>
                  <button
                    onClick={() => onOpenRoleLogin('faculty')}
                    className="px-4 py-2 bg-[#1E4D33] hover:bg-[#2A6647] text-white font-bold text-xs rounded-xl transition-colors cursor-pointer"
                  >
                    Launch Faculty Portal
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* PARENT PREVIEW */}
          {activeRolePreview === 'parent' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fade-in">
              <div className="lg:col-span-6 space-y-6">
                <div>
                  <div className="text-xs uppercase tracking-widest text-[#42A85D] font-semibold mb-2">
                    Role 03 · Guardian Transparency
                  </div>
                  <h3 className="font-display text-3xl sm:text-4xl font-light tracking-tight text-[#12281A]">
                    Parent Portal: Direct Billing & Academic Oversight
                  </h3>
                  <p className="mt-3 text-base text-[#12281A]/70 leading-relaxed">
                    Access real-time daily lecture attendance feeds, internal test cards, and verified institutional circulars directly from the university council. Clear pending fees with instant receipt generation.
                  </p>
                </div>

                <div className="space-y-3 pt-2">
                  <div className="p-4 rounded-2xl bg-white border border-black/10 flex items-start gap-3.5 shadow-2xs">
                    <Activity className="w-5 h-5 text-[#1E4D33] shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-semibold text-[#12281A]">Daily Attendance & Test Score Feeds</h4>
                      <p className="text-xs text-[#12281A]/60 mt-0.5">
                        Live updates whenever your ward enters or misses a lecture. Automatic risk alerts trigger if absences exceed 3 consecutive sessions.
                      </p>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-white border border-black/10 flex items-start gap-3.5 shadow-2xs">
                    <CreditCard className="w-5 h-5 text-[#1E4D33] shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-semibold text-[#12281A]">Direct Ward Fee Settlement</h4>
                      <p className="text-xs text-[#12281A]/60 mt-0.5">
                        View itemized semester tuition and hostel boarding fees. Pay via UPI, Cards, or NetBanking directly on behalf of the scholar.
                      </p>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-white border border-black/10 flex items-start gap-3.5 shadow-2xs">
                    <Shield className="w-5 h-5 text-[#1E4D33] shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-semibold text-[#12281A]">Verified Institutional Circulars</h4>
                      <p className="text-xs text-[#12281A]/60 mt-0.5">
                        Official examination notifications, convocation schedules, and holiday directives with registrar digital signatures.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => onOpenRoleLogin('parent')}
                    className="inline-flex items-center gap-2 bg-[#1E4D33] hover:bg-[#2A6647] text-white px-6 py-3 rounded-full text-xs font-semibold transition-all shadow-md cursor-pointer"
                  >
                    <span>Sign In to Parent Portal</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Informative Parent Architecture Card */}
              <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-xl shadow-black/5 space-y-5">
                <div className="flex items-center justify-between border-b border-black/10 pb-4">
                  <div>
                    <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Guardian Telemetry</span>
                    <h4 className="font-display font-semibold text-lg text-[#12281A]">
                      Parent Transparency & Oversight Framework
                    </h4>
                  </div>
                  <span className="text-[11px] font-bold text-[#1E4D33] bg-[#E4EFDA] px-2.5 py-1 rounded-full flex items-center gap-1">
                    <Users className="w-3 h-3 text-[#42A85D]" /> 24/7 Verified Gateway
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="p-3.5 rounded-2xl bg-[#FBFAF7] border border-black/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-[#1E4D33] text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      01
                    </span>
                    <div>
                      <div className="font-bold text-[#12281A]">Live Lecture Attendance Streams</div>
                      <div className="text-slate-600 mt-0.5 leading-relaxed">
                        Instant notification feeds when your ward checks into classroom sessions via geofenced OTP, maintaining 100% transparency.
                      </div>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-[#FBFAF7] border border-black/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-[#1E4D33] text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      02
                    </span>
                    <div>
                      <div className="font-bold text-[#12281A]">Continuous Assessment & Report Cards</div>
                      <div className="text-slate-600 mt-0.5 leading-relaxed">
                        Access mid-term evaluations, quiz percentiles, and semester SGPA cards directly verified from the academic council.
                      </div>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-[#FBFAF7] border border-black/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-[#1E4D33] text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      03
                    </span>
                    <div>
                      <div className="font-bold text-[#12281A]">Direct Fee Settlement & Tax Invoices</div>
                      <div className="text-slate-600 mt-0.5 leading-relaxed">
                        Conveniently pay semester tuition, examination, and hostel boarding dues on behalf of your ward with instant 80G/educational receipts.
                      </div>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-[#FBFAF7] border border-black/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-[#1E4D33] text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      04
                    </span>
                    <div>
                      <div className="font-bold text-[#12281A]">Automated Hostel Leave & Outpass Consent</div>
                      <div className="text-slate-600 mt-0.5 leading-relaxed">
                        1-tap SMS / email guardian verification for weekend outpasses, inter-college hackathons, and emergency campus departures.
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-black/10 flex items-center justify-between">
                  <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-amber-600" />
                    <span>Parent authentication required to monitor ward records</span>
                  </div>
                  <button
                    onClick={() => onOpenRoleLogin('parent')}
                    className="px-4 py-2 bg-[#1E4D33] hover:bg-[#2A6647] text-white font-bold text-xs rounded-xl transition-colors cursor-pointer"
                  >
                    Launch Parent Portal
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* LEADERSHIP PREVIEW */}
          {activeRolePreview === 'admin' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fade-in">
              <div className="lg:col-span-6 space-y-6">
                <div>
                  <div className="text-xs uppercase tracking-widest text-[#42A85D] font-semibold mb-2">
                    Role 04 · Governance & Executive Control
                  </div>
                  <h3 className="font-display text-3xl sm:text-4xl font-light tracking-tight text-[#12281A]">
                    Administrator & Leadership Governance Hub
                  </h3>
                  <p className="mt-3 text-base text-[#12281A]/70 leading-relaxed">
                    Institutional governance analytics covering ₹42.8 Cr in fee reconciliations, role-based access control (RBAC), cryptographic batch certificate issuance, 48-hour SLA grievance escalation tracking, and campus infrastructure oversight.
                  </p>
                </div>

                <div className="space-y-3 pt-2">
                  <div className="p-4 rounded-2xl bg-white border border-black/10 flex items-start gap-3.5 shadow-2xs">
                    <Layers className="w-5 h-5 text-[#1E4D33] shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-semibold text-[#12281A]">Institutional Governance & SLA Analytics</h4>
                      <p className="text-xs text-[#12281A]/60 mt-0.5">
                        Real-time university KPI cockpits with 97.2% SLA compliance, average resolution of 31.4 hours, and departmental breakdown.
                      </p>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-white border border-black/10 flex items-start gap-3.5 shadow-2xs">
                    <Lock className="w-5 h-5 text-[#1E4D33] shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-semibold text-[#12281A]">RBAC & Security Layers</h4>
                      <p className="text-xs text-[#12281A]/60 mt-0.5">
                        Manage permissions across scholars, faculty, wardens, and transit dispatchers via JWT / OAuth2 token governance.
                      </p>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-white border border-black/10 flex items-start gap-3.5 shadow-2xs">
                    <Building2 className="w-5 h-5 text-[#1E4D33] shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-semibold text-[#12281A]">Infrastructure & Transit Optimization</h4>
                      <p className="text-xs text-[#12281A]/60 mt-0.5">
                        Hostel room allocations, food hygiene audits across 4 mess blocks, and 18-vehicle GPS fleet route optimization.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => onOpenRoleLogin('admin')}
                    className="inline-flex items-center gap-2 bg-[#1E4D33] hover:bg-[#2A6647] text-white px-6 py-3 rounded-full text-xs font-semibold transition-all shadow-md cursor-pointer"
                  >
                    <span>Sign In to Leadership Portal</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Informative Admin Architecture Card */}
              <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-xl shadow-black/5 space-y-5">
                <div className="flex items-center justify-between border-b border-black/10 pb-4">
                  <div>
                    <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Executive Hub</span>
                    <h4 className="font-display font-semibold text-lg text-[#12281A]">
                      Institutional Governance & Administration
                    </h4>
                  </div>
                  <span className="text-[11px] font-bold text-[#1E4D33] bg-[#E4EFDA] px-2.5 py-1 rounded-full flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-[#42A85D]" /> Enterprise Grade RBAC
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="p-3.5 rounded-2xl bg-[#FBFAF7] border border-black/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-[#1E4D33] text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      01
                    </span>
                    <div>
                      <div className="font-bold text-[#12281A]">₹42.8 Cr Revenue & Fee Collection Ledger</div>
                      <div className="text-slate-600 mt-0.5 leading-relaxed">
                        Real-time tracking of tuition recovery across departments, installment scheduling, and reconciliation with university treasury.
                      </div>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-[#FBFAF7] border border-black/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-[#1E4D33] text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      02
                    </span>
                    <div>
                      <div className="font-bold text-[#12281A]">Fine-Grained Role-Based Access Control (RBAC)</div>
                      <div className="text-slate-600 mt-0.5 leading-relaxed">
                        Granular policy enforcement guaranteeing student data isolation and mentor intervention authorizations.
                      </div>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-[#FBFAF7] border border-black/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-[#1E4D33] text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      03
                    </span>
                    <div>
                      <div className="font-bold text-[#12281A]">Batch Cryptographic SHA-256 Signer</div>
                      <div className="text-slate-600 mt-0.5 leading-relaxed">
                        Bulk sign degrees and convocation grade cards with SHA-256 hashes synchronized to National DigiLocker repository.
                      </div>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-[#FBFAF7] border border-black/10 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-[#1E4D33] text-white font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      04
                    </span>
                    <div>
                      <div className="font-bold text-[#12281A]">Campus Infrastructure & Transit Dispatch</div>
                      <div className="text-slate-600 mt-0.5 leading-relaxed">
                        Hostel room allocations, cafeteria hygiene audits, and multi-route GPS fleet telemetry for university transport.
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-black/10 flex items-center justify-between">
                  <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-amber-600" />
                    <span>Administrator authentication required for executive controls</span>
                  </div>
                  <button
                    onClick={() => onOpenRoleLogin('admin')}
                    className="px-4 py-2 bg-[#1E4D33] hover:bg-[#2A6647] text-white font-bold text-xs rounded-xl transition-colors cursor-pointer"
                  >
                    Launch Leadership Hub
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Subtle Animated Divider 3 */}
      <div className="subtle-animated-divider" />

      {/* ============ EDITORIAL BENTO SHOWCASE (Substance Lab style) ============ */}
      <section className="bg-[#E4EFDA] text-[#12281A] py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-6 sm:px-10">
          <div className="max-w-3xl mb-16" data-reveal>
            <p className="text-xs uppercase tracking-[0.25em] text-[#1E4D33] font-semibold mb-4">
              Core Technical Architecture
            </p>
            <h2 className="font-display text-4xl sm:text-6xl font-light tracking-tighter">
              Where event-driven workflows meet{' '}
              <em className="font-serif-accent italic font-normal text-[#1E4D33]">
                tamper-proof integrity.
              </em>
            </h2>
            <p className="text-base sm:text-lg text-[#12281A]/70 mt-6 leading-relaxed">
              Every operation inside Cassatrix triggers real-time state machines—from classroom proximity beacon checks to automatic out-pass verification and AI dropout early warnings.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Panel 1 */}
            <div className="bg-[#FBFAF7] rounded-2xl p-6 sm:p-8 border border-black/10 shadow-lg shadow-black/5 flex flex-col justify-between" data-reveal>
              <div>
                <div className="aspect-[16/10] rounded-xl overflow-hidden mb-6 bg-slate-100">
                  <img
                    src="/src/assets/images/campus_student_learning_hub_1790955628415.jpg"
                    alt="Smart Learning & AI Assistant"
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                  />
                </div>
                <div className="text-xs font-mono text-[#42A85D] mb-2 font-bold">01 · GEOFENCED OTP ATTENDANCE</div>
                <h3 className="font-display text-xl font-semibold text-[#12281A] mb-2">
                  Zero-Proxy Geofenced OTP
                </h3>
                <p className="text-sm text-[#12281A]/70 leading-relaxed">
                  Dual-factor 6-digit lecture OTP verification and physical classroom GPS boundary checks eradicate proxy attendance forever.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-black/5 text-xs font-mono text-[#1E4D33] flex items-center justify-between">
                <span>Latency: &lt; 200ms</span>
                <span className="text-[#42A85D]">100% Audit Track</span>
              </div>
            </div>

            {/* Panel 2 */}
            <div className="bg-[#FBFAF7] rounded-2xl p-6 sm:p-8 border border-black/10 shadow-lg shadow-black/5 flex flex-col justify-between" data-reveal>
              <div>
                <div className="aspect-[16/10] rounded-xl overflow-hidden mb-6 bg-slate-100">
                  <img
                    src="/src/assets/images/campus_governance_center_1790955647613.jpg"
                    alt="Campus Governance Center"
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                  />
                </div>
                <div className="text-xs font-mono text-[#42A85D] mb-2 font-bold">02 · PREDICTIVE ML ENGINE</div>
                <h3 className="font-display text-xl font-semibold text-[#12281A] mb-2">
                  Early Dropout Detection
                </h3>
                <p className="text-sm text-[#12281A]/70 leading-relaxed">
                  Continuous assessment analysis monitors attendance trajectories and quiz percentiles, flagging at-risk scholars before exam debarment.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-black/5 text-xs font-mono text-[#1E4D33] flex items-center justify-between">
                <span>Accuracy: 94.2%</span>
                <span className="text-[#42A85D]">Automated SMS/Push</span>
              </div>
            </div>

            {/* Panel 3 */}
            <div className="bg-[#FBFAF7] rounded-2xl p-6 sm:p-8 border border-black/10 shadow-lg shadow-black/5 flex flex-col justify-between" data-reveal>
              <div>
                <div className="aspect-[16/10] rounded-xl overflow-hidden mb-6 bg-slate-100">
                  <img
                    src="/src/assets/images/smart_campus_aerial_1790954534375.jpg"
                    alt="Campus Aerial Infrastructure"
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                  />
                </div>
                <div className="text-xs font-mono text-[#42A85D] mb-2 font-bold">03 · SMART LIVING & TRANSIT</div>
                <h3 className="font-display text-xl font-semibold text-[#12281A] mb-2">
                  Campus Logistics Spine
                </h3>
                <p className="text-sm text-[#12281A]/70 leading-relaxed">
                  Automated hostel out-passes with guardian verification, mess food quality audit logs, and real-time university bus GPS telemetry.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-black/5 text-xs font-mono text-[#1E4D33] flex items-center justify-between">
                <span>18 GPS Fleet Units</span>
                <span className="text-[#42A85D]">Auto-Approval Logic</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Subtle Animated Divider 4 */}
      <div className="subtle-animated-divider" />

      {/* ============ PROOF & ACCREDITATIONS ============ */}
      <section className="bg-[#FBFAF7] py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-6 sm:px-10 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-5" data-reveal>
            <div className="rounded-2xl overflow-hidden aspect-[4/5] shadow-2xl shadow-black/10 border border-black/10">
              <img
                src="/src/assets/images/campus_student_learning_hub_1790955628415.jpg"
                alt="Institutional Council and Students"
                className="w-full h-full object-cover filter grayscale hover:grayscale-0 transition-all duration-700"
              />
            </div>
          </div>

          <div className="lg:col-span-7 space-y-6" data-reveal>
            <div className="text-xs uppercase tracking-[0.25em] text-[#1E4D33] font-semibold">
              Dean & Governance Endorsement
            </div>
            <blockquote className="font-display text-2xl sm:text-4xl leading-[1.25] text-[#12281A] font-light tracking-tight">
              "By eliminating proxy attendance with geofenced OTP and automating multi-tier grievance escalations, Cassatrix transformed our university operations into a transparent, event-driven academic institution."
            </blockquote>
            <div className="pt-2">
              <div className="text-base font-semibold text-[#12281A]">Dr. Rajeshwar Rao</div>
              <div className="text-xs text-[#12281A]/50">Registrar & Dean of Digital Governance · Cassatrix Digital Campus</div>
            </div>

            <div className="pt-6 border-t border-black/10 grid grid-cols-3 gap-6 text-xs">
              <div>
                <div className="font-mono text-2xl font-bold text-[#1E4D33]">12,450</div>
                <div className="text-[#12281A]/60 mt-0.5">Enrolled Scholars</div>
              </div>
              <div>
                <div className="font-mono text-2xl font-bold text-[#1E4D33]">₹42.8 Cr</div>
                <div className="text-[#12281A]/60 mt-0.5">Fee Reconciled</div>
              </div>
              <div>
                <div className="font-mono text-2xl font-bold text-[#42A85D]">100%</div>
                <div className="text-[#12281A]/60 mt-0.5">DigiLocker Synced</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Subtle Animated Divider 5 */}
      <div className="subtle-animated-divider" />

      {/* ============ FOOTER ============ */}
      <footer className="border-t border-black/10 bg-[#FBFAF7] py-12">
        <div className="max-w-7xl mx-auto px-6 sm:px-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="flex items-center gap-2.5">
            <span className="grid grid-cols-3 gap-[2.5px]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#42A85D]"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#12281A]/70"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#12281A]/30"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#12281A]/70"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#42A85D]"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#12281A]/70"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#12281A]/30"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#12281A]/70"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#42A85D]"></span>
            </span>
            <span className="font-display font-semibold text-sm tracking-tight text-[#12281A]">
              Cassatrix Smart Campus Infrastructure
            </span>
          </div>

          <div className="flex flex-wrap gap-x-6 gap-y-2 text-xs text-[#12281A]/60">
            <button onClick={() => onOpenRoleLogin('student')} className="hover:text-[#12281A] transition-colors cursor-pointer">
              Student Portal
            </button>
            <button onClick={() => onOpenRoleLogin('faculty')} className="hover:text-[#12281A] transition-colors cursor-pointer">
              Faculty & Mentor
            </button>
            <button onClick={() => onOpenRoleLogin('parent')} className="hover:text-[#12281A] transition-colors cursor-pointer">
              Parent Transparency
            </button>
            <button onClick={() => onOpenRoleLogin('admin')} className="hover:text-[#12281A] transition-colors cursor-pointer">
              Leadership & Admin
            </button>
            <button onClick={onOpenVoiceAssistant} className="hover:text-[#12281A] transition-colors cursor-pointer">
              Voice Icecream
            </button>
          </div>

          <p className="text-xs text-[#12281A]/40 font-mono">
            © 2026 Cassatrix University · Single-Window ERP
          </p>
        </div>
      </footer>
    </div>
  );
};
