import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';
import { Shield, Lock, LogOut, Sparkles, Mic, Menu, X, GraduationCap, Briefcase, Users, ShieldCheck } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenLogin: (role?: UserRole) => void;
  onOpenVoiceAssistant: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenLogin,
  onOpenVoiceAssistant,
}) => {
  const { currentUser, currentRole, logout, attemptRoleSwitch } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (tab: string, targetRole?: UserRole) => {
    setMobileMenuOpen(false);
    if (targetRole) {
      if (!currentUser) {
        // Unauthenticated: MUST prompt user to log in for this specific role!
        onOpenLogin(targetRole);
        return;
      }
      if (currentUser.role === targetRole) {
        setActiveTab(tab);
        return;
      }
      // Logged in as another role: role switch guard checks password
      const allowed = attemptRoleSwitch(targetRole);
      if (allowed) {
        setActiveTab(tab);
      }
    } else {
      setActiveTab(tab);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FBFAF7]/95 backdrop-blur-md border-b border-black/10 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-3">
        {/* Zone 1: Single text element Brand Wordmark */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => handleNavClick('landing')}
            className="flex items-center gap-2.5 text-left group cursor-pointer"
          >
            {/* 3x3 Dot matrix insignia inspired by Cassatrix */}
            <span className="grid grid-cols-3 gap-[2.5px] p-1.5 rounded-lg bg-[#1E4D33]/10 group-hover:bg-[#1E4D33]/20 transition-colors">
              <span className="w-1.5 h-1.5 rounded-full bg-[#42A85D]"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#12281A]/70"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#12281A]/30"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#12281A]/70"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#42A85D]"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#12281A]/70"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#12281A]/30"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#12281A]/70"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#42A85D]"></span>
            </span>
            <span className="font-display font-bold text-lg sm:text-xl tracking-tight text-[#12281A]">
              Cassatrix
            </span>
          </button>
        </div>

        {/* Zone 2: Desktop Clean Navigation Links (Hidden on Mobile) */}
        <nav className="hidden lg:flex items-center gap-6 xl:gap-7 text-xs font-medium text-[#12281A]/60">
          <button
            onClick={() => handleNavClick('landing')}
            className={`transition-colors hover:text-[#12281A] whitespace-nowrap cursor-pointer ${
              activeTab === 'landing' ? 'text-[#1E4D33] font-semibold border-b-2 border-[#1E4D33] pb-0.5' : ''
            }`}
          >
            Overview
          </button>

          <button
            onClick={() => handleNavClick('dashboard', 'student')}
            className={`transition-colors hover:text-[#12281A] whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'dashboard' && currentRole === 'student' ? 'text-[#1E4D33] font-semibold border-b-2 border-[#1E4D33] pb-0.5' : ''
            }`}
          >
            <span>Student Portal</span>
            <sup className="text-[#42A85D] text-[10px] font-mono">01</sup>
          </button>

          <button
            onClick={() => handleNavClick('faculty_portal', 'faculty')}
            className={`transition-colors hover:text-[#12281A] whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
              currentRole === 'faculty' && activeTab === 'faculty_portal' ? 'text-[#1E4D33] font-semibold border-b-2 border-[#1E4D33] pb-0.5' : ''
            }`}
          >
            <span>Faculty & Mentor</span>
            <sup className="text-[#42A85D] text-[10px] font-mono">02</sup>
          </button>

          <button
            onClick={() => handleNavClick('parent_portal', 'parent')}
            className={`transition-colors hover:text-[#12281A] whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
              currentRole === 'parent' && activeTab === 'parent_portal' ? 'text-[#1E4D33] font-semibold border-b-2 border-[#1E4D33] pb-0.5' : ''
            }`}
          >
            <span>Parent Portal</span>
            <sup className="text-[#42A85D] text-[10px] font-mono">03</sup>
          </button>

          <button
            onClick={() => handleNavClick('admin_portal', 'admin')}
            className={`transition-colors hover:text-[#12281A] whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
              currentRole === 'admin' && activeTab === 'admin_portal' ? 'text-[#1E4D33] font-semibold border-b-2 border-[#1E4D33] pb-0.5' : ''
            }`}
          >
            <span>Leadership & Admin</span>
            <sup className="text-[#42A85D] text-[10px] font-mono">04</sup>
          </button>

          <button
            onClick={() => handleNavClick('ai_analytics')}
            className={`transition-colors hover:text-[#12281A] flex items-center gap-1 whitespace-nowrap cursor-pointer ${
              activeTab === 'ai_analytics' ? 'text-[#1E4D33] font-semibold border-b-2 border-[#1E4D33] pb-0.5' : ''
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-[#42A85D]" />
            <span>AI Risk Pipeline</span>
          </button>

          <button
            onClick={() => handleNavClick('tech_architecture')}
            className={`transition-colors hover:text-[#12281A] flex items-center gap-1 whitespace-nowrap cursor-pointer ${
              activeTab === 'tech_architecture' ? 'text-[#1E4D33] font-semibold border-b-2 border-[#1E4D33] pb-0.5' : ''
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-[#42A85D]"></span>
            <span>Tech Architecture</span>
          </button>
        </nav>

        {/* Zone 3: Primary Actions & User Status */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={onOpenVoiceAssistant}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#1E4D33] bg-[#E4EFDA] hover:bg-[#d8e7cb] rounded-full transition-colors shadow-2xs whitespace-nowrap cursor-pointer"
            title="Launch Voice Assistant"
          >
            <Mic className="w-3.5 h-3.5 text-[#1E4D33]" />
            <span>Voice Icecream</span>
          </button>

          {currentUser ? (
            <div className="flex items-center gap-2">
              <div className="text-right hidden md:block">
                <div className="text-xs font-semibold text-[#12281A] flex items-center justify-end gap-1">
                  <span>{currentUser.name}</span>
                  <span title="Session Role Locked">
                    <Lock className="w-3 h-3 text-[#1E4D33]" />
                  </span>
                </div>
                <div className="text-[11px] text-[#12281A]/50 capitalize">
                  {currentUser.roleTitle}
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => onOpenLogin(currentUser.role)}
                  className="px-2.5 sm:px-3 py-1.5 text-xs font-medium bg-[#1E4D33]/10 hover:bg-[#1E4D33]/20 text-[#1E4D33] rounded-full transition-colors flex items-center gap-1 whitespace-nowrap cursor-pointer"
                  title="Switch Role Portal"
                >
                  <Shield className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Switch Role</span>
                </button>

                <button
                  onClick={logout}
                  className="p-1.5 text-[#12281A]/40 hover:text-rose-600 hover:bg-rose-50 rounded-full transition-colors cursor-pointer"
                  title="Sign Out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onOpenLogin('student')}
                className="px-3.5 sm:px-4 py-2 text-xs font-medium text-white bg-[#1E4D33] hover:bg-[#2A6647] active:scale-95 rounded-full transition-all duration-300 shadow-md shadow-[#1E4D33]/20 whitespace-nowrap cursor-pointer"
              >
                Sign In to Portal
              </button>
            </div>
          )}

          {/* Mobile Hamburger Toggle Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-xl text-[#12281A] hover:bg-[#1E4D33]/10 transition-colors cursor-pointer"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Responsive Mobile Drawer / Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white/95 backdrop-blur-md border-b border-black/10 px-4 py-4 space-y-3 animate-fade-in shadow-xl">
          {currentUser && (
            <div className="p-3 bg-[#FBFAF7] rounded-2xl border border-black/10 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-[#12281A] flex items-center gap-1">
                  <span>{currentUser.name}</span>
                  <Lock className="w-3 h-3 text-[#1E4D33]" />
                </div>
                <div className="text-[11px] text-[#12281A]/60 capitalize">{currentUser.roleTitle}</div>
              </div>
              <button
                onClick={logout}
                className="px-2.5 py-1 text-xs text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg font-semibold flex items-center gap-1 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Logout</span>
              </button>
            </div>
          )}

          <div className="grid grid-cols-1 gap-1 text-sm font-semibold text-[#12281A]">
            <button
              onClick={() => handleNavClick('landing')}
              className={`w-full text-left p-2.5 rounded-xl transition-colors cursor-pointer flex items-center justify-between ${
                activeTab === 'landing' ? 'bg-[#E4EFDA] text-[#1E4D33]' : 'hover:bg-slate-100'
              }`}
            >
              <span>🏛️ Overview & Infrastructure</span>
            </button>

            <button
              onClick={() => handleNavClick('dashboard', 'student')}
              className={`w-full text-left p-2.5 rounded-xl transition-colors cursor-pointer flex items-center justify-between ${
                activeTab === 'dashboard' ? 'bg-[#E4EFDA] text-[#1E4D33]' : 'hover:bg-slate-100'
              }`}
            >
              <span className="flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-[#42A85D]" />
                <span>Student ERP Portal</span>
              </span>
              <span className="text-[10px] font-mono text-[#42A85D]">01</span>
            </button>

            <button
              onClick={() => handleNavClick('faculty_portal', 'faculty')}
              className={`w-full text-left p-2.5 rounded-xl transition-colors cursor-pointer flex items-center justify-between ${
                activeTab === 'faculty_portal' ? 'bg-[#E4EFDA] text-[#1E4D33]' : 'hover:bg-slate-100'
              }`}
            >
              <span className="flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-[#42A85D]" />
                <span>Faculty & Mentor Console</span>
              </span>
              <span className="text-[10px] font-mono text-[#42A85D]">02</span>
            </button>

            <button
              onClick={() => handleNavClick('parent_portal', 'parent')}
              className={`w-full text-left p-2.5 rounded-xl transition-colors cursor-pointer flex items-center justify-between ${
                activeTab === 'parent_portal' ? 'bg-[#E4EFDA] text-[#1E4D33]' : 'hover:bg-slate-100'
              }`}
            >
              <span className="flex items-center gap-2">
                <Users className="w-4 h-4 text-[#42A85D]" />
                <span>Parent & Guardian Portal</span>
              </span>
              <span className="text-[10px] font-mono text-[#42A85D]">03</span>
            </button>

            <button
              onClick={() => handleNavClick('admin_portal', 'admin')}
              className={`w-full text-left p-2.5 rounded-xl transition-colors cursor-pointer flex items-center justify-between ${
                activeTab === 'admin_portal' ? 'bg-[#E4EFDA] text-[#1E4D33]' : 'hover:bg-slate-100'
              }`}
            >
              <span className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#42A85D]" />
                <span>Leadership & Governance Hub</span>
              </span>
              <span className="text-[10px] font-mono text-[#42A85D]">04</span>
            </button>

            <button
              onClick={() => handleNavClick('ai_analytics')}
              className={`w-full text-left p-2.5 rounded-xl transition-colors cursor-pointer flex items-center justify-between ${
                activeTab === 'ai_analytics' ? 'bg-[#E4EFDA] text-[#1E4D33]' : 'hover:bg-slate-100'
              }`}
            >
              <span className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#42A85D]" />
                <span>AI Risk & Dropout Pipeline</span>
              </span>
            </button>
          </div>

          <div className="pt-2 border-t border-black/10 flex gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenVoiceAssistant();
              }}
              className="flex-1 py-2.5 bg-[#E4EFDA] hover:bg-[#d8e7cb] text-[#1E4D33] rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
            >
              <Mic className="w-3.5 h-3.5" />
              <span>Voice Icecream</span>
            </button>

            {!currentUser && (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenLogin('student');
                }}
                className="flex-1 py-2.5 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
              >
                <span>Sign In</span>
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
