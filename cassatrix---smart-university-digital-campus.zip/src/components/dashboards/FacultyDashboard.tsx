import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  STUDENT_RISK_PROFILES,
  INITIAL_TIMETABLE,
  INITIAL_GRIEVANCES,
} from '../../data/mockData';
import {
  Users,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Calendar,
  BookOpen,
  Award,
  Sparkles,
  Send,
  Save,
  Radio,
  Clock,
  RefreshCw,
  Bell,
  Check,
  Shield,
  LifeBuoy,
} from 'lucide-react';
import { GrievanceTicket } from '../../types';

export const FacultyDashboard: React.FC = () => {
  const { currentUser } = useAuth();

  // Classroom Live Geofence Session Radar (No QR)
  const [sessionPulse, setSessionPulse] = useState(15);
  const [radarActive, setRadarActive] = useState(true);
  const [currentSessionToken, setCurrentSessionToken] = useState('UNIV-RADAR-CS601-9481');

  // Dynamic geofence pulse
  useEffect(() => {
    const timer = setInterval(() => {
      setSessionPulse((prev) => {
        if (prev <= 1) {
          setCurrentSessionToken(`UNIV-RADAR-CS601-${Math.floor(1000 + Math.random() * 9000)}`);
          return 15;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Class roster with manual override capability
  const [students, setStudents] = useState([
    { id: '0101CS221045', name: 'Aarav Sharma', status: 'Present' as 'Present' | 'Absent', overrideReason: '' },
    { id: '0101CS221088', name: 'Rohan Mehra', status: 'Absent' as 'Present' | 'Absent', overrideReason: '' },
    { id: '0101CS221062', name: 'Pooja Tiwari', status: 'Present' as 'Present' | 'Absent', overrideReason: '' },
    { id: '0101CS221019', name: 'Devansh Khandelwal', status: 'Present' as 'Present' | 'Absent', overrideReason: '' },
    { id: '0101CS221094', name: 'Ananya Deshmukh', status: 'Present' as 'Present' | 'Absent', overrideReason: '' },
  ]);

  // Centralized Grading Ledger State
  const [gradingLedger, setGradingLedger] = useState([
    { id: '0101CS221045', name: 'Aarav Sharma', midTerm: 28, practical: 29, quiz: 19, assignment: 10 },
    { id: '0101CS221088', name: 'Rohan Mehra', midTerm: 12, practical: 14, quiz: 7, assignment: 5 },
    { id: '0101CS221062', name: 'Pooja Tiwari', midTerm: 23, practical: 25, quiz: 15, assignment: 9 },
    { id: '0101CS221019', name: 'Devansh Khandelwal', midTerm: 26, practical: 28, quiz: 18, assignment: 9 },
    { id: '0101CS221094', name: 'Ananya Deshmukh', midTerm: 27, practical: 26, quiz: 17, assignment: 10 },
  ]);

  // Conflict Resolution Alert State
  const [timetableConflict, setTimetableConflict] = useState<string | null>(
    'Lab 204 Schedule Collision Detected: CS602-P coincides with M.Tech AI Seminar on Monday 2 PM.'
  );

  // Early Dropout Intervention Alerts
  const [riskProfiles, setRiskProfiles] = useState(STUDENT_RISK_PROFILES);
  const [counselingNotice, setCounselingNotice] = useState<string | null>(null);

  // Department Grievance Queue
  const [deptTickets, setDeptTickets] = useState<GrievanceTicket[]>(
    INITIAL_GRIEVANCES.filter((g) => g.category === 'Academic')
  );

  // Feedback notifications
  const [attendanceSaved, setAttendanceSaved] = useState(false);
  const [gradesSaved, setGradesSaved] = useState(false);

  // Override attendance toggle
  const toggleStudentAttendance = (id: string) => {
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id === id) {
          const newStatus = s.status === 'Present' ? 'Absent' : 'Present';
          return {
            ...s,
            status: newStatus,
            overrideReason: newStatus === 'Present' ? 'Faculty Manual Proctor Override' : '',
          };
        }
        return s;
      })
    );
  };

  // Resolve schedule conflict
  const handleAutoRescheduleConflict = () => {
    setTimetableConflict(null);
    setCounselingNotice('Schedule collision resolved: CS602-P moved to Turing Advanced AI Lab 102.');
    setTimeout(() => setCounselingNotice(null), 5000);
  };

  // Schedule Priority Counseling
  const handleScheduleCounseling = (studentId: string, studentName: string) => {
    setRiskProfiles((prev) =>
      prev.map((p) => (p.studentId === studentId ? { ...p, counselingScheduled: true } : p))
    );
    setCounselingNotice(
      `Priority academic counseling scheduled for ${studentName}. Automated SMS and Push alert dispatched to registered guardian!`
    );
    setTimeout(() => setCounselingNotice(null), 6000);
  };

  // Resolve department ticket
  const handleResolveTicket = (ticketId: string) => {
    setDeptTickets((prev) =>
      prev.map((t) =>
        t.id === ticketId
          ? {
              ...t,
              status: 'Resolved',
              resolutionRemarks: 'Marks re-totaled and Question 4(b) awarded 4 marks. Central grade ledger synced.',
            }
          : t
      )
    );
  };

  // Update grade score
  const handleUpdateGrade = (id: string, field: 'midTerm' | 'practical' | 'quiz' | 'assignment', val: number) => {
    setGradingLedger((prev) =>
      prev.map((row) => (row.id === id ? { ...row, [field]: Number(val) } : row))
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fade-in text-[#12281A]">
      {/* ============ BANNER ============ */}
      <div className="bg-[#12281A] text-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-96 bg-gradient-to-l from-[#42A85D]/15 to-transparent pointer-events-none"></div>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2 text-xs uppercase tracking-widest text-[#42A85D] font-mono">
              <span className="w-2 h-2 rounded-full bg-[#42A85D] animate-pulse"></span>
              <span>Academic Instruction & Mentorship Console</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-display font-light text-white tracking-tight">
              {currentUser?.role === 'faculty' ? currentUser.name : 'Dr. Sunita Verma'}
            </h1>
            <p className="text-xs text-white/70 mt-1.5 font-mono">
              Department of Computer Science & Engineering · Proctor ID: <strong className="text-[#42A85D]">FAC-CS-809</strong>
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/10 text-xs">
            <div className="text-white/60 font-semibold">Active Assigned Lecture:</div>
            <div className="text-base font-bold text-[#42A85D] mt-0.5">CS601: Advanced Database Systems</div>
            <div className="text-[11px] text-white/70 font-mono">Smart Lecture Hall 301 (10:00 - 11:30 AM)</div>
          </div>
        </div>
      </div>

      {counselingNotice && (
        <div className="p-4 bg-[#E4EFDA] border border-[#42A85D]/40 text-[#1E4D33] rounded-2xl text-xs flex items-center gap-3 animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-[#42A85D] shrink-0" />
          <div className="font-semibold">{counselingNotice}</div>
        </div>
      )}

      {/* Conflict Detection Alert */}
      {timetableConflict && (
        <div className="p-4 bg-amber-50 border border-amber-300 text-amber-900 rounded-2xl text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-fade-in">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
            <div>
              <strong>Timetable Conflict Detected:</strong> {timetableConflict}
            </div>
          </div>
          <button
            onClick={handleAutoRescheduleConflict}
            className="px-3.5 py-1.5 bg-amber-800 text-white rounded-xl font-semibold text-xs whitespace-nowrap cursor-pointer hover:bg-amber-900"
          >
            Auto-Reschedule to Hall 102
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* ========================================================================= */}
        {/* CAPABILITY 1: DYNAMIC 6-DIGIT LECTURE OTP GENERATOR WITH GEOFENCE LOCK */}
        {/* ========================================================================= */}
        <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-6">
          <div className="flex items-center justify-between border-b border-black/10 pb-4">
            <div>
              <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Classroom Operations</span>
              <h3 className="font-display font-semibold text-xl text-[#12281A] mt-1">
                Live 6-Digit Lecture OTP Generator
              </h3>
            </div>
            <div className="text-right">
              <span className="text-[11px] text-[#12281A]/50">OTP Rotates in</span>
              <div className="font-mono text-sm font-bold text-[#1E4D33]">
                00:{sessionPulse.toString().padStart(2, '0')}s
              </div>
            </div>
          </div>

          <div className="p-6 bg-[#FBFAF7] rounded-2xl border border-black/10 flex flex-col items-center justify-center text-center relative overflow-hidden">
            {/* Geofence Guard Badge */}
            <div className="flex items-center gap-2 mb-3 bg-[#E4EFDA] text-[#1E4D33] px-3 py-1 rounded-full text-xs font-semibold">
              <Shield className="w-3.5 h-3.5 text-[#42A85D]" />
              <span>50m Geofence Lock: Smart Hall 301</span>
            </div>

            {/* Prominent 6-Digit OTP Box */}
            <div className="p-3 sm:p-5 bg-white rounded-2xl border-2 border-[#1E4D33]/20 shadow-md flex items-center justify-center gap-1.5 sm:gap-2.5 my-2 max-w-full overflow-x-auto">
              {currentSessionToken.slice(-6).split('').map((digit, idx) => (
                <span
                  key={idx}
                  className="w-8 h-10 sm:w-10 sm:h-12 rounded-xl bg-[#FBFAF7] border border-black/15 font-mono text-lg sm:text-2xl font-black text-[#1E4D33] flex items-center justify-center shadow-inner shrink-0"
                >
                  {digit}
                </span>
              ))}
            </div>

            <div className="flex items-center gap-2 mt-2">
              <span className="font-mono text-xs font-bold text-[#1E4D33]">
                Active Code: {currentSessionToken.slice(-6)}
              </span>
              <button
                onClick={() => {
                  const newCode = `${Math.floor(100000 + Math.random() * 900000)}`;
                  setCurrentSessionToken(`UNIV-RADAR-CS601-${newCode}`);
                  setSessionPulse(45);
                }}
                className="p-1 hover:bg-slate-200 rounded text-slate-600 text-[11px] flex items-center gap-1 font-semibold cursor-pointer"
                title="Refresh OTP Code"
              >
                <RefreshCw className="w-3 h-3 text-[#42A85D]" />
                <span>New OTP</span>
              </button>
            </div>

            <p className="text-[11px] text-[#12281A]/60 mt-2 max-w-sm">
              Project this 6-digit code onto the lecture screen. Students must be inside the <strong>50m physical classroom geofence</strong> to validate this OTP.
            </p>
          </div>

          {/* Manual Exception Override Roster */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-[#12281A]">
                Real-Time Class Attendance Roster (CS601)
              </span>
              <span className="text-xs font-mono text-[#1E4D33] font-bold">
                {students.filter((s) => s.status === 'Present').length} / {students.length} Verified Present
              </span>
            </div>

            <div className="divide-y divide-black/5 border border-black/10 rounded-2xl overflow-hidden bg-white text-xs">
              {students.map((student) => (
                <div key={student.id} className="p-3 flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-[#12281A]">{student.name}</div>
                    <div className="text-[11px] font-mono text-[#12281A]/50">
                      {student.id} {student.status === 'Present' ? '· OTP (Verified) + GPS (14m Lock)' : (student.overrideReason ? `· ${student.overrideReason}` : '· Awaiting OTP')}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`px-2.5 py-0.5 rounded text-[10px] font-bold ${
                      student.status === 'Present' ? 'bg-[#E4EFDA] text-[#1E4D33]' : 'bg-rose-100 text-rose-800'
                    }`}>
                      {student.status}
                    </span>
                    <button
                      onClick={() => toggleStudentAttendance(student.id)}
                      className="px-2.5 py-1 border border-black/15 hover:bg-slate-50 text-[10px] rounded-lg font-medium cursor-pointer"
                    >
                      Override
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => {
                setAttendanceSaved(true);
                setTimeout(() => setAttendanceSaved(false), 4000);
              }}
              className="w-full py-2.5 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Publish Attendance to Central Ledger</span>
            </button>

            {attendanceSaved && (
              <div className="text-center text-xs text-emerald-700 font-semibold animate-fade-in">
                Attendance ledger updated and synced with parent notifications!
              </div>
            )}
          </div>
        </div>

        {/* ========================================================================= */}
        {/* CAPABILITY 2: EARLY DROPOUT INTERVENTION DASHBOARD */}
        {/* ========================================================================= */}
        <div className="lg:col-span-6 space-y-8">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-5">
            <div className="border-b border-black/10 pb-4">
              <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Predictive Machine Learning</span>
              <h3 className="font-display font-semibold text-xl text-[#12281A] mt-1">
                Early Intervention & Counseling Alerts
              </h3>
              <p className="text-xs text-[#12281A]/60 mt-0.5">
                AI model continuously checks attendance trajectories & quiz percentile decline.
              </p>
            </div>

            <div className="space-y-4">
              {riskProfiles.map((student) => (
                <div
                  key={student.studentId}
                  className="p-4 rounded-2xl border border-black/10 bg-[#FBFAF7] space-y-3 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-bold text-sm text-[#12281A]">{student.name}</span>
                      <span className="font-mono text-xs text-[#12281A]/50 ml-2">({student.enrollmentNo})</span>
                    </div>
                    <span className={`px-2.5 py-0.5 rounded font-bold text-[10px] ${
                      student.dropoutRiskLevel === 'High'
                        ? 'bg-rose-100 text-rose-800'
                        : student.dropoutRiskLevel === 'Moderate'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-[#E4EFDA] text-[#1E4D33]'
                    }`}>
                      Risk Score: {student.dropoutRiskScore} / 100 ({student.dropoutRiskLevel})
                    </span>
                  </div>

                  <div className="space-y-1 text-[11px] text-[#12281A]/70">
                    {student.keyRiskFactors.map((factor, idx) => (
                      <div key={idx} className="flex items-start gap-1.5">
                        <span className="text-rose-500 font-bold">•</span>
                        <span>{factor}</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-black/5 flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-[#1E4D33]">
                      Attendance: {student.attendanceRate}% · CGPA: {student.currentCgpa}
                    </span>

                    {student.counselingScheduled ? (
                      <span className="text-emerald-700 font-bold text-[11px] flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" />
                        <span>Counseling Scheduled</span>
                      </span>
                    ) : (
                      <button
                        onClick={() => handleScheduleCounseling(student.studentId, student.name)}
                        className="px-3 py-1.5 bg-rose-700 hover:bg-rose-800 text-white rounded-lg font-semibold text-xs transition-colors cursor-pointer"
                      >
                        Mandate Proctor Counseling
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ========================================================================= */}
          {/* CAPABILITY 4: DEPARTMENT GRIEVANCE QUEUE (24-48h SLA) */}
          {/* ========================================================================= */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-5">
            <div className="border-b border-black/10 pb-4">
              <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Faculty SLA Queue</span>
              <h3 className="font-display font-semibold text-xl text-[#12281A] mt-1">
                Assigned Academic Grievances
              </h3>
              <p className="text-xs text-[#12281A]/60 mt-0.5">
                Enforced 48-Hour SLA. Unresolved tickets escalate directly to the Dean.
              </p>
            </div>

            <div className="space-y-3 text-xs">
              {deptTickets.map((t) => (
                <div key={t.id} className="p-4 rounded-2xl border border-black/10 bg-[#FBFAF7] space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#12281A]">{t.subject}</span>
                    <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                      t.status === 'Resolved' ? 'bg-[#E4EFDA] text-[#1E4D33]' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {t.status}
                    </span>
                  </div>
                  <p className="text-[#12281A]/70 text-[11px]">{t.description}</p>
                  <div className="pt-2 border-t border-black/5 flex items-center justify-between">
                    <span className="font-mono text-[#1E4D33] font-semibold">
                      SLA: {t.slaHoursRemaining}h remaining
                    </span>
                    {t.status !== 'Resolved' && (
                      <button
                        onClick={() => handleResolveTicket(t.id)}
                        className="px-3 py-1 bg-[#1E4D33] text-white rounded-lg font-semibold cursor-pointer"
                      >
                        Inspect & Resolve
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* CAPABILITY 3: CENTRALIZED GRADING LEDGER */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-black/10 pb-4">
          <div>
            <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Evaluation Infrastructure</span>
            <h3 className="font-display font-semibold text-xl text-[#12281A] mt-1">
              Centralized Continuous Assessment Grading Ledger
            </h3>
            <p className="text-xs text-[#12281A]/60 mt-0.5">
              Live spreadsheet grid for mid-term, practical evaluations, and continuous quizzes.
            </p>
          </div>
          <button
            onClick={() => {
              setGradesSaved(true);
              setTimeout(() => setGradesSaved(false), 4000);
            }}
            className="px-4 py-2 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save & Recalculate CGPA Ledger</span>
          </button>
        </div>

        {gradesSaved && (
          <div className="p-3 bg-[#E4EFDA] border border-[#42A85D]/40 text-[#1E4D33] rounded-xl text-xs flex items-center gap-2 animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-[#42A85D]" />
            <span>Centralized grading ledger reconciled. Automatic GPA updates synchronized across university databases.</span>
          </div>
        )}

        {/* Mobile horizontal scroll hint */}
        <div className="flex sm:hidden items-center justify-between text-[11px] text-[#1E4D33] bg-[#E4EFDA] px-3 py-1.5 rounded-xl font-medium">
          <span>← Swipe horizontally to edit all grade columns →</span>
          <span className="font-mono text-[10px]">7 Columns</span>
        </div>

        <div className="overflow-x-auto max-w-full border border-black/10 rounded-2xl touch-pan-x">
          <table className="w-full text-xs text-left min-w-[700px]">
            <thead className="bg-[#FBFAF7] text-[#12281A]/70 uppercase font-mono text-[10px] border-b border-black/10">
              <tr>
                <th className="py-3 px-4">Scholar Name & ID</th>
                <th className="py-3 px-4">Mid-Term (30)</th>
                <th className="py-3 px-4">Practical (30)</th>
                <th className="py-3 px-4">Quiz (20)</th>
                <th className="py-3 px-4">Continuous Assignment (10)</th>
                <th className="py-3 px-4">Total Score (90)</th>
                <th className="py-3 px-4">Standing</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-black/5 font-mono">
              {gradingLedger.map((row) => {
                const total = row.midTerm + row.practical + row.quiz + row.assignment;
                const standing = total >= 70 ? 'Excellent' : total >= 50 ? 'Average' : 'Intervention Needed';
                return (
                  <tr key={row.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-sans font-bold text-[#12281A]">{row.name}</div>
                      <div className="text-[10px] text-[#12281A]/50">{row.id}</div>
                    </td>
                    <td className="py-3 px-4">
                      <input
                        type="number"
                        min={0}
                        max={30}
                        value={row.midTerm}
                        onChange={(e) => handleUpdateGrade(row.id, 'midTerm', Number(e.target.value))}
                        className="w-16 px-2 py-1 rounded border border-black/15 bg-white text-xs"
                      />
                    </td>
                    <td className="py-3 px-4">
                      <input
                        type="number"
                        min={0}
                        max={30}
                        value={row.practical}
                        onChange={(e) => handleUpdateGrade(row.id, 'practical', Number(e.target.value))}
                        className="w-16 px-2 py-1 rounded border border-black/15 bg-white text-xs"
                      />
                    </td>
                    <td className="py-3 px-4">
                      <input
                        type="number"
                        min={0}
                        max={20}
                        value={row.quiz}
                        onChange={(e) => handleUpdateGrade(row.id, 'quiz', Number(e.target.value))}
                        className="w-16 px-2 py-1 rounded border border-black/15 bg-white text-xs"
                      />
                    </td>
                    <td className="py-3 px-4">
                      <input
                        type="number"
                        min={0}
                        max={10}
                        value={row.assignment}
                        onChange={(e) => handleUpdateGrade(row.id, 'assignment', Number(e.target.value))}
                        className="w-16 px-2 py-1 rounded border border-black/15 bg-white text-xs"
                      />
                    </td>
                    <td className="py-3 px-4 font-bold text-sm text-[#1E4D33]">
                      {total} / 90
                    </td>
                    <td className="py-3 px-4 font-sans">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        total >= 70 ? 'bg-[#E4EFDA] text-[#1E4D33]' : total >= 50 ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                      }`}>
                        {standing}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
