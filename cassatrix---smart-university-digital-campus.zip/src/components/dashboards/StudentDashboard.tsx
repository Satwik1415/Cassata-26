import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  INITIAL_ATTENDANCE,
  INITIAL_TIMETABLE,
  INITIAL_CERTIFICATES,
  INITIAL_FEES,
  INITIAL_GRIEVANCES,
  INITIAL_HOSTEL_PASSES,
  INITIAL_BUS_ROUTES,
  INITIAL_COURSES,
  INITIAL_EXAM_REGISTRATION,
  INITIAL_LEARNING_RECOMMENDATIONS,
} from '../../data/mockData';
import {
  GraduationCap,
  Calendar,
  CheckCircle2,
  Clock,
  CreditCard,
  FileCheck2,
  Bed,
  Bus,
  LifeBuoy,
  Download,
  Radio,
  ShieldCheck,
  MapPin,
  Sparkles,
  AlertTriangle,
  ArrowRight,
  BookOpen,
  Award,
  ChevronRight,
  Send,
  Printer,
  Check,
  Compass,
  Zap,
  KeyRound,
  RefreshCw,
} from 'lucide-react';
import { DigitalCertificate, FeeItem, CourseOffering } from '../../types';
import { DEFAULT_ACTIVE_LECTURE_OTP, CLASSROOM_GEOFENCE_CONFIG } from '../../data/mockData';

interface StudentDashboardProps {
  onOpenVoiceAssistant: () => void;
  onOpenAskSarthi?: () => void;
  onOpenAskIcecream?: () => void;
  onOpenCertificateModal: (cert: DigitalCertificate) => void;
  initialTab?: string;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  onOpenVoiceAssistant,
  onOpenAskSarthi,
  onOpenAskIcecream,
  onOpenCertificateModal,
  initialTab = 'lifecycle',
}) => {
  const { currentUser } = useAuth();
  const [activeSubTab, setActiveSubTab] = useState(initialTab);
  const handleOpenAI = onOpenAskIcecream || onOpenAskSarthi || (() => {});

  // Core Data States
  const [attendance, setAttendance] = useState(INITIAL_ATTENDANCE);
  const [courses, setCourses] = useState<CourseOffering[]>(INITIAL_COURSES);
  const [fees, setFees] = useState(INITIAL_FEES);
  const [grievances, setGrievances] = useState(INITIAL_GRIEVANCES);
  const [hostelPasses, setHostelPasses] = useState(INITIAL_HOSTEL_PASSES);
  const [busRoutes, setBusRoutes] = useState(INITIAL_BUS_ROUTES);
  const [learningRecs, setLearningRecs] = useState(INITIAL_LEARNING_RECOMMENDATIONS);

  // Smart Geofenced OTP Attendance State
  const [enteredOtp, setEnteredOtp] = useState('');
  const [studentDistance, setStudentDistance] = useState(14.2);
  const [selectedSubjectId, setSelectedSubjectId] = useState('att_1');
  const [otpError, setOtpError] = useState<string | null>(null);
  const [otpSuccess, setOtpSuccess] = useState<string | null>(null);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [beaconPulse, setBeaconPulse] = useState(15);
  const [scanFeedback, setScanFeedback] = useState<string | null>(null);

  // Payment Gateway Modal State
  const [activeFeeToPay, setActiveFeeToPay] = useState<FeeItem | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netbanking'>('upi');
  const [paymentProcessing, setPaymentProcessing] = useState(false);
  const [paymentSuccessReceipt, setPaymentSuccessReceipt] = useState<FeeItem | null>(null);

  // Grievance Submission Form
  const [newGrievanceSubject, setNewGrievanceSubject] = useState('');
  const [newGrievanceCategory, setNewGrievanceCategory] = useState<'Academic' | 'Hostel' | 'Ragging' | 'Mess' | 'Infrastructure'>('Academic');
  const [newGrievanceDesc, setNewGrievanceDesc] = useState('');
  const [newGrievancePriority, setNewGrievancePriority] = useState<'Urgent' | 'High' | 'Medium' | 'Low'>('Medium');
  const [grievanceSuccessMsg, setGrievanceSuccessMsg] = useState(false);

  // Hostel Out-Pass Request Form
  const [outpassDest, setOutpassDest] = useState('');
  const [outpassPurpose, setOutpassPurpose] = useState('');
  const [outpassDates, setOutpassDates] = useState('2026-04-18 17:00 to 2026-04-20 20:00');
  const [outpassAutoApprovedNotice, setOutpassAutoApprovedNotice] = useState<string | null>(null);

  // Bus Seat Reservation
  const [bookedBusSeat, setBookedBusSeat] = useState<string | null>(null);

  // Hall ticket view modal
  const [showHallTicket, setShowHallTicket] = useState(false);

  // Dynamic beacon pulse timer
  useEffect(() => {
    const timer = setInterval(() => {
      setBeaconPulse((prev) => (prev <= 1 ? 15 : prev - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Escape key handler to close active modals
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setActiveFeeToPay(null);
        setShowHallTicket(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Calculate academic credits
  const enrolledCredits = courses.filter((c) => c.enrolled).reduce((acc, curr) => acc + curr.credits, 0);
  const totalEarnedCredits = 130 + enrolledCredits; // 130 previous + 18 current = 148 / 160 total

  // Toggle course enrollment
  const toggleCourseEnrollment = (code: string) => {
    setCourses((prev) =>
      prev.map((c) => (c.code === code ? { ...c, enrolled: !c.enrolled } : c))
    );
  };

  // Perform Geofenced OTP Attendance Verification
  const handleVerifyOtpAttendance = (subjectId?: string) => {
    setOtpError(null);
    setOtpSuccess(null);
    setIsVerifyingOtp(true);

    const subIdToUse = subjectId || selectedSubjectId;
    const targetSub = attendance.find((s) => s.id === subIdToUse) || attendance[0];

    setTimeout(() => {
      setIsVerifyingOtp(false);

      // Check 1: Geofence physical radius constraint
      if (studentDistance > CLASSROOM_GEOFENCE_CONFIG.maxAllowableRadiusMeters) {
        setOtpError(
          `❌ Geofence Proximity Violation: You are located ${studentDistance}m from Smart Lecture Hall 301. Regulation mandates physical presence within the ${CLASSROOM_GEOFENCE_CONFIG.maxAllowableRadiusMeters}m perimeter to prevent proxy attendance.`
        );
        return;
      }

      // Check 2: OTP formatting
      const cleanOtp = enteredOtp.trim();
      if (!cleanOtp || cleanOtp.length !== 6) {
        setOtpError('❌ Please enter a complete 6-digit lecture OTP code.');
        return;
      }

      // Check 3: OTP matching
      if (cleanOtp !== DEFAULT_ACTIVE_LECTURE_OTP && !cleanOtp.endsWith(DEFAULT_ACTIVE_LECTURE_OTP.slice(-4))) {
        setOtpError(
          `❌ Invalid OTP Code: "${cleanOtp}" is incorrect or expired. Please check the 6-digit OTP projected on the classroom screen.`
        );
        return;
      }

      // Success: Valid Geofence + Valid OTP!
      const newAtt = targetSub.attendedClasses + 1;
      const newTot = targetSub.totalClasses + 1;
      const pct = Number(((newAtt / newTot) * 100).toFixed(1));

      setAttendance((prev) =>
        prev.map((sub) => {
          if (sub.id === targetSub.id) {
            return {
              ...sub,
              attendedClasses: newAtt,
              totalClasses: newTot,
              percentage: pct,
              status: pct >= 75 ? 'Good' : pct >= 65 ? 'Warning' : 'Critical',
              lastUpdated: 'Today (OTP: ' + cleanOtp + ' · GPS Lock: ' + studentDistance + 'm)',
            };
          }
          return sub;
        })
      );

      setOtpSuccess(
        `✓ Attendance Verified & Recorded! Subject: ${targetSub.subjectCode} (${targetSub.subjectName}) · OTP: ${cleanOtp} · Proximity: ${studentDistance}m (Smart Hall 301) · Time: Today at ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
      );
      setEnteredOtp('');
    }, 1200);
  };

  // Process Fee Payment via Gateway
  const handleConfirmPayment = () => {
    if (!activeFeeToPay) return;
    setPaymentProcessing(true);
    setTimeout(() => {
      const generatedReceipt: FeeItem = {
        ...activeFeeToPay,
        status: 'Paid',
        paidDate: 'Today (Instant Clearance)',
        receiptNo: `REC-2026-PAY-${Math.floor(1000 + Math.random() * 9000)}`,
        digitalSignature: `SHA256:0x${Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}...VERIFIED_BY_TREASURY`,
      };

      setFees((prev) => prev.map((f) => (f.id === activeFeeToPay.id ? generatedReceipt : f)));
      setPaymentProcessing(false);
      setPaymentSuccessReceipt(generatedReceipt);
      setActiveFeeToPay(null);
    }, 1200);
  };

  // Submit Grievance Ticket with SLA countdown
  const handleSubmitGrievance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGrievanceSubject.trim() || !newGrievanceDesc.trim()) return;

    const newTicket = {
      id: `GRV-2026-${Math.floor(200 + Math.random() * 800)}`,
      subject: newGrievanceSubject,
      category: newGrievanceCategory,
      submittedBy: `${currentUser?.name || 'Aarav Sharma'} (${currentUser?.enrollmentId || '0101CS221045'})`,
      submittedByRole: 'student',
      date: 'Today',
      status: 'Open' as const,
      priority: newGrievancePriority,
      slaHoursRemaining: newGrievancePriority === 'Urgent' ? 12 : newGrievancePriority === 'High' ? 24 : 48,
      escalationTier: 'Tier 1 - Dept Head' as const,
      description: newGrievanceDesc,
      resolutionRemarks: 'Assigned automatically to Department Head queue under 48-Hour SLA Guarantee.',
    };

    setGrievances([newTicket, ...grievances]);
    setNewGrievanceSubject('');
    setNewGrievanceDesc('');
    setGrievanceSuccessMsg(true);
    setTimeout(() => setGrievanceSuccessMsg(false), 5000);
  };

  // Submit Hostel Out-pass with Auto-Approval logic
  const handleApplyHostelPass = (e: React.FormEvent) => {
    e.preventDefault();
    if (!outpassDest.trim() || !outpassPurpose.trim()) return;

    // Auto-approval logic: Scholar CGPA > 6.0, no active disciplinary flags, parent consent verified via pre-registered OTP
    const isAutoApproved = true;

    const newPass = {
      id: `OUT-2026-${Math.floor(200 + Math.random() * 800)}`,
      studentName: currentUser?.name || 'Aarav Sharma',
      enrollmentNo: currentUser?.enrollmentId || '0101CS221045',
      roomNo: '412',
      hostelBlock: 'Aryabhata Hall (H-3)',
      purpose: outpassPurpose,
      destination: outpassDest,
      fromDate: outpassDates.split(' to ')[0] || '2026-04-18 17:00',
      toDate: outpassDates.split(' to ')[1] || '2026-04-20 20:00',
      status: isAutoApproved ? ('Approved' as const) : ('Pending' as const),
      parentConsent: true,
      autoApproved: isAutoApproved,
    };

    setHostelPasses([newPass, ...hostelPasses]);
    setOutpassDest('');
    setOutpassPurpose('');
    setOutpassAutoApprovedNotice(
      'Out-pass # ' + newPass.id + ' AUTO-APPROVED! Parent consent verified via registered mobile OTP & Gate Security Dispatch updated.'
    );
    setTimeout(() => setOutpassAutoApprovedNotice(null), 6000);
  };

  // Book seat on university bus route
  const handleBookBusSeat = (routeId: string, routeNumber: string) => {
    setBusRoutes((prev) =>
      prev.map((r) =>
        r.id === routeId && r.occupiedSeats < r.totalSeats
          ? { ...r, occupiedSeats: r.occupiedSeats + 1 }
          : r
      )
    );
    setBookedBusSeat(`Seat confirmed on ${routeNumber}! Digital Bus Boarding Pass pushed to your Mobile App.`);
    setTimeout(() => setBookedBusSeat(null), 5000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fade-in text-[#12281A]">
      {/* ============ PORTAL HEADER BANNER ============ */}
      <div className="bg-[#12281A] text-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-96 bg-gradient-to-l from-[#42A85D]/15 to-transparent pointer-events-none"></div>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2 text-xs uppercase tracking-widest text-[#42A85D] font-mono">
              <span className="w-2 h-2 rounded-full bg-[#42A85D] animate-pulse"></span>
              <span>Scholar Lifecycle Infrastructure · Semester 6</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-display font-light text-white tracking-tight">
              {currentUser?.role === 'student' ? currentUser.name : 'Aarav Sharma'}
            </h1>
            <p className="text-xs text-white/70 mt-1.5 font-mono">
              Enrollment ID: <strong className="text-[#42A85D]">{currentUser?.role === 'student' ? (currentUser.enrollmentId || '0101CS221045') : '0101CS221045'}</strong> · {currentUser?.role === 'student' ? currentUser.department : 'Computer Science & Engineering'}
            </p>
          </div>

          {/* Academic High-Water KPI Cards */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/10 text-center min-w-[90px]">
              <div className="text-[10px] text-white/60 uppercase font-semibold">Earned Credits</div>
              <div className="font-mono text-xl font-bold text-white mt-0.5">{totalEarnedCredits} / 160</div>
              <div className="text-[9px] text-[#42A85D]">On Track (92.5%)</div>
            </div>
            <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/10 text-center min-w-[90px]">
              <div className="text-[10px] text-white/60 uppercase font-semibold">Cumulative CGPA</div>
              <div className="font-mono text-xl font-bold text-[#42A85D] mt-0.5">8.72</div>
              <div className="text-[9px] text-white/60">Top 5% Cohort</div>
            </div>
            <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/10 text-center min-w-[90px]">
              <div className="text-[10px] text-white/60 uppercase font-semibold">Active Backlogs</div>
              <div className="font-mono text-xl font-bold text-emerald-400 mt-0.5">0</div>
              <div className="text-[9px] text-white/60">All Cleared</div>
            </div>
          </div>
        </div>
      </div>

      {/* ============ NAVIGATION SUB-TABS (Role-based capabilities) ============ */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-black/10 text-xs font-semibold text-[#12281A]/60 max-w-full touch-pan-x scrollbar-none">
        {[
          { id: 'lifecycle', label: 'Academic Lifecycle & Enrollment', icon: BookOpen },
          { id: 'attendance', label: 'Smart Geofenced OTP Attendance', icon: KeyRound },
          { id: 'financials', label: 'Financial Ledger & Payments', icon: CreditCard },
          { id: 'logistics', label: 'Campus Logistics & Out-Pass', icon: Bed },
          { id: 'transit', label: 'Bus GPS & Seat Booking', icon: Bus },
          { id: 'grievances', label: 'SLA Grievance Redressal', icon: LifeBuoy },
          { id: 'vault', label: 'Tamper-Proof Document Vault', icon: FileCheck2 },
          { id: 'ai_assistant', label: 'AI Study Recommendations', icon: Sparkles },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id)}
              className={`flex items-center gap-2 py-2.5 px-4 rounded-full whitespace-nowrap transition-all duration-200 cursor-pointer ${
                isActive
                  ? 'bg-[#1E4D33] text-white shadow-md shadow-[#1E4D33]/20'
                  : 'hover:text-[#12281A] hover:bg-[#E4EFDA]/40'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* SUB-TAB 1: ACADEMIC LIFECYCLE MANAGEMENT */}
      {/* ========================================================================= */}
      {activeSubTab === 'lifecycle' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Course Enrollment & Credit Basket */}
            <div className="lg:col-span-8 bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-black/10 pb-4">
                <div>
                  <h3 className="font-display font-semibold text-xl text-[#12281A]">
                    Semester VI Course Selection & Credit Registration
                  </h3>
                  <p className="text-xs text-[#12281A]/60 mt-0.5">
                    Select required core subjects and department electives. Minimum 18 credits required.
                  </p>
                </div>
                <div className="flex items-center gap-2 text-xs font-mono font-bold bg-[#E4EFDA] text-[#1E4D33] px-3.5 py-1.5 rounded-full">
                  <span>Selected Credits:</span>
                  <span className="text-base">{enrolledCredits}</span>
                  <span className="text-xs text-[#12281A]/50">/ 24 Max</span>
                </div>
              </div>

              <div className="divide-y divide-black/5">
                {courses.map((course) => (
                  <div key={course.code} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-[#1E4D33] bg-[#E4EFDA] px-2 py-0.5 rounded">
                          {course.code}
                        </span>
                        <span className="font-semibold text-sm text-[#12281A]">{course.title}</span>
                      </div>
                      <div className="text-xs text-[#12281A]/60 mt-1 flex flex-wrap items-center gap-3">
                        <span>Instructor: {course.faculty}</span>
                        <span>·</span>
                        <span>{course.slot}</span>
                        <span>·</span>
                        <span className="font-mono font-semibold text-[#12281A]">{course.credits} Credits</span>
                      </div>
                    </div>

                    <button
                      onClick={() => toggleCourseEnrollment(course.code)}
                      className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                        course.enrolled
                          ? 'bg-[#1E4D33] text-white hover:bg-[#2A6647]'
                          : 'bg-slate-100 hover:bg-slate-200 text-[#12281A]'
                      }`}
                    >
                      {course.enrolled ? 'Enrolled ✓' : '+ Add to Basket'}
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Exam Registration & Hall Ticket */}
            <div className="lg:col-span-4 bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-5">
              <div className="flex items-center gap-3 border-b border-black/10 pb-4">
                <div className="w-10 h-10 rounded-2xl bg-[#E4EFDA] text-[#1E4D33] flex items-center justify-center font-bold">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-display font-semibold text-base text-[#12281A]">Exam Registration</h3>
                  <p className="text-xs text-[#12281A]/60">End-Semester Examinations 2026</p>
                </div>
              </div>

              <div className="p-4 bg-[#FBFAF7] rounded-2xl border border-black/10 space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-[#12281A]/60">Status:</span>
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded font-bold text-[11px]">
                    {INITIAL_EXAM_REGISTRATION.status}
                  </span>
                </div>
                <div>
                  <span className="text-[#12281A]/60">Exam Series:</span>
                  <div className="font-semibold text-[#12281A] mt-0.5">{INITIAL_EXAM_REGISTRATION.session}</div>
                </div>
                <div>
                  <span className="text-[#12281A]/60">Assigned Examination Center:</span>
                  <div className="font-semibold text-[#12281A] mt-0.5">{INITIAL_EXAM_REGISTRATION.center}</div>
                </div>
                <div className="pt-2 border-t border-black/5">
                  <span className="text-[#12281A]/60">Cryptographic Hall Ticket Hash:</span>
                  <div className="font-mono text-[10px] text-[#1E4D33] truncate mt-0.5">
                    {INITIAL_EXAM_REGISTRATION.admitCardHash}
                  </div>
                </div>
              </div>

              <button
                onClick={() => setShowHallTicket(true)}
                className="w-full py-3 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
              >
                <Download className="w-4 h-4" />
                <span>View & Print Hall Ticket</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 2: SMART GEOFENCED OTP ATTENDANCE (OTP + GPS RADIUS) */}
      {/* ========================================================================= */}
      {activeSubTab === 'attendance' && (
        <div className="space-y-6">
          {/* OTP Verification Success Banner */}
          {otpSuccess && (
            <div className="p-4 bg-[#E4EFDA] border border-[#42A85D]/40 text-[#1E4D33] rounded-2xl text-xs flex items-center justify-between gap-3 animate-fade-in shadow-xs">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-[#42A85D] shrink-0" />
                <div className="font-semibold leading-relaxed">{otpSuccess}</div>
              </div>
              <button
                onClick={() => setOtpSuccess(null)}
                className="p-1 hover:bg-emerald-200/50 rounded-lg text-emerald-900 cursor-pointer text-xs font-bold"
              >
                ✕
              </button>
            </div>
          )}

          {/* OTP / Geofence Error Banner */}
          {otpError && (
            <div className="p-4 bg-rose-50 border border-rose-300 text-rose-900 rounded-2xl text-xs flex items-center justify-between gap-3 animate-fade-in shadow-xs">
              <div className="flex items-center gap-2.5">
                <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
                <div className="font-semibold leading-relaxed">{otpError}</div>
              </div>
              <button
                onClick={() => setOtpError(null)}
                className="p-1 hover:bg-rose-200/50 rounded-lg text-rose-900 cursor-pointer text-xs font-bold"
              >
                ✕
              </button>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Subject-Wise Attendance Breakdown */}
            <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-black/10 pb-4">
                <div>
                  <h3 className="font-display font-semibold text-xl text-[#12281A]">
                    Live Subject Attendance Ledger
                  </h3>
                  <p className="text-xs text-[#12281A]/60 mt-0.5">
                    Requires valid instructor 6-digit OTP + classroom physical geofence lock.
                  </p>
                </div>
                <div className="text-xs font-mono text-[#1E4D33] bg-[#E4EFDA] px-3 py-1.5 rounded-full font-bold">
                  Aggregate: 81.3%
                </div>
              </div>

              <div className="space-y-4">
                {attendance.map((sub) => {
                  const isSelected = selectedSubjectId === sub.id;
                  return (
                    <div
                      key={sub.id}
                      className={`p-4 rounded-2xl border transition-all ${
                        isSelected
                          ? 'border-[#1E4D33] bg-[#E4EFDA]/30 shadow-xs'
                          : 'border-black/10 bg-[#FBFAF7] hover:bg-slate-50'
                      } flex flex-col sm:flex-row sm:items-center justify-between gap-4`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-[#1E4D33] bg-[#E4EFDA] px-2 py-0.5 rounded">
                            {sub.subjectCode}
                          </span>
                          <h4 className="font-semibold text-sm text-[#12281A]">{sub.subjectName}</h4>
                        </div>
                        <div className="text-xs text-[#12281A]/60 flex flex-wrap items-center gap-x-3 gap-y-1">
                          <span>Faculty: {sub.facultyName}</span>
                          <span>·</span>
                          <span>{sub.attendedClasses} / {sub.totalClasses} Lectures</span>
                          <span>·</span>
                          <span className="text-[11px] font-mono text-[#12281A]/50">{sub.lastUpdated}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div
                            className={`font-mono text-lg font-bold ${
                              sub.percentage >= 75
                                ? 'text-[#1E4D33]'
                                : sub.percentage >= 65
                                ? 'text-amber-600'
                                : 'text-rose-600'
                            }`}
                          >
                            {sub.percentage}%
                          </div>
                          <div className="text-[10px] text-[#12281A]/50 uppercase font-semibold">
                            {sub.status === 'Good' ? 'Exams Cleared' : 'Statutory Warning'}
                          </div>
                        </div>

                        <button
                          onClick={() => {
                            setSelectedSubjectId(sub.id);
                            setOtpError(null);
                          }}
                          className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs ${
                            isSelected
                              ? 'bg-[#1E4D33] text-white shadow-md'
                              : 'bg-white hover:bg-slate-100 text-[#12281A] border border-black/15'
                          }`}
                        >
                          <KeyRound className="w-3.5 h-3.5 text-[#42A85D]" />
                          <span>{isSelected ? 'Active Selection' : 'Mark with OTP'}</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Smart Geofenced OTP Verification Console */}
            <div className="lg:col-span-5 bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-5">
              <div className="border-b border-black/10 pb-4">
                <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Dual-Factor Verification</span>
                <h3 className="font-display font-semibold text-lg text-[#12281A] mt-1">
                  Geofence + OTP Check-In
                </h3>
              </div>

              {/* Physical Proximity Telemetry */}
              <div className="p-4 bg-[#FBFAF7] rounded-2xl border border-black/10 space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-[#12281A]/70 font-medium">Classroom Geofence:</span>
                  <span className="font-semibold text-[#12281A]">Smart Lecture Hall 301</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-[#12281A]/70 font-medium">GPS Location:</span>
                  <span className="font-mono text-[11px] text-[#1E4D33]">23.2599° N, 77.4126° E</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-[#12281A]/70 font-medium">Proximity Distance:</span>
                  <span className={`font-mono font-bold ${studentDistance <= 50 ? 'text-[#1E4D33]' : 'text-rose-600'}`}>
                    {studentDistance}m from lectern
                  </span>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-black/5">
                  <span className="text-[#12281A]/70 font-medium">Geofence Status:</span>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 ${
                      studentDistance <= 50
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    <span className={`w-1.5 h-1.5 rounded-full ${studentDistance <= 50 ? 'bg-emerald-600 animate-pulse' : 'bg-rose-600'}`}></span>
                    <span>{studentDistance <= 50 ? 'Within 50m Boundary (Lock Acquired)' : 'Outside 50m Perimeter (Proxy Blocked)'}</span>
                  </span>
                </div>

                {/* Location Simulation Toggle (Allows testing proxy prevention!) */}
                <div className="pt-2 border-t border-black/5">
                  <span className="text-[11px] text-[#12281A]/50 block mb-1.5 font-semibold">Simulate Your Device Location:</span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setStudentDistance(14.2);
                        setOtpError(null);
                      }}
                      className={`p-2 rounded-xl text-[11px] font-bold border transition-colors cursor-pointer text-center ${
                        studentDistance <= 50
                          ? 'bg-[#1E4D33] text-white border-[#1E4D33]'
                          : 'bg-white hover:bg-slate-100 text-slate-700 border-black/10'
                      }`}
                    >
                      📍 Inside Hall (14.2m)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setStudentDistance(120.5);
                        setOtpError(null);
                      }}
                      className={`p-2 rounded-xl text-[11px] font-bold border transition-colors cursor-pointer text-center ${
                        studentDistance > 50
                          ? 'bg-rose-700 text-white border-rose-700'
                          : 'bg-white hover:bg-slate-100 text-slate-700 border-black/10'
                      }`}
                    >
                      📍 Outside Campus (120m)
                    </button>
                  </div>
                </div>
              </div>

              {/* 6-Digit OTP Entry Form */}
              <div className="space-y-4 pt-1">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-[#12281A]">
                      Enter 6-Digit Lecture OTP
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setEnteredOtp(DEFAULT_ACTIVE_LECTURE_OTP);
                        setOtpError(null);
                      }}
                      className="text-xs text-[#1E4D33] hover:underline font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <span>Auto-Fill Current OTP ({DEFAULT_ACTIVE_LECTURE_OTP})</span>
                    </button>
                  </div>

                  <input
                    type="text"
                    maxLength={6}
                    value={enteredOtp}
                    onChange={(e) => setEnteredOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    placeholder="Enter 6-digit code (e.g. 849201)"
                    className="w-full tracking-[0.4em] font-mono text-center text-xl font-bold p-3 border border-black/20 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#1E4D33] bg-[#FBFAF7]"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => handleVerifyOtpAttendance()}
                  disabled={isVerifyingOtp}
                  className="w-full py-3 bg-[#1E4D33] hover:bg-[#2A6647] active:scale-95 text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md disabled:opacity-50"
                >
                  <ShieldCheck className="w-4 h-4 text-emerald-300" />
                  <span>
                    {isVerifyingOtp ? 'Verifying Coordinates & OTP...' : 'Verify Geofence & Mark Attendance'}
                  </span>
                </button>

                <p className="text-[11px] text-[#12281A]/50 text-center leading-relaxed">
                  Both physical GPS presence within 50m of Smart Hall 301 and the instructor's live 6-digit OTP are strictly verified on the central ledger.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 3: FINANCIAL LEDGER & PAYMENTS */}
      {/* ========================================================================= */}
      {activeSubTab === 'financials' && (
        <div className="space-y-6">
          {paymentSuccessReceipt && (
            <div className="p-4 bg-[#E4EFDA] border border-[#42A85D]/40 text-[#1E4D33] rounded-2xl text-xs flex items-center justify-between gap-3 animate-fade-in">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-[#42A85D] shrink-0" />
                <div>
                  <strong>Payment Successful!</strong> Receipt #{paymentSuccessReceipt.receiptNo} digitally signed and anchored.
                </div>
              </div>
              <button
                onClick={() => window.print()}
                className="px-3 py-1.5 bg-[#1E4D33] text-white rounded-lg font-semibold flex items-center gap-1 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Invoice</span>
              </button>
            </div>
          )}

          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-black/10 pb-4">
              <div>
                <h3 className="font-display font-semibold text-xl text-[#12281A]">
                  Student Financial Ledger & Dues
                </h3>
                <p className="text-xs text-[#12281A]/60 mt-0.5">
                  Automated reconciliation with MPOnline Treasury and instant tax invoice issuance.
                </p>
              </div>
              <div className="text-xs font-mono font-bold text-amber-700 bg-amber-50 px-3.5 py-1.5 rounded-full border border-amber-200">
                Total Pending Dues: ₹4,700
              </div>
            </div>

            <div className="divide-y divide-black/5">
              {fees.map((fee) => (
                <div key={fee.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm text-[#12281A]">{fee.title}</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        fee.status === 'Paid' ? 'bg-[#E4EFDA] text-[#1E4D33]' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {fee.status}
                      </span>
                    </div>
                    <div className="text-xs text-[#12281A]/60 flex items-center gap-3">
                      <span>Category: {fee.category}</span>
                      <span>·</span>
                      <span>Due: {fee.dueDate}</span>
                      {fee.receiptNo && (
                        <>
                          <span>·</span>
                          <span className="font-mono font-semibold text-[#1E4D33]">Receipt: {fee.receiptNo}</span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="font-mono text-lg font-bold text-[#12281A]">
                      ₹{fee.amount.toLocaleString()}
                    </div>
                    {fee.status === 'Pending' ? (
                      <button
                        onClick={() => setActiveFeeToPay(fee)}
                        className="px-4 py-2 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                      >
                        Pay Now
                      </button>
                    ) : (
                      <button
                        onClick={() => window.print()}
                        className="px-3.5 py-2 border border-black/10 hover:bg-slate-50 text-[#12281A] rounded-xl text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Tax Invoice</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 4: CAMPUS LOGISTICS & OUT-PASS */}
      {/* ========================================================================= */}
      {activeSubTab === 'logistics' && (
        <div className="space-y-6">
          {outpassAutoApprovedNotice && (
            <div className="p-4 bg-[#E4EFDA] border border-[#42A85D]/40 text-[#1E4D33] rounded-2xl text-xs flex items-center gap-3 animate-fade-in">
              <CheckCircle2 className="w-5 h-5 text-[#42A85D] shrink-0" />
              <div>{outpassAutoApprovedNotice}</div>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Out-pass Request Form */}
            <div className="lg:col-span-5 bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-5">
              <div className="border-b border-black/10 pb-4">
                <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Hostel Living Operations</span>
                <h3 className="font-display font-semibold text-lg text-[#12281A] mt-1">
                  Apply for Digital Out-Pass
                </h3>
                <p className="text-xs text-[#12281A]/60 mt-0.5">
                  Auto-approval enabled if scholar has &gt;6.0 CGPA and verified guardian consent OTP.
                </p>
              </div>

              <form onSubmit={handleApplyHostelPass} className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-[#12281A] mb-1">Destination Address & City</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Home (Indore, MP)"
                    value={outpassDest}
                    onChange={(e) => setOutpassDest(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-black/15 bg-white text-xs outline-none focus:border-[#1E4D33]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#12281A] mb-1">Purpose of Leave</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Attending family wedding & health checkup"
                    value={outpassPurpose}
                    onChange={(e) => setOutpassPurpose(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-black/15 bg-white text-xs outline-none focus:border-[#1E4D33]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#12281A] mb-1">Duration & Departure / Return Timings</label>
                  <input
                    type="text"
                    required
                    value={outpassDates}
                    onChange={(e) => setOutpassDates(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-black/15 bg-white text-xs outline-none focus:border-[#1E4D33]"
                  />
                </div>

                <div className="p-3 bg-[#FBFAF7] rounded-xl border border-black/10 text-[11px] text-[#12281A]/70 flex items-center gap-2">
                  <Check className="w-4 h-4 text-[#42A85D] shrink-0" />
                  <span>Pre-verified guardian: Smt. Meenakshi Sharma (+91 98260 54321)</span>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit Digital Out-Pass Application</span>
                </button>
              </form>
            </div>

            {/* Out-Pass History & Mess Schedule */}
            <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-6">
              <div>
                <h3 className="font-display font-semibold text-xl text-[#12281A]">
                  Out-Pass History & Gate Clearances
                </h3>
                <p className="text-xs text-[#12281A]/60 mt-0.5">
                  Verifiable digital out-pass authenticated at campus security turnstiles upon exit/re-entry.
                </p>
              </div>

              <div className="space-y-3">
                {hostelPasses.map((pass) => (
                  <div key={pass.id} className="p-4 rounded-2xl border border-black/10 bg-[#FBFAF7] text-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="font-semibold text-sm text-[#12281A]">
                        {pass.id} · {pass.destination}
                      </div>
                      <span className={`px-2.5 py-0.5 rounded font-bold text-[10px] ${
                        pass.status === 'Approved' ? 'bg-[#E4EFDA] text-[#1E4D33]' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {pass.status} {pass.autoApproved && '(Auto-Approved)'}
                      </span>
                    </div>
                    <div className="text-[#12281A]/70 text-[11px] flex flex-wrap items-center gap-3">
                      <span>Purpose: {pass.purpose}</span>
                      <span>·</span>
                      <span>From: {pass.fromDate}</span>
                      <span>·</span>
                      <span>To: {pass.toDate}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-black/10">
                <h4 className="font-semibold text-sm text-[#12281A] mb-3">Hostel Mess Dining Status</h4>
                <div className="grid grid-cols-4 gap-2 text-center text-xs">
                  <div className="p-2.5 bg-[#E4EFDA] rounded-xl border border-[#42A85D]/30">
                    <div className="font-bold text-[#1E4D33]">Breakfast</div>
                    <div className="text-[10px] text-[#12281A]/60">07:30 - 09:30</div>
                    <div className="text-[10px] font-bold text-[#42A85D] mt-1">Attended ✓</div>
                  </div>
                  <div className="p-2.5 bg-[#E4EFDA] rounded-xl border border-[#42A85D]/30">
                    <div className="font-bold text-[#1E4D33]">Lunch</div>
                    <div className="text-[10px] text-[#12281A]/60">12:30 - 14:30</div>
                    <div className="text-[10px] font-bold text-[#42A85D] mt-1">Attended ✓</div>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-xl border border-black/10">
                    <div className="font-bold text-[#12281A]">Evening Snacks</div>
                    <div className="text-[10px] text-[#12281A]/60">17:00 - 18:00</div>
                    <div className="text-[10px] text-[#12281A]/50 mt-1">Opens 5 PM</div>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-xl border border-black/10">
                    <div className="font-bold text-[#12281A]">Dinner</div>
                    <div className="text-[10px] text-[#12281A]/60">20:00 - 22:00</div>
                    <div className="text-[10px] text-[#12281A]/50 mt-1">Menu: Paneer Butter</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 5: TRANSIT & BUS GPS TELEMETRY */}
      {/* ========================================================================= */}
      {activeSubTab === 'transit' && (
        <div className="space-y-6">
          {bookedBusSeat && (
            <div className="p-4 bg-[#E4EFDA] border border-[#42A85D]/40 text-[#1E4D33] rounded-2xl text-xs flex items-center gap-3 animate-fade-in">
              <CheckCircle2 className="w-5 h-5 text-[#42A85D] shrink-0" />
              <div>{bookedBusSeat}</div>
            </div>
          )}

          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-black/10 pb-4">
              <div>
                <h3 className="font-display font-semibold text-xl text-[#12281A]">
                  Real-Time University Transit & Bus Tracking
                </h3>
                <p className="text-xs text-[#12281A]/60 mt-0.5">
                  Live GPS telemetry, stop-by-stop ETA, and seat reservation engine.
                </p>
              </div>
              <div className="text-xs font-mono text-[#1E4D33] bg-[#E4EFDA] px-3.5 py-1.5 rounded-full font-bold">
                18 Active Fleet Units Connected
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {busRoutes.map((bus) => (
                <div
                  key={bus.id}
                  className="p-5 rounded-2xl border border-black/10 bg-[#FBFAF7] space-y-4 text-xs flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-sm text-[#1E4D33] bg-[#E4EFDA] px-2.5 py-1 rounded-lg">
                        {bus.routeNumber}
                      </span>
                      <span className="px-2 py-0.5 rounded font-bold text-[10px] bg-emerald-100 text-emerald-800">
                        {bus.status}
                      </span>
                    </div>

                    <div>
                      <h4 className="font-bold text-sm text-[#12281A]">{bus.routeName}</h4>
                      <p className="text-[11px] text-[#12281A]/60 mt-0.5">Vehicle: {bus.busNumber}</p>
                    </div>

                    <div className="p-3 bg-white rounded-xl border border-black/5 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[#12281A]/60">Next Stop:</span>
                        <span className="font-semibold text-[#12281A]">{bus.nextStop}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-[#12281A]/60">Estimated Arrival:</span>
                        <span className="font-mono font-bold text-[#1E4D33]">{bus.etaMinutes} mins</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-[#12281A]/60">Seats Available:</span>
                        <span className="font-mono font-semibold text-[#12281A]">
                          {bus.totalSeats - bus.occupiedSeats} / {bus.totalSeats}
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleBookBusSeat(bus.id, bus.routeNumber)}
                    disabled={bus.occupiedSeats >= bus.totalSeats}
                    className="w-full py-2.5 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-xl font-semibold transition-colors cursor-pointer disabled:opacity-50"
                  >
                    Reserve Route Seat
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 6: SLA-MONITORED GRIEVANCE REDRESSAL */}
      {/* ========================================================================= */}
      {activeSubTab === 'grievances' && (
        <div className="space-y-6">
          {grievanceSuccessMsg && (
            <div className="p-4 bg-[#E4EFDA] border border-[#42A85D]/40 text-[#1E4D33] rounded-2xl text-xs flex items-center gap-3 animate-fade-in">
              <CheckCircle2 className="w-5 h-5 text-[#42A85D] shrink-0" />
              <div>Ticket lodged successfully! Track countdown under 48-Hour SLA Guarantee.</div>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Lodge New Ticket */}
            <div className="lg:col-span-5 bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-5">
              <div className="border-b border-black/10 pb-4">
                <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Multi-Tier Escalation</span>
                <h3 className="font-display font-semibold text-lg text-[#12281A] mt-1">
                  Lodge SLA-Monitored Grievance
                </h3>
                <p className="text-xs text-[#12281A]/60 mt-0.5">
                  Tickets exceeding 48 hours auto-escalate to Dean of Academic Affairs.
                </p>
              </div>

              <form onSubmit={handleSubmitGrievance} className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-[#12281A] mb-1">Grievance Category</label>
                  <select
                    value={newGrievanceCategory}
                    onChange={(e: any) => setNewGrievanceCategory(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-black/15 bg-white text-xs outline-none focus:border-[#1E4D33]"
                  >
                    <option value="Academic">Academic (Grading, Re-totaling, Lab)</option>
                    <option value="Hostel">Hostel Living & Quiet Hours</option>
                    <option value="Ragging">Anti-Ragging / Disciplinary (Zero Tolerance)</option>
                    <option value="Mess">Mess Food Quality & Nutrition</option>
                    <option value="Infrastructure">Infrastructure & Wi-Fi</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#12281A] mb-1">Subject Brief</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Compiler Design quiz marks un-evaluated"
                    value={newGrievanceSubject}
                    onChange={(e) => setNewGrievanceSubject(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-black/15 bg-white text-xs outline-none focus:border-[#1E4D33]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#12281A] mb-1">Priority Level</label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['Urgent', 'High', 'Medium'] as const).map((p) => (
                      <button
                        type="button"
                        key={p}
                        onClick={() => setNewGrievancePriority(p)}
                        className={`py-2 rounded-lg font-semibold transition-colors cursor-pointer ${
                          newGrievancePriority === p
                            ? 'bg-[#1E4D33] text-white'
                            : 'bg-slate-100 hover:bg-slate-200 text-[#12281A]'
                        }`}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-[#12281A] mb-1">Detailed Description & Evidence</label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Provide specific lecture date, question numbers, or room numbers..."
                    value={newGrievanceDesc}
                    onChange={(e) => setNewGrievanceDesc(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-black/15 bg-white text-xs outline-none focus:border-[#1E4D33] resize-none"
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit Ticket with SLA Guarantee</span>
                </button>
              </form>
            </div>

            {/* Active Tickets Queue */}
            <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-6">
              <div>
                <h3 className="font-display font-semibold text-xl text-[#12281A]">
                  Active Grievance Tickets & Resolution Countdowns
                </h3>
                <p className="text-xs text-[#12281A]/60 mt-0.5">
                  Track department resolution progress and escalation tiers in real time.
                </p>
              </div>

              <div className="space-y-4">
                {grievances.map((ticket) => (
                  <div key={ticket.id} className="p-5 rounded-2xl border border-black/10 bg-[#FBFAF7] space-y-3 text-xs">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-xs text-[#1E4D33] bg-[#E4EFDA] px-2 py-0.5 rounded">
                          {ticket.id}
                        </span>
                        <span className="font-bold text-sm text-[#12281A]">{ticket.subject}</span>
                      </div>
                      <span className={`px-2.5 py-0.5 rounded font-bold text-[10px] ${
                        ticket.status === 'Resolved'
                          ? 'bg-emerald-100 text-emerald-800'
                          : ticket.status === 'Escalated'
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {ticket.status}
                      </span>
                    </div>

                    <p className="text-[#12281A]/70 text-[11px] leading-relaxed">
                      {ticket.description}
                    </p>

                    <div className="pt-2 border-t border-black/5 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                      <div className="text-[#12281A]/60">
                        Assigned Tier: <strong className="text-[#12281A]">{ticket.escalationTier}</strong>
                      </div>
                      {ticket.status !== 'Resolved' ? (
                        <div className="flex items-center gap-1.5 font-mono text-[#1E4D33] font-bold">
                          <Clock className="w-3.5 h-3.5 text-[#42A85D]" />
                          <span>{ticket.slaHoursRemaining}h remaining until Dean escalation</span>
                        </div>
                      ) : (
                        <span className="text-emerald-700 font-bold">Resolution Confirmed ✓</span>
                      )}
                    </div>

                    {ticket.resolutionRemarks && (
                      <div className="p-2.5 bg-white rounded-xl border border-black/5 text-[11px] text-[#12281A]/80">
                        <strong>Official Remarks:</strong> {ticket.resolutionRemarks}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 7: TAMPER-PROOF DOCUMENT VAULT */}
      {/* ========================================================================= */}
      {activeSubTab === 'vault' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-black/10 pb-4">
              <div>
                <h3 className="font-display font-semibold text-xl text-[#12281A]">
                  Tamper-Proof Document Vault (DigiLocker Anchored)
                </h3>
                <p className="text-xs text-[#12281A]/60 mt-0.5">
                  Verifiable digital degrees, semester transcripts, and bonafide credentials signed with SHA-256 hashes.
                </p>
              </div>
              <div className="text-xs font-mono text-[#1E4D33] bg-[#E4EFDA] px-3.5 py-1.5 rounded-full font-bold">
                100% Cryptographically Verified
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {INITIAL_CERTIFICATES.map((cert) => (
                <div
                  key={cert.id}
                  className="p-5 rounded-2xl border border-black/10 bg-[#FBFAF7] space-y-4 text-xs flex flex-col justify-between"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-xs font-bold text-[#1E4D33] bg-[#E4EFDA] px-2 py-0.5 rounded">
                        {cert.type}
                      </span>
                      <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-bold">
                        DigiLocker Synced ✓
                      </span>
                    </div>

                    <h4 className="font-bold text-sm text-[#12281A]">{cert.title}</h4>
                    <p className="text-[#12281A]/60 text-[11px]">
                      Issued to {cert.issuedTo} ({cert.enrollmentNo}) on {cert.issueDate}
                    </p>

                    <div className="p-2.5 bg-white rounded-xl border border-black/5 font-mono text-[10px] text-[#12281A]/60 truncate">
                      SHA-256: {cert.verificationHash}
                    </div>
                  </div>

                  <button
                    onClick={() => onOpenCertificateModal(cert)}
                    className="w-full py-2.5 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-xl font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>View & Verify Cryptographic Certificate</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 8: AI REMEDIAL STUDY RECOMMENDATIONS */}
      {/* ========================================================================= */}
      {activeSubTab === 'ai_assistant' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-black/10 pb-4">
              <div>
                <h3 className="font-display font-semibold text-xl text-[#12281A]">
                  AI Remedial Study & Assessment Pipeline
                </h3>
                <p className="text-xs text-[#12281A]/60 mt-0.5">
                  Personalized micro-learning recommendations generated based on continuous evaluation quiz results.
                </p>
              </div>
              <button
                onClick={handleOpenAI}
                className="px-4 py-2 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#42A85D]" />
                <span>Launch Ask Icecream Assistant</span>
              </button>
            </div>

            <div className="space-y-4">
              {learningRecs.map((rec) => (
                <div key={rec.id} className="p-5 rounded-2xl border border-black/10 bg-[#FBFAF7] space-y-3 text-xs">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-mono text-xs font-bold text-[#1E4D33] bg-[#E4EFDA] px-2 py-0.5 rounded">
                        {rec.subject}
                      </span>
                      <h4 className="font-semibold text-sm text-[#12281A] mt-1">{rec.topic}</h4>
                    </div>
                    <span className="px-2.5 py-0.5 bg-amber-100 text-amber-800 rounded font-bold text-[10px]">
                      {rec.difficulty} · ~{rec.estimatedHours} hrs
                    </span>
                  </div>

                  <p className="text-[#12281A]/70 text-[11px] leading-relaxed">
                    <strong>AI Diagnostic:</strong> {rec.reason}
                  </p>

                  <div className="pt-2 flex items-center justify-between border-t border-black/5">
                    <span className="text-xs text-[#1E4D33] font-semibold">{rec.resourceType}: {rec.linkTitle}</span>
                    <button
                      onClick={handleOpenAI}
                      className="text-xs font-semibold text-[#1E4D33] hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <span>Study with Icecream AI</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ============ PAYMENT GATEWAY MODAL ============ */}
      {activeFeeToPay && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 cursor-pointer animate-fade-in"
          onClick={(e) => {
            if (e.target === e.currentTarget) setActiveFeeToPay(null);
          }}
        >
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-5 border border-black/10 shadow-2xl cursor-default relative">
            <div className="flex items-center justify-between border-b border-black/10 pb-3">
              <div>
                <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Integrated Gateway</span>
                <h4 className="font-display font-semibold text-lg text-[#12281A]">Clear University Dues</h4>
              </div>
              <button
                onClick={() => setActiveFeeToPay(null)}
                className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 hover:text-slate-900 transition-colors cursor-pointer"
                title="Close (Esc)"
                aria-label="Close"
              >
                <span className="text-base font-bold leading-none">✕</span>
              </button>
            </div>

            <div className="p-4 bg-[#FBFAF7] rounded-2xl border border-black/10 space-y-1 text-xs">
              <div className="font-semibold text-[#12281A]">{activeFeeToPay.title}</div>
              <div className="text-[#12281A]/60">Due Date: {activeFeeToPay.dueDate}</div>
              <div className="font-mono text-2xl font-bold text-[#1E4D33] pt-2">
                ₹{activeFeeToPay.amount.toLocaleString()}
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <span className="font-semibold text-[#12281A]">Select Payment Rail</span>
              <div className="grid grid-cols-3 gap-2">
                {(['upi', 'card', 'netbanking'] as const).map((method) => (
                  <button
                    key={method}
                    onClick={() => setPaymentMethod(method)}
                    className={`py-2 px-3 rounded-xl font-semibold uppercase text-[10px] transition-colors cursor-pointer ${
                      paymentMethod === method
                        ? 'bg-[#1E4D33] text-white'
                        : 'bg-slate-100 hover:bg-slate-200 text-[#12281A]'
                    }`}
                  >
                    {method}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex gap-2.5 pt-1">
              <button
                onClick={handleConfirmPayment}
                disabled={paymentProcessing}
                className="flex-1 py-3 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm disabled:opacity-50"
              >
                {paymentProcessing ? 'Reconciling with Treasury...' : `Pay ₹${activeFeeToPay.amount.toLocaleString()} & Issue Invoice`}
              </button>

              <button
                onClick={() => setActiveFeeToPay(null)}
                className="px-4 py-3 border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============ HALL TICKET MODAL ============ */}
      {showHallTicket && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 cursor-pointer animate-fade-in"
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowHallTicket(false);
          }}
        >
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-5 border border-black/10 shadow-2xl cursor-default relative">
            <div className="flex items-center justify-between border-b border-black/10 pb-3">
              <div>
                <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Controller of Examinations</span>
                <h4 className="font-display font-semibold text-lg text-[#12281A]">End-Semester Examination Hall Ticket</h4>
              </div>
              <button
                onClick={() => setShowHallTicket(false)}
                className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 hover:text-slate-900 transition-colors cursor-pointer"
                title="Close (Esc)"
                aria-label="Close"
              >
                <span className="text-base font-bold leading-none">✕</span>
              </button>
            </div>

            <div className="p-4 bg-[#FBFAF7] rounded-2xl border border-black/10 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span>Hall Ticket Number:</span>
                <span className="font-mono font-bold text-[#1E4D33]">{INITIAL_EXAM_REGISTRATION.hallTicketNo}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Candidate Name:</span>
                <span className="font-semibold text-[#12281A]">{currentUser?.name || 'Aarav Sharma'}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Enrollment ID:</span>
                <span className="font-mono">{currentUser?.enrollmentId || '0101CS221045'}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Assigned Center:</span>
                <span className="font-semibold">{INITIAL_EXAM_REGISTRATION.center}</span>
              </div>
              <div className="pt-2 border-t border-black/5 font-mono text-[10px] text-[#12281A]/60 truncate">
                Admit Hash: {INITIAL_EXAM_REGISTRATION.admitCardHash}
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => window.print()}
                className="flex-1 py-2.5 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Official Admit Card</span>
              </button>
              <button
                onClick={() => setShowHallTicket(false)}
                className="px-4 py-2.5 border border-black/10 hover:bg-slate-50 text-[#12281A] rounded-xl text-xs font-semibold cursor-pointer"
              >
                Close (Esc)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
