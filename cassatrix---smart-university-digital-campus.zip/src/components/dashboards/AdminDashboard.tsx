import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { supabase, SUPABASE_SQL_SCHEMA, SUPABASE_SEED_SQL, testSupabaseConnection, seedSupabaseDatabase, pingSupabaseSystemStatus } from '../../lib/supabase';
import {
  INITIAL_GRIEVANCES,
  INITIAL_HOSTEL_PASSES,
  INITIAL_BUS_ROUTES,
  RBAC_ROLE_CONFIGS,
} from '../../data/mockData';
import {
  ShieldCheck,
  Building2,
  Users,
  CreditCard,
  FileCheck2,
  CheckCircle2,
  TrendingDown,
  Sparkles,
  Award,
  Clock,
  Lock,
  Layers,
  Check,
  Bed,
  Bus,
  AlertTriangle,
  Send,
  Zap,
  Database,
  Copy,
} from 'lucide-react';
import { RbacRoleConfig, GrievanceTicket } from '../../types';

export const AdminDashboard: React.FC = () => {
  const { currentUser } = useAuth();

  // Active Sub-Tab
  const [activeTab, setActiveTab] = useState<'governance' | 'rbac' | 'credentials' | 'escalations' | 'infrastructure' | 'supabase'>('governance');
  const [supabaseStatus, setSupabaseStatus] = useState<{ connected: boolean; message: string }>({
    connected: false,
    message: 'Testing Supabase Database connection...',
  });
  const [copiedSchema, setCopiedSchema] = useState(false);
  const [copiedSeedSql, setCopiedSeedSql] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);
  const [seedNotice, setSeedNotice] = useState<{ success: boolean; message: string } | null>(null);

  useEffect(() => {
    testSupabaseConnection().then(setSupabaseStatus);
    pingSupabaseSystemStatus();
  }, []);

  // RBAC Matrix State
  const [rbacRoles, setRbacRoles] = useState<RbacRoleConfig[]>(RBAC_ROLE_CONFIGS);
  const [rbacUpdatedNotice, setRbacUpdatedNotice] = useState(false);

  // Batch Cryptographic Credential Issuance Engine
  const [batchIssuing, setBatchIssuing] = useState(false);
  const [batchSuccessNotice, setBatchSuccessNotice] = useState<string | null>(null);
  const [issuedBatchCount, setIssuedBatchCount] = useState(420);

  // Escalated Grievances Queue (Dean / Registrar Tier)
  const [escalatedTickets, setEscalatedTickets] = useState<GrievanceTicket[]>(
    INITIAL_GRIEVANCES.filter((g) => g.status === 'Escalated' || g.escalationTier.includes('Tier 2') || g.escalationTier.includes('Tier 3'))
  );
  const [escalationResolutionMsg, setEscalationResolutionMsg] = useState<string | null>(null);

  // Infrastructure Management States
  const [hostelMaintenanceQueue, setHostelMaintenanceQueue] = useState([
    { id: 'MAINT-401', block: 'Aryabhata Hall (H-3)', issue: 'Corridor Lighting & Sensor Replacement', priority: 'Medium', status: 'In Progress' },
    { id: 'MAINT-402', block: 'Gargi Hall (H-1)', issue: 'Solar Water Geyser Pressure Calibration', priority: 'High', status: 'Pending' },
    { id: 'MAINT-403', block: 'CV Raman Hall (H-4)', issue: 'Water Purification Filter Replacement', priority: 'Urgent', status: 'Resolved' },
  ]);

  const [messAuditLogs, setMessAuditLogs] = useState([
    { mess: 'Mess Block 1 (Central)', rating: '4.8 / 5', hygieneScore: '96%', sampleTest: 'Passed (ISO 22000)', date: 'Today, 08:30 AM' },
    { mess: 'Mess Block 2 (North)', rating: '4.4 / 5', hygieneScore: '89%', sampleTest: 'Passed', date: 'Yesterday' },
    { mess: 'Mess Block 3 (Girls Wing)', rating: '4.9 / 5', hygieneScore: '98%', sampleTest: 'Passed (A+)', date: 'Today, 08:00 AM' },
  ]);

  // Toggle RBAC permission
  const handleTogglePermission = (roleId: string, permissionKey: keyof RbacRoleConfig) => {
    setRbacRoles((prev) =>
      prev.map((role) =>
        role.roleId === roleId
          ? { ...role, [permissionKey]: !role[permissionKey] }
          : role
      )
    );
    setRbacUpdatedNotice(true);
    setTimeout(() => setRbacUpdatedNotice(false), 3000);
  };

  // Run Batch SHA-256 Signer
  const handleBatchIssueCredentials = () => {
    setBatchIssuing(true);
    setBatchSuccessNotice(null);
    setTimeout(() => {
      setBatchIssuing(false);
      setIssuedBatchCount((prev) => prev + 120);
      setBatchSuccessNotice(
        'Batch Execution Complete: 120 B.Tech 2026 degrees signed with SHA-256 cryptographic hashes and synchronized to National DigiLocker API!'
      );
    }, 1800);
  };

  // Resolve Dean Escalation
  const handleResolveEscalation = (ticketId: string) => {
    setEscalatedTickets((prev) =>
      prev.map((t) =>
        t.id === ticketId
          ? {
              ...t,
              status: 'Resolved',
              resolutionRemarks: 'Executive intervention completed by Dean Academic Council. Corrective directive issued.',
            }
          : t
      )
    );
    setEscalationResolutionMsg(`Grievance ${ticketId} resolved with Dean Executive Signature.`);
    setTimeout(() => setEscalationResolutionMsg(null), 4000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fade-in text-[#12281A]">
      {/* ============ BANNER ============ */}
      <div className="bg-[#12281A] text-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-96 bg-gradient-to-l from-[#42A85D]/15 to-transparent pointer-events-none"></div>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2 text-xs uppercase tracking-widest text-[#42A85D] font-mono">
              <span className="w-2 h-2 rounded-full bg-[#42A85D] animate-pulse"></span>
              <span>University Executive Governance & Administration</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-display font-light text-white tracking-tight">
              {currentUser?.role === 'admin' ? currentUser.name : 'Dr. Rajeshwar Rao'}
            </h1>
            <p className="text-xs text-white/70 mt-1.5 font-mono">
              {currentUser?.role === 'admin' ? currentUser.roleTitle : 'Registrar & Dean of Digital Governance'} · Governance Council ID: <strong className="text-[#42A85D]">ADM-GOV-001</strong>
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/10 text-xs text-right">
            <div className="text-white/60 font-semibold">Institutional Authority:</div>
            <div className="text-base font-bold text-[#42A85D] mt-0.5">MPOnline Integrated Hub</div>
            <div className="text-[11px] text-white/70">All 14 Engineering & Management Departments Live</div>
          </div>
        </div>
      </div>

      {/* ============ NAVIGATION SUB-TABS ============ */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-black/10 text-xs font-semibold text-[#12281A]/60 max-w-full touch-pan-x scrollbar-none">
        {[
          { id: 'governance', label: '1. Governance & Financial Analytics', icon: Layers },
          { id: 'rbac', label: '2. Role-Based Access Control (RBAC)', icon: Lock },
          { id: 'credentials', label: '3. Cryptographic Credential Issuance', icon: Award },
          { id: 'escalations', label: '4. 48h SLA Escalation Oversight', icon: AlertTriangle },
          { id: 'infrastructure', label: '5. Campus Living & Transit Logistics', icon: Building2 },
          { id: 'supabase', label: '6. Supabase Database & Schema', icon: Database },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 py-2.5 px-4 rounded-full whitespace-nowrap transition-all duration-200 cursor-pointer ${
                isActive
                  ? 'bg-[#1E4D33] text-white shadow-md shadow-[#1E4D33]/20'
                  : 'hover:text-[#12281A] hover:bg-[#E4EFDA]/40'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* CAPABILITY 1: INSTITUTIONAL GOVERNANCE ANALYTICS */}
      {/* ========================================================================= */}
      {activeTab === 'governance' && (
        <div className="space-y-8">
          {/* Executive KPI Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-3xl border border-black/10 shadow-2xs">
              <span className="text-xs text-[#12281A]/50 font-semibold uppercase">Total Campus Enrolment</span>
              <div className="text-2xl font-display font-bold text-[#12281A] mt-1 font-mono">
                12,450
              </div>
              <p className="text-[11px] text-[#12281A]/60 mt-1">Across 32 Engineering & Doctoral Programs</p>
            </div>

            <div className="bg-white p-5 rounded-3xl border border-black/10 shadow-2xs">
              <span className="text-xs text-[#12281A]/50 font-semibold uppercase">Fee Collection Rate</span>
              <div className="text-2xl font-display font-bold text-[#1E4D33] mt-1 font-mono">
                94.6%
              </div>
              <p className="text-[11px] text-[#12281A]/60 mt-1">₹42.8 Cr reconciled via MPOnline Treasury</p>
            </div>

            <div className="bg-white p-5 rounded-3xl border border-black/10 shadow-2xs">
              <span className="text-xs text-[#12281A]/50 font-semibold uppercase">Grievance SLA Compliance</span>
              <div className="text-2xl font-display font-bold text-blue-600 mt-1 font-mono">
                97.2%
              </div>
              <p className="text-[11px] text-[#12281A]/60 mt-1">Average resolution latency: 31.4 hours</p>
            </div>

            <div className="bg-white p-5 rounded-3xl border border-black/10 shadow-2xs">
              <span className="text-xs text-[#12281A]/50 font-semibold uppercase">AI Dropout Interventions</span>
              <div className="text-2xl font-display font-bold text-[#42A85D] mt-1 font-mono">
                142 Scholars
              </div>
              <p className="text-[11px] text-[#12281A]/60 mt-1">At-risk students re-engaged via proctors</p>
            </div>
          </div>

          {/* Departmental Performance Matrix */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-black/10 pb-4">
              <div>
                <h3 className="font-display font-semibold text-xl text-[#12281A]">
                  Departmental Attendance & Risk Analytics
                </h3>
                <p className="text-xs text-[#12281A]/60 mt-0.5">
                  Real-time aggregation across lectures, labs, and faculty grading journals.
                </p>
              </div>
              <div className="text-xs font-mono text-[#1E4D33] bg-[#E4EFDA] px-3.5 py-1.5 rounded-full font-bold">
                Campus Mean Attendance: 83.4%
              </div>
            </div>

            <div className="divide-y divide-black/5 text-xs">
              {[
                { dept: 'Computer Science & Engineering', students: 1840, attendance: 86.2, feeReconciled: '₹8.4 Cr', dropoutRisk: 'Low (4.2%)' },
                { dept: 'Electronics & Communication', students: 1420, attendance: 82.5, feeReconciled: '₹6.2 Cr', dropoutRisk: 'Low (6.1%)' },
                { dept: 'Mechanical Engineering', students: 1100, attendance: 78.9, feeReconciled: '₹4.9 Cr', dropoutRisk: 'Moderate (9.4%)' },
                { dept: 'Civil Engineering', students: 950, attendance: 79.4, feeReconciled: '₹4.1 Cr', dropoutRisk: 'Moderate (8.7%)' },
                { dept: 'Management Studies (MBA)', students: 820, attendance: 89.1, feeReconciled: '₹5.6 Cr', dropoutRisk: 'Low (3.1%)' },
              ].map((row, idx) => (
                <div key={idx} className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="font-bold text-sm text-[#12281A]">{row.dept}</div>
                    <div className="text-[11px] text-[#12281A]/60 mt-0.5">
                      {row.students} Active Enrolled Scholars · Fees: {row.feeReconciled}
                    </div>
                  </div>

                  <div className="flex items-center gap-6 font-mono">
                    <div className="text-right">
                      <div className="text-[10px] text-[#12281A]/50 uppercase font-sans">Avg Attendance</div>
                      <div className="font-bold text-sm text-[#1E4D33]">{row.attendance}%</div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] text-[#12281A]/50 uppercase font-sans">Dropout Probability</div>
                      <div className="font-bold text-sm text-emerald-700">{row.dropoutRisk}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* CAPABILITY 2: ROLE-BASED ACCESS CONTROL (RBAC) */}
      {/* ========================================================================= */}
      {activeTab === 'rbac' && (
        <div className="space-y-6">
          {rbacUpdatedNotice && (
            <div className="p-4 bg-[#E4EFDA] border border-[#42A85D]/40 text-[#1E4D33] rounded-2xl text-xs flex items-center gap-3 animate-fade-in">
              <CheckCircle2 className="w-5 h-5 text-[#42A85D] shrink-0" />
              <div>RBAC permission matrix updated and broadcast across OAuth2 / JWT authorization layers!</div>
            </div>
          )}

          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-6">
            <div className="border-b border-black/10 pb-4">
              <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Security & Governance</span>
              <h3 className="font-display font-semibold text-xl text-[#12281A] mt-1">
                Role-Based Access Control (RBAC) Permission Matrix
              </h3>
              <p className="text-xs text-[#12281A]/60 mt-0.5">
                Toggle functional entitlements across students, faculty, guardians, and administrative officers.
              </p>
            </div>

            {/* Mobile horizontal scroll hint */}
            <div className="flex sm:hidden items-center justify-between text-[11px] text-[#1E4D33] bg-[#E4EFDA] px-3 py-1.5 rounded-xl font-medium">
              <span>← Swipe horizontally to review all role permissions →</span>
              <span className="font-mono text-[10px]">7 Controls</span>
            </div>

            <div className="overflow-x-auto max-w-full border border-black/10 rounded-2xl touch-pan-x">
              <table className="w-full text-xs text-left min-w-[720px]">
                <thead className="bg-[#FBFAF7] text-[#12281A]/70 uppercase font-mono text-[10px] border-b border-black/10">
                  <tr>
                    <th className="py-3 px-4">Portal Role</th>
                    <th className="py-3 px-4">Target Group & Active Users</th>
                    <th className="py-3 px-4 text-center">View Ledgers</th>
                    <th className="py-3 px-4 text-center">Override Attendance</th>
                    <th className="py-3 px-4 text-center">Sign Degrees</th>
                    <th className="py-3 px-4 text-center">Manage Logistics</th>
                    <th className="py-3 px-4 text-center">Resolve Escalations</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-black/5 font-sans">
                  {rbacRoles.map((role) => (
                    <tr key={role.roleId} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3.5 px-4 font-bold text-[#12281A]">
                        {role.roleTitle}
                      </td>
                      <td className="py-3.5 px-4 text-[#12281A]/70 text-[11px]">
                        {role.targetGroup}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <input
                          type="checkbox"
                          checked={role.canViewLedgers}
                          onChange={() => handleTogglePermission(role.roleId, 'canViewLedgers')}
                          className="rounded text-[#1E4D33]"
                        />
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <input
                          type="checkbox"
                          checked={role.canOverrideAttendance}
                          onChange={() => handleTogglePermission(role.roleId, 'canOverrideAttendance')}
                          className="rounded text-[#1E4D33]"
                        />
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <input
                          type="checkbox"
                          checked={role.canSignDegrees}
                          onChange={() => handleTogglePermission(role.roleId, 'canSignDegrees')}
                          className="rounded text-[#1E4D33]"
                        />
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <input
                          type="checkbox"
                          checked={role.canManageBuses}
                          onChange={() => handleTogglePermission(role.roleId, 'canManageBuses')}
                          className="rounded text-[#1E4D33]"
                        />
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <input
                          type="checkbox"
                          checked={role.canResolveEscalations}
                          onChange={() => handleTogglePermission(role.roleId, 'canResolveEscalations')}
                          className="rounded text-[#1E4D33]"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* CAPABILITY 3: BATCH CRYPTOGRAPHIC CREDENTIAL ISSUANCE */}
      {/* ========================================================================= */}
      {activeTab === 'credentials' && (
        <div className="space-y-6">
          {batchSuccessNotice && (
            <div className="p-4 bg-[#E4EFDA] border border-[#42A85D]/40 text-[#1E4D33] rounded-2xl text-xs flex items-center gap-3 animate-fade-in">
              <CheckCircle2 className="w-5 h-5 text-[#42A85D] shrink-0" />
              <div className="font-semibold">{batchSuccessNotice}</div>
            </div>
          )}

          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-black/10 pb-4">
              <div>
                <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Cryptographic Authority</span>
                <h3 className="font-display font-semibold text-xl text-[#12281A] mt-1">
                  Batch Digital Degree & Transcript Signer
                </h3>
                <p className="text-xs text-[#12281A]/60 mt-0.5">
                  Batch-hash credentials using SHA-256 and anchor to the National DigiLocker repository.
                </p>
              </div>

              <button
                onClick={handleBatchIssueCredentials}
                disabled={batchIssuing}
                className="px-5 py-2.5 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-xl text-xs font-semibold flex items-center gap-2 cursor-pointer shadow-sm disabled:opacity-50"
              >
                <Award className="w-4 h-4" />
                <span>{batchIssuing ? 'Generating SHA-256 Hashes...' : 'Batch Sign & Push to DigiLocker'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
              <div className="p-5 bg-[#FBFAF7] rounded-2xl border border-black/10 space-y-2">
                <span className="font-mono text-[10px] text-[#12281A]/50 uppercase">Total Degrees Anchored</span>
                <div className="font-mono text-2xl font-bold text-[#1E4D33]">{issuedBatchCount}</div>
                <div className="text-[11px] text-[#12281A]/60">Class of 2026 Graduating Cohort</div>
              </div>

              <div className="p-5 bg-[#FBFAF7] rounded-2xl border border-black/10 space-y-2">
                <span className="font-mono text-[10px] text-[#12281A]/50 uppercase">DigiLocker Sync Rate</span>
                <div className="font-mono text-2xl font-bold text-emerald-700">100.0%</div>
                <div className="text-[11px] text-[#12281A]/60">Zero hash collisions or rejections</div>
              </div>

              <div className="p-5 bg-[#FBFAF7] rounded-2xl border border-black/10 space-y-2">
                <span className="font-mono text-[10px] text-[#12281A]/50 uppercase">Cryptographic Standard</span>
                <div className="font-mono text-2xl font-bold text-[#12281A]">SHA-256</div>
                <div className="text-[11px] text-[#12281A]/60">ECDSA P-256 Digital Signature</div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-black/10 font-mono text-[11px] text-[#12281A]/70 space-y-1">
              <div><strong>Active Signing Certificate:</strong> CN=Cassatrix University Root CA, OU=Governance Council, O=MPOnline Higher Ed</div>
              <div><strong>Ledger Anchor:</strong> 0x9d4e5f7b8a1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e</div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* CAPABILITY 4: 48-HOUR SLA ESCALATION OVERSIGHT */}
      {/* ========================================================================= */}
      {activeTab === 'escalations' && (
        <div className="space-y-6">
          {escalationResolutionMsg && (
            <div className="p-4 bg-[#E4EFDA] border border-[#42A85D]/40 text-[#1E4D33] rounded-2xl text-xs flex items-center gap-3 animate-fade-in">
              <CheckCircle2 className="w-5 h-5 text-[#42A85D] shrink-0" />
              <div>{escalationResolutionMsg}</div>
            </div>
          )}

          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-6">
            <div className="border-b border-black/10 pb-4">
              <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Executive Redressal</span>
              <h3 className="font-display font-semibold text-xl text-[#12281A] mt-1">
                Dean & Registrar Grievance Escalation Desk
              </h3>
              <p className="text-xs text-[#12281A]/60 mt-0.5">
                Tickets automatically routed here when department heads fail to resolve issues within the 48-hour SLA window.
              </p>
            </div>

            <div className="space-y-4">
              {escalatedTickets.map((ticket) => (
                <div key={ticket.id} className="p-5 rounded-2xl border border-black/10 bg-[#FBFAF7] space-y-3 text-xs">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-xs text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                        {ticket.id}
                      </span>
                      <h4 className="font-bold text-sm text-[#12281A]">{ticket.subject}</h4>
                    </div>
                    <span className="px-2.5 py-0.5 bg-rose-100 text-rose-800 rounded font-bold text-[10px]">
                      {ticket.escalationTier}
                    </span>
                  </div>

                  <p className="text-[#12281A]/70 text-[11px]">{ticket.description}</p>

                  <div className="pt-2 border-t border-black/5 flex flex-wrap items-center justify-between gap-3 text-[11px]">
                    <div className="text-[#12281A]/60">
                      Lodge Date: {ticket.date} · Submitted by: {ticket.submittedBy}
                    </div>

                    {ticket.status !== 'Resolved' ? (
                      <button
                        onClick={() => handleResolveEscalation(ticket.id)}
                        className="px-4 py-1.5 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-xl font-semibold cursor-pointer shadow-xs"
                      >
                        Executive Dean Resolution Override
                      </button>
                    ) : (
                      <span className="text-emerald-700 font-bold">Resolved by Dean Order ✓</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* CAPABILITY 5: INFRASTRUCTURE & LOGISTICS MANAGEMENT */}
      {/* ========================================================================= */}
      {activeTab === 'infrastructure' && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Hostel Maintenance & Room Allotment */}
            <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-5">
              <div className="border-b border-black/10 pb-4">
                <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Hostel Administration</span>
                <h3 className="font-display font-semibold text-xl text-[#12281A] mt-1">
                  Hostel Maintenance & Allocations
                </h3>
              </div>

              <div className="space-y-3 text-xs">
                {hostelMaintenanceQueue.map((m) => (
                  <div key={m.id} className="p-4 rounded-2xl bg-[#FBFAF7] border border-black/10 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#12281A]">{m.block}</span>
                      <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                        m.status === 'Resolved' ? 'bg-[#E4EFDA] text-[#1E4D33]' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {m.status}
                      </span>
                    </div>
                    <p className="text-[#12281A]/70 text-[11px]">{m.issue}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Mess Food Quality Audit */}
            <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-5">
              <div className="border-b border-black/10 pb-4">
                <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Dining & Hygiene</span>
                <h3 className="font-display font-semibold text-xl text-[#12281A] mt-1">
                  Mess Food Quality & Inspection Logs
                </h3>
              </div>

              <div className="space-y-3 text-xs">
                {messAuditLogs.map((log, idx) => (
                  <div key={idx} className="p-4 rounded-2xl bg-[#FBFAF7] border border-black/10 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#12281A]">{log.mess}</span>
                      <span className="text-[#1E4D33] font-bold">{log.rating}</span>
                    </div>
                    <div className="text-[11px] text-[#12281A]/60 flex items-center justify-between">
                      <span>Hygiene: {log.hygieneScore} · Sample: {log.sampleTest}</span>
                      <span className="font-mono">{log.date}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* CAPABILITY 6: SUPABASE POSTGRESQL DATABASE & SCHEMA MANAGEMENT */}
      {/* ========================================================================= */}
      {activeTab === 'supabase' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-black/10 pb-4">
              <div>
                <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Cloud Backend & DBMS</span>
                <h3 className="font-display font-semibold text-xl text-[#12281A] mt-1">
                  Supabase PostgreSQL Database Management
                </h3>
                <p className="text-xs text-[#12281A]/60 mt-0.5">
                  Real-time database connection status, schema migrations, and Row-Level Security (RLS) policies.
                </p>
              </div>

              <div className={`px-3.5 py-1.5 rounded-full text-xs font-bold font-mono flex items-center gap-2 ${
                supabaseStatus.connected
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-amber-100 text-amber-900 border border-amber-300'
              }`}>
                <span className={`w-2 h-2 rounded-full ${supabaseStatus.connected ? 'bg-emerald-600 animate-ping' : 'bg-amber-600'}`}></span>
                <span>{supabaseStatus.connected ? 'Supabase Connected ✓' : 'Resilient Mode Active'}</span>
              </div>
            </div>

            <div className="p-4 bg-[#FBFAF7] rounded-2xl border border-black/10 text-xs space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="font-semibold text-[#12281A]">Database Status & Live Connection Test:</div>
                  <div className="font-mono text-[#1E4D33] text-[11px] mt-1 bg-white p-2.5 rounded-xl border border-black/5">
                    {supabaseStatus.message}
                  </div>
                </div>

                <button
                  onClick={async () => {
                    setIsSeeding(true);
                    setSeedNotice(null);
                    const res = await seedSupabaseDatabase();
                    setIsSeeding(false);
                    setSeedNotice(res);
                    const conn = await testSupabaseConnection();
                    setSupabaseStatus(conn);
                  }}
                  disabled={isSeeding}
                  className="px-4 py-2.5 bg-gradient-to-r from-[#1E4D33] to-[#2A6647] hover:from-[#2A6647] hover:to-[#42A85D] text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md transition-all shrink-0"
                >
                  <Zap className="w-4 h-4 text-emerald-300 animate-bounce" />
                  <span>{isSeeding ? 'Populating Database...' : '🚀 Seed Supabase Database'}</span>
                </button>
              </div>

              {seedNotice && (
                <div className={`p-3 rounded-xl border text-xs flex items-start gap-2 ${
                  seedNotice.success ? 'bg-emerald-50 text-emerald-900 border-emerald-200' : 'bg-amber-50 text-amber-900 border-amber-200'
                }`}>
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
                  <div>
                    <strong className="block font-bold">{seedNotice.success ? 'Seed Execution Successful!' : 'Notice'}</strong>
                    <span>{seedNotice.message}</span>
                  </div>
                </div>
              )}
            </div>

            {/* DDL SCHEMA */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-sm text-[#12281A]">1. Supabase SQL DDL Migration Script</h4>
                  <p className="text-xs text-[#12281A]/60">Run this script in your Supabase SQL Editor to initialize all 5 campus tables and RLS security policies.</p>
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(SUPABASE_SQL_SCHEMA);
                    setCopiedSchema(true);
                    setTimeout(() => setCopiedSchema(false), 2500);
                  }}
                  className="px-4 py-2 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  {copiedSchema ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSchema ? 'SQL Copied!' : 'Copy SQL Schema'}</span>
                </button>
              </div>

              <pre className="p-4 bg-[#12281A] text-emerald-400 font-mono text-[11px] rounded-2xl overflow-x-auto max-h-64 border border-black/10 shadow-inner leading-relaxed">
                {SUPABASE_SQL_SCHEMA}
              </pre>
            </div>

            {/* SEED DATA SQL */}
            <div className="space-y-3 pt-2 border-t border-black/10">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-sm text-[#12281A]">2. SQL Seed Data Script (Manual Insert Alternative)</h4>
                  <p className="text-xs text-[#12281A]/60">You can also copy and paste this seed SQL directly into your Supabase SQL Editor to populate sample records!</p>
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(SUPABASE_SEED_SQL);
                    setCopiedSeedSql(true);
                    setTimeout(() => setCopiedSeedSql(false), 2500);
                  }}
                  className="px-4 py-2 bg-[#12281A] hover:bg-[#1E4D33] text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  {copiedSeedSql ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSeedSql ? 'Seed SQL Copied!' : 'Copy Seed SQL'}</span>
                </button>
              </div>

              <pre className="p-4 bg-[#12281A] text-amber-300 font-mono text-[11px] rounded-2xl overflow-x-auto max-h-64 border border-black/10 shadow-inner leading-relaxed">
                {SUPABASE_SEED_SQL}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
