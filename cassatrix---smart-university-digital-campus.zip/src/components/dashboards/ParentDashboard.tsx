import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { INITIAL_FEES, INITIAL_ATTENDANCE } from '../../data/mockData';
import {
  Users,
  CheckCircle2,
  AlertTriangle,
  CreditCard,
  MessageCircle,
  Phone,
  Calendar,
  Send,
  Download,
  Shield,
  FileCheck2,
  Bell,
  Check,
  Printer,
  Sparkles,
} from 'lucide-react';
import { FeeItem } from '../../types';

export const ParentDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const [fees, setFees] = useState(INITIAL_FEES);
  const [paidMsg, setPaidMsg] = useState<string | null>(null);

  // Parent alert notification settings
  const [smsAlerts, setSmsAlerts] = useState(true);
  const [whatsappAlerts, setWhatsappAlerts] = useState(true);
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [alertSettingsSaved, setAlertSettingsSaved] = useState(false);

  // Direct Communication to Proctor
  const [proctorMessage, setProctorMessage] = useState('');
  const [messageSent, setMessageSent] = useState(false);

  // Direct Billing Payment Handler
  const handlePayWardFee = (feeId: string) => {
    setFees((prev) =>
      prev.map((f) => {
        if (f.id === feeId) {
          const recNo = `REC-PARENT-${Math.floor(1000 + Math.random() * 9000)}`;
          return {
            ...f,
            status: 'Paid',
            paidDate: 'Today (Guardian Direct Clearance)',
            receiptNo: recNo,
            digitalSignature: `SHA256:0x${Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}...VERIFIED_GUARDIAN_PORTAL`,
          };
        }
        return f;
      })
    );
    setPaidMsg('Ward dues cleared instantly on behalf of student! Official payment receipt pushed to guardian mobile.');
    setTimeout(() => setPaidMsg(null), 5000);
  };

  const handleSendMessageToProctor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!proctorMessage.trim()) return;
    setMessageSent(true);
    setProctorMessage('');
    setTimeout(() => setMessageSent(false), 4000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fade-in text-[#12281A]">
      {/* ============ BANNER ============ */}
      <div className="bg-[#12281A] text-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-96 bg-gradient-to-l from-[#42A85D]/15 to-transparent pointer-events-none"></div>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2 text-xs uppercase tracking-widest text-[#42A85D] font-mono">
              <span className="w-2 h-2 rounded-full bg-[#42A85D] animate-pulse"></span>
              <span>Parent & Guardian Transparency Portal</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-display font-light text-white tracking-tight">
              {currentUser?.role === 'parent' ? currentUser.name : 'Smt. Meenakshi Sharma'}
            </h1>
            <p className="text-xs text-white/70 mt-1.5 font-mono">
              Registered Legal Guardian for Ward: <strong className="text-[#42A85D]">Aarav Sharma</strong> (Enrollment: 0101CS221045)
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/10 text-xs">
            <div className="text-white/60 font-semibold">Ward Academic Status:</div>
            <div className="text-base font-bold text-[#42A85D] mt-0.5">8.72 CGPA · Top Decile</div>
            <div className="text-[11px] text-white/70">Hostel H-3, Room 412 (Aryabhata Hall)</div>
          </div>
        </div>
      </div>

      {paidMsg && (
        <div className="p-4 bg-[#E4EFDA] border border-[#42A85D]/40 text-[#1E4D33] rounded-2xl text-xs flex items-center justify-between gap-3 animate-fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-[#42A85D] shrink-0" />
            <span className="font-semibold">{paidMsg}</span>
          </div>
          <button
            onClick={() => window.print()}
            className="px-3 py-1.5 bg-[#1E4D33] text-white rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Receipt</span>
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* CAPABILITY 2: AUTOMATED RISK ALERTS BANNER */}
      {/* ========================================================================= */}
      <div className="p-5 bg-amber-50/80 border border-amber-300 rounded-3xl space-y-2 text-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 font-bold text-amber-900 text-sm">
            <AlertTriangle className="w-4 h-4 text-amber-600" />
            <span>Automated Ward Risk Threshold Monitor</span>
          </div>
          <span className="text-[11px] font-mono text-amber-800 bg-amber-200/60 px-2.5 py-0.5 rounded-full font-bold">
            1 Active Observation
          </span>
        </div>
        <p className="text-amber-800 leading-relaxed text-xs">
          <strong>Notice for Compiler Design (CS603):</strong> Aarav's attendance is currently <strong>71.4%</strong>. The statutory minimum for university examination clearance is 75.0%. Your ward requires 3 more consecutive lecture attendances to comfortably clear the examination threshold.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* ========================================================================= */}
        {/* CAPABILITY 1: ACADEMIC & ATTENDANCE OVERSIGHT */}
        {/* ========================================================================= */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-6">
          <div className="flex items-center justify-between border-b border-black/10 pb-4">
            <div>
              <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Real-Time Daily Oversight</span>
              <h3 className="font-display font-semibold text-xl text-[#12281A] mt-1">
                Ward Attendance & Continuous Scores
              </h3>
            </div>
            <div className="text-xs font-mono font-bold text-[#1E4D33] bg-[#E4EFDA] px-3 py-1.5 rounded-full">
              Aggregate: 81.3%
            </div>
          </div>

          <div className="divide-y divide-black/5 text-xs">
            {INITIAL_ATTENDANCE.map((sub) => (
              <div key={sub.id} className="py-3.5 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-sm text-[#12281A]">{sub.subjectName}</div>
                  <div className="text-[11px] text-[#12281A]/60 mt-0.5 flex items-center gap-2">
                    <span>{sub.subjectCode}</span>
                    <span>·</span>
                    <span>Faculty: {sub.facultyName}</span>
                    <span>·</span>
                    <span>{sub.attendedClasses} / {sub.totalClasses} Lectures</span>
                  </div>
                </div>

                <div className="text-right">
                  <div className={`font-mono text-base font-bold ${
                    sub.percentage >= 75 ? 'text-[#1E4D33]' : 'text-amber-600'
                  }`}>
                    {sub.percentage}%
                  </div>
                  <span className={`text-[10px] font-bold ${
                    sub.status === 'Good' ? 'text-[#42A85D]' : 'text-amber-700'
                  }`}>
                    {sub.status === 'Good' ? 'Compliant' : 'Warning'}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-4 border-t border-black/10">
            <h4 className="font-semibold text-sm text-[#12281A] mb-3">Internal Test Score Cards (Semester VI)</h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs text-center font-mono">
              <div className="p-3 bg-[#FBFAF7] rounded-xl border border-black/10">
                <div className="text-[10px] text-[#12281A]/50 font-sans uppercase">Database Systems</div>
                <div className="font-bold text-base text-[#1E4D33] mt-1">28 / 30</div>
                <div className="text-[9px] text-[#42A85D] font-sans">93.3% Grade A+</div>
              </div>
              <div className="p-3 bg-[#FBFAF7] rounded-xl border border-black/10">
                <div className="text-[10px] text-[#12281A]/50 font-sans uppercase">Neural Nets</div>
                <div className="font-bold text-base text-[#1E4D33] mt-1">27 / 30</div>
                <div className="text-[9px] text-[#42A85D] font-sans">90.0% Grade A</div>
              </div>
              <div className="p-3 bg-[#FBFAF7] rounded-xl border border-black/10">
                <div className="text-[10px] text-[#12281A]/50 font-sans uppercase">Compiler Design</div>
                <div className="font-bold text-base text-amber-700 mt-1">19 / 30</div>
                <div className="text-[9px] text-amber-700 font-sans">63.3% Grade B</div>
              </div>
              <div className="p-3 bg-[#FBFAF7] rounded-xl border border-black/10">
                <div className="text-[10px] text-[#12281A]/50 font-sans uppercase">Cloud Computing</div>
                <div className="font-bold text-base text-[#1E4D33] mt-1">29 / 30</div>
                <div className="text-[9px] text-[#42A85D] font-sans">96.6% Grade A+</div>
              </div>
            </div>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* CAPABILITY 3: DIRECT BILLING & FEE CLEARANCE */}
        {/* ========================================================================= */}
        <div className="lg:col-span-5 space-y-8">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-5">
            <div className="border-b border-black/10 pb-4">
              <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Guardian Payment Gateway</span>
              <h3 className="font-display font-semibold text-xl text-[#12281A] mt-1">
                Direct Ward Fee Settlement
              </h3>
              <p className="text-xs text-[#12281A]/60 mt-0.5">
                Pay university dues directly on behalf of your ward with instant tax invoices.
              </p>
            </div>

            <div className="space-y-4 text-xs">
              {fees.map((fee) => (
                <div key={fee.id} className="p-4 rounded-2xl border border-black/10 bg-[#FBFAF7] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-[#12281A]">{fee.title}</span>
                    <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                      fee.status === 'Paid' ? 'bg-[#E4EFDA] text-[#1E4D33]' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {fee.status}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-[11px] text-[#12281A]/60">Due: {fee.dueDate} · {fee.category}</div>
                      {fee.receiptNo && (
                        <div className="font-mono text-[10px] text-[#1E4D33] mt-0.5">Receipt: {fee.receiptNo}</div>
                      )}
                    </div>
                    <div className="font-mono text-base font-bold text-[#12281A]">
                      ₹{fee.amount.toLocaleString()}
                    </div>
                  </div>

                  {fee.status === 'Pending' ? (
                    <button
                      onClick={() => handlePayWardFee(fee.id)}
                      className="w-full py-2 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-xl font-semibold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      <span>Pay Dues as Guardian</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => window.print()}
                      className="w-full py-2 border border-black/10 hover:bg-slate-50 text-[#12281A] rounded-xl font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download Digitally Signed Receipt</span>
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Alert Notification Channels */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-4">
            <h4 className="font-semibold text-sm text-[#12281A]">Guardian Risk Notification Channels</h4>
            <div className="space-y-3 text-xs">
              <label className="flex items-center justify-between cursor-pointer">
                <span>Immediate SMS Alerts on Consecutive Absences</span>
                <input
                  type="checkbox"
                  checked={smsAlerts}
                  onChange={(e) => setSmsAlerts(e.target.checked)}
                  className="rounded text-[#1E4D33]"
                />
              </label>
              <label className="flex items-center justify-between cursor-pointer">
                <span>WhatsApp Digest of Weekly Test Scores</span>
                <input
                  type="checkbox"
                  checked={whatsappAlerts}
                  onChange={(e) => setWhatsappAlerts(e.target.checked)}
                  className="rounded text-[#1E4D33]"
                />
              </label>
              <label className="flex items-center justify-between cursor-pointer">
                <span>Official Leadership Circulars by Email</span>
                <input
                  type="checkbox"
                  checked={emailAlerts}
                  onChange={(e) => setEmailAlerts(e.target.checked)}
                  className="rounded text-[#1E4D33]"
                />
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* CAPABILITY 4: OFFICIAL INSTITUTIONAL COMMUNICATION */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-black/10 shadow-2xs space-y-6">
        <div className="border-b border-black/10 pb-4">
          <span className="text-xs font-mono text-[#42A85D] uppercase tracking-wider">Verified Governance Circulars</span>
          <h3 className="font-display font-semibold text-xl text-[#12281A] mt-1">
            Official Leadership Communications
          </h3>
          <p className="text-xs text-[#12281A]/60 mt-0.5">
            Verified circulars, convocation schedules, and holiday directives from the Registrar and Deans.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
          <div className="p-5 rounded-2xl bg-[#FBFAF7] border border-black/10 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs font-bold text-[#1E4D33] bg-[#E4EFDA] px-2 py-0.5 rounded">
                CIRCULAR #41
              </span>
              <span className="text-[10px] text-[#12281A]/50">31 March 2026</span>
            </div>
            <h4 className="font-bold text-sm text-[#12281A]">End-Semester Examination Schedule</h4>
            <p className="text-[#12281A]/70 text-[11px] leading-relaxed">
              Theory examinations begin 18 May 2026. Hall tickets available for download after fee and attendance clearance.
            </p>
            <div className="pt-2 text-[10px] text-emerald-700 font-semibold">
              Digitally Signed by Controller of Examinations ✓
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-[#FBFAF7] border border-black/10 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs font-bold text-[#1E4D33] bg-[#E4EFDA] px-2 py-0.5 rounded">
                CIRCULAR #38
              </span>
              <span className="text-[10px] text-[#12281A]/50">24 March 2026</span>
            </div>
            <h4 className="font-bold text-sm text-[#12281A]">Hostel Curfew & Out-Pass Security Norms</h4>
            <p className="text-[#12281A]/70 text-[11px] leading-relaxed">
              Night curfew at 10:30 PM. Mandatory guardian OTP verification on all overnight leave applications.
            </p>
            <div className="pt-2 text-[10px] text-emerald-700 font-semibold">
              Digitally Signed by Chief Warden & Proctor ✓
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-[#FBFAF7] border border-black/10 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs font-bold text-[#1E4D33] bg-[#E4EFDA] px-2 py-0.5 rounded">
                CIRCULAR #35
              </span>
              <span className="text-[10px] text-[#12281A]/50">15 March 2026</span>
            </div>
            <h4 className="font-bold text-sm text-[#12281A]">Annual Convocation & Degree Issuance</h4>
            <p className="text-[#12281A]/70 text-[11px] leading-relaxed">
              Degrees for 2026 graduates anchored with SHA-256 hashes and synchronized to National DigiLocker.
            </p>
            <div className="pt-2 text-[10px] text-emerald-700 font-semibold">
              Digitally Signed by Registrar & Dean Academic ✓
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
