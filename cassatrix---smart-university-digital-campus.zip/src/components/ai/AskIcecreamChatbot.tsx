import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, X, Volume2, VolumeX, Sparkles, Lock, ShieldCheck, LogIn, ArrowRight, Info, HelpCircle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../types';
import { GoogleGenAI } from '@google/genai';
import icecreamLogo from '../../assets/images/icecream_ai_logo_1790959695348.jpg';

interface ChatMessage {
  id: string;
  sender: 'user' | 'icecream';
  text: string;
  time: string;
  requiresAuth?: boolean;
  targetRole?: UserRole;
  authPromptText?: string;
}

interface AskIcecreamChatbotProps {
  onOpenRoleLogin?: (role?: UserRole) => void;
}

// Universal Campus Knowledge Base (Accessible to ALL users, logged in or not)
const PUBLIC_CAMPUS_KNOWLEDGE: { keywords: string[]; answer: string }[] = [
  {
    keywords: ['what is cassatrix', 'about cassatrix', 'cassatrix erp', 'about the website', 'what is this website', 'how does this work'],
    answer: "Cassatrix is a Unified Smart Campus ERP & AI Governance platform built for modern universities. It seamlessly integrates geofenced 6-digit OTP lecture attendance, automated hostel out-pass workflows, centralized continuous assessment grading, predictive ML dropout prevention, and SHA-256 verifiable DigiLocker credentials across 4 dedicated role portals: Student, Faculty, Parent, and Leadership.",
  },
  {
    keywords: ['how to mark attendance', 'how does otp attendance work', 'otp attendance', 'geofence', 'geofenced attendance', 'attendance procedure', 'biometric'],
    answer: "Cassatrix uses Zero-Proxy Geofenced OTP Attendance: 1) During active lectures, professors project a dynamic rotating 6-digit OTP in class. 2) Students enter this 6-digit code in their Student Portal. 3) The system's high-precision GPS engine confirms the student is physically within the 50-meter classroom boundary. (Biometrics have been completely replaced with this secure dual-factor method).",
  },
  {
    keywords: ['portals', '4 portals', 'role portals', 'which roles', 'what roles', 'user roles'],
    answer: "Cassatrix features 4 specialized role portals:\n• 🎓 Student Portal: Course registration, geofenced OTP attendance, fee payments, and degree vault.\n• 💼 Faculty & Mentor: Live lecture OTP generator, centralized grading ledger, and early dropout alerts.\n• 👨‍👩‍👦 Parent Portal: Real-time ward attendance monitoring, test scorecards, and direct fee clearance.\n• 🏛️ Leadership & Admin: Institutional governance, ₹42.8 Cr revenue analytics, and RBAC matrix.",
  },
  {
    keywords: ['dropout', 'ml prediction', 'risk pipeline', 'early warning', 'ai risk'],
    answer: "Cassatrix's Early Dropout & Risk Pipeline uses machine learning to evaluate student risk trajectories across: 1) Lecture attendance trends (<75% triggers warning), 2) Continuous assessment quiz scores, 3) Assignment submission latency, and 4) Fee default history. Mentors receive instant actionable alerts with 1-click counseling scheduling.",
  },
  {
    keywords: ['bus', 'transport', 'route', 'shuttle', 'bus schedule'],
    answer: "Cassatrix operates 4 GPS-tracked university bus routes:\n• Route 01: Indore Junction ⇄ Main Campus West Gate\n• Route 02: Bhopal ISBT ⇄ East Campus Transit\n• Route 03: Arera Colony ⇄ South Academic Complex\n• Route 04: Bhopal Central Station ⇄ North Gate\nLive telematics and driver contact details are integrated directly into student and parent dashboards.",
  },
  {
    keywords: ['hostel', 'outpass', 'leave', 'night pass', 'gate pass'],
    answer: "Hostel Out-Pass rules: Scholars apply online in the Student Portal specifying dates and destination. For approved academic hackathons or emergencies, parent automated SMS/email verification triggers instantaneous cryptographic gate pass generation with dynamic QR verification at security turnstiles.",
  },
  {
    keywords: ['degree', 'certificate', 'digilocker', 'tamper proof', 'marksheet', 'transcript'],
    answer: "All semester grade cards, bonafide certificates, and degree transcripts in Cassatrix are hashed using SHA-256 algorithms and registered to the National Academic Depository (DigiLocker). Third-party employers and universities can verify authenticity in seconds via QR scan.",
  },
  {
    keywords: ['grading', 'exams', 'evaluation', 'mst', 'marks', 'curriculum', 'policy'],
    answer: "University Grading Policy: Assessment is divided into Continuous Evaluation (30% weightage: MST1, MST2, quizzes, laboratory assessments) and End-Semester University Examination (70% weightage). Maintaining a minimum 75% attendance in each course is mandatory to receive exam admit cards.",
  },
  {
    keywords: ['contact', 'helpline', 'admission', 'email', 'phone', 'address'],
    answer: "Cassatrix Smart Campus HQ: Knowledge City, Bhopal, Madhya Pradesh 462001.\n• Registrar Office: registrar@cassatrix.edu\n• Admissions Desk: admissions@cassatrix.edu | +91 755 2400100\n• AI & Student Helpdesk: support@cassatrix.edu (24/7 SLA)",
  },
];

// Queries requiring authentication when unauthenticated
const AUTH_PROTECTED_TRIGGERS: { keywords: string[]; role: UserRole; reason: string }[] = [
  {
    keywords: ['my attendance', 'check my attendance', 'what is my attendance', 'am i present', 'my attendance status', 'attendance percentage'],
    role: 'student',
    reason: 'To view your personal lecture attendance percentage, subject breakdown, and absence warnings, please sign in to your Scholar portal.',
  },
  {
    keywords: ['my fee', 'my dues', 'pay fee', 'pending fees', 'fee receipt', 'fee invoice', 'my tuition'],
    role: 'student',
    reason: 'To inspect your itemized semester tuition invoice, pending hostel dues, and download tax receipts, please sign in to your student or parent account.',
  },
  {
    keywords: ['my grades', 'my cgpa', 'my marks', 'my report card', 'my backlogs', 'my result'],
    role: 'student',
    reason: 'To check your personalized SGPA, CGPA, mid-sem scorecards, and degree transcripts, please sign in to your Student Portal.',
  },
  {
    keywords: ['generate otp', 'start lecture', 'take attendance', 'record marks', 'enter grade', 'grade students'],
    role: 'faculty',
    reason: 'To generate dynamic 6-digit lecture OTPs or update the continuous evaluation grading ledger, please sign in with your Faculty credentials.',
  },
  {
    keywords: ['my ward', 'ward attendance', 'my child', 'my son', 'my daughter', 'parent dashboard'],
    role: 'parent',
    reason: "To monitor your ward's daily attendance records, mentor remarks, and clear semester fees, please sign in to the Parent Portal.",
  },
  {
    keywords: ['admin analytics', 'collection revenue', 'rbac security', 'batch sign', 'sign certificates'],
    role: 'admin',
    reason: 'To access institutional revenue analytics, governance settings, and batch DigiLocker signing, please sign in with Administrator credentials.',
  },
  {
    keywords: ['my outpass', 'apply outpass', 'my bus pass', 'book seat'],
    role: 'student',
    reason: 'To apply for hostel out-passes, manage room allocations, or reserve bus shuttle seats, please sign in to your Student Portal.',
  },
];

export const AskIcecreamChatbot: React.FC<AskIcecreamChatbotProps> = ({ onOpenRoleLogin }) => {
  const { currentUser } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize messages based on current auth state
  useEffect(() => {
    if (currentUser) {
      setMessages([
        {
          id: 'msg-welcome-auth',
          sender: 'icecream',
          text: `Namaste ${currentUser.name.split(' ')[0]}! 🎓 I am Icecream, your official Cassatrix AI Assistant (${currentUser.roleTitle}). You have full access to your personalized academic ledger, geofenced OTP attendance, fee invoices, bus fleet telemetry, and examination schedules. How can I assist you today?`,
          time: 'Just now',
        },
      ]);
    } else {
      setMessages([
        {
          id: 'msg-welcome-public',
          sender: 'icecream',
          text: `Hello! 👋 I am Icecream, the Cassatrix Smart Campus AI Guide. You can ask me anything about the university website, 6-digit geofenced OTP attendance, the 4 role portals, academic policies, bus routes, or admissions. (For your personal attendance, grades, or fee dues, I will guide you to sign in).`,
          time: 'Just now',
        },
      ]);
    }
  }, [currentUser?.email, currentUser?.role]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isOpen]);

  // Escape key handler to close chatbot
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  const speakText = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    if (isSpeaking) {
      setIsSpeaking(false);
      return;
    }
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const handleSend = async (userQuery?: string) => {
    const textToSend = userQuery || input;
    if (!textToSend.trim()) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      time: 'Just now',
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!userQuery) setInput('');
    setIsLoading(true);

    const lower = textToSend.toLowerCase().trim();

    // -------------------------------------------------------------------------
    // CASE A: User is NOT LOGGED IN
    // -------------------------------------------------------------------------
    if (!currentUser) {
      // 1. Check if the user is asking for private/personal data that requires login
      for (const trigger of AUTH_PROTECTED_TRIGGERS) {
        if (trigger.keywords.some((k) => lower.includes(k))) {
          setTimeout(() => {
            const botMsg: ChatMessage = {
              id: `bot-${Date.now()}`,
              sender: 'icecream',
              text: trigger.reason,
              time: 'Just now',
              requiresAuth: true,
              targetRole: trigger.role,
              authPromptText: `Sign In as ${trigger.role.charAt(0).toUpperCase() + trigger.role.slice(1)}`,
            };
            setMessages((prev) => [...prev, botMsg]);
            setIsLoading(false);
            speakText(trigger.reason);
          }, 400);
          return;
        }
      }

      // 2. Check if query matches public university knowledge
      for (const item of PUBLIC_CAMPUS_KNOWLEDGE) {
        if (item.keywords.some((k) => lower.includes(k))) {
          setTimeout(() => {
            const botMsg: ChatMessage = {
              id: `bot-${Date.now()}`,
              sender: 'icecream',
              text: item.answer,
              time: 'Just now',
            };
            setMessages((prev) => [...prev, botMsg]);
            setIsLoading(false);
            speakText(item.answer);
          }, 400);
          return;
        }
      }

      // 3. Fallback for unauthenticated general queries (or Gemini API if available)
      try {
        const apiKey = process.env.GEMINI_API_KEY || (window as any).GEMINI_API_KEY;
        if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
          const ai = new GoogleGenAI({ apiKey });
          const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `You are Icecream, the AI guide for Cassatrix Smart University Digital Campus. The user is a campus visitor/prospective student (unauthenticated). 
Answer the user's question clearly and helpfully based on smart campus ERP knowledge (geofenced OTP attendance, 4 portals for student/faculty/parent/admin, hostel workflows, bus telematics, ML dropout prevention). 
If the user is asking for personal data (like their own specific grades or fee balance), politely instruct them to sign in to their portal.
User query: "${textToSend}"`,
          });

          const reply = response.text || "I'm here to help you learn about Cassatrix Smart Campus and all our university services.";
          const botMsg: ChatMessage = {
            id: `bot-${Date.now()}`,
            sender: 'icecream',
            text: reply,
            time: 'Just now',
          };
          setMessages((prev) => [...prev, botMsg]);
          speakText(reply);
        } else {
          throw new Error('Fallback local');
        }
      } catch {
        const fallbackMsg: ChatMessage = {
          id: `bot-${Date.now()}`,
          sender: 'icecream',
          text: `Cassatrix provides unified campus operations. You can ask me about how our 6-digit geofenced OTP attendance functions, details on the 4 role portals (Student, Faculty, Parent, Leadership), bus transit routes, or university guidelines. If you need your personal records, please sign in using the button above!`,
          time: 'Just now',
        };
        setMessages((prev) => [...prev, fallbackMsg]);
      } finally {
        setIsLoading(false);
      }
      return;
    }

    // -------------------------------------------------------------------------
    // CASE B: User IS LOGGED IN (Role-Aware Context)
    // -------------------------------------------------------------------------
    // 1. Personalized authenticated responses
    if (lower.includes('attendance') || lower.includes('present') || lower.includes('absent')) {
      let ans = '';
      if (currentUser.role === 'student') {
        ans = "Your aggregate attendance is 81.3%. Compiler Design is at 71.4% (Warning threshold) and Cybersecurity is 63.3% (Critical). Please enter the 6-digit OTP in class within the 50m geofence for your next 3 lectures to remain eligible for exams.";
      } else if (currentUser.role === 'faculty') {
        ans = "In your active CS601 lecture (Smart Hall 301), 42 out of 48 enrolled students have checked in via dynamic 6-digit OTP. 6 absentees were recorded on the central ledger.";
      } else if (currentUser.role === 'parent') {
        ans = "Your ward Aarav Sharma's attendance is 81.3%. He has 5 recent absences in Cybersecurity Lab. We recommend monitoring upcoming practical sessions.";
      } else {
        ans = "Campus-wide student attendance is averaging 84.6% today. 14 classes are actively broadcasting geofenced OTPs.";
      }
      setTimeout(() => {
        setMessages((prev) => [...prev, { id: `bot-${Date.now()}`, sender: 'icecream', text: ans, time: 'Just now' }]);
        setIsLoading(false);
        speakText(ans);
      }, 400);
      return;
    }

    if (lower.includes('fee') || lower.includes('due') || lower.includes('dues') || lower.includes('tuition')) {
      let ans = '';
      if (currentUser.role === 'student' || currentUser.role === 'parent') {
        ans = "Semester VI Tuition (₹54,000) and Hostel (₹28,500) are fully PAID. Outstanding dues: End-Sem Exam Fee (₹3,200, due 30 Apr) and Digital Library (₹1,500, due 10 May). Payments can be cleared via UPI in the Financial Ledger.";
      } else if (currentUser.role === 'admin') {
        ans = "Total semester fee collections stand at ₹42.84 Crores (91.2% recovered). ₹4.12 Cr remains outstanding before the upcoming 30th April deadline.";
      } else {
        ans = "Departmental grant utilization: ₹14.5 Lakhs allocated for CS Research Labs. All faculty claims are processed.";
      }
      setTimeout(() => {
        setMessages((prev) => [...prev, { id: `bot-${Date.now()}`, sender: 'icecream', text: ans, time: 'Just now' }]);
        setIsLoading(false);
        speakText(ans);
      }, 400);
      return;
    }

    if (lower.includes('otp') || lower.includes('geofence')) {
      let ans = '';
      if (currentUser.role === 'faculty') {
        ans = "Your current CS601 lecture OTP is 849201 (Valid for 4 minutes 20 seconds). Geofence perimeter is locked to Smart Lecture Hall 301 (50m radius).";
      } else {
        ans = "To check in for your current lecture, enter the 6-digit OTP shown by your instructor while inside the 50m classroom boundary.";
      }
      setTimeout(() => {
        setMessages((prev) => [...prev, { id: `bot-${Date.now()}`, sender: 'icecream', text: ans, time: 'Just now' }]);
        setIsLoading(false);
        speakText(ans);
      }, 400);
      return;
    }

    // Check public knowledge for general campus queries
    for (const item of PUBLIC_CAMPUS_KNOWLEDGE) {
      if (item.keywords.some((k) => lower.includes(k))) {
        setTimeout(() => {
          setMessages((prev) => [...prev, { id: `bot-${Date.now()}`, sender: 'icecream', text: item.answer, time: 'Just now' }]);
          setIsLoading(false);
          speakText(item.answer);
        }, 400);
        return;
      }
    }

    // Try Gemini API with authenticated profile context
    try {
      const apiKey = process.env.GEMINI_API_KEY || (window as any).GEMINI_API_KEY;
      if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
        const ai = new GoogleGenAI({ apiKey });
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: `You are Icecream, the AI campus assistant for Cassatrix Smart University Digital Campus. The user is logged in as ${currentUser.name} (${currentUser.roleTitle}), role: ${currentUser.role}.
Answer concisely in 2-3 sentences based on university governance and their profile: "${textToSend}"`,
        });

        const reply = response.text || 'I am ready to assist with all your campus needs.';
        setMessages((prev) => [...prev, { id: `bot-${Date.now()}`, sender: 'icecream', text: reply, time: 'Just now' }]);
        speakText(reply);
      } else {
        throw new Error('Fallback local');
      }
    } catch {
      const fallbackMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'icecream',
        text: `Your ${currentUser.roleTitle} portal is synchronized. You can ask me about Attendance, Timetable, Fee Receipts, Bus Route 04, or Hostel Out-Pass.`,
        time: 'Just now',
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Floating launcher styled with Icecream AI badge */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
        {!isOpen && (
          <div className="flex flex-col items-end gap-1.5 animate-bounce-subtle">
            <div
              className="bg-white/95 backdrop-blur-md px-3.5 py-1.5 rounded-full shadow-lg border border-[#42A85D]/30 text-xs font-bold text-slate-800 flex items-center gap-1.5 cursor-pointer hover:shadow-xl transition-all"
              onClick={() => setIsOpen(true)}
            >
              <span className="w-2 h-2 rounded-full bg-[#42A85D] animate-ping"></span>
              <span className="text-[11px] font-bold text-[#1E4D33]">ASK ICECREAM</span>
              <span className="text-slate-400">· Campus AI</span>
            </div>

            <button
              onClick={() => setIsOpen(true)}
              className="w-14 h-14 rounded-full bg-[#12281A] text-white shadow-xl shadow-[#1E4D33]/40 flex items-center justify-center hover:scale-105 transition-transform cursor-pointer border-2 border-[#42A85D]/60 overflow-hidden group"
              title="Open Ask Icecream AI Assistant"
            >
              <img
                src={icecreamLogo}
                alt="Icecream AI Logo"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform"
              />
            </button>
          </div>
        )}

        {/* Chat Window */}
        {isOpen && (
          <div className="bg-white rounded-3xl shadow-2xl border border-black/10 w-[92vw] sm:w-[420px] h-[550px] flex flex-col overflow-hidden animate-scale-up">
            {/* Header */}
            <div className="bg-[#12281A] text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-white/10 border border-[#42A85D]/50 flex items-center justify-center overflow-hidden shadow-sm shrink-0">
                  <img src={icecreamLogo} alt="Icecream AI Logo" className="w-full h-full object-cover" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="font-bold text-sm">Ask Icecream AI</h3>
                    {currentUser ? (
                      <span className="text-[10px] px-2 py-0.5 bg-[#42A85D] text-white rounded-full font-bold">
                        {currentUser.roleTitle.split(' ')[0]}
                      </span>
                    ) : (
                      <span className="text-[10px] px-2 py-0.5 bg-emerald-700/80 text-white rounded-full font-bold flex items-center gap-1">
                        Campus Guide
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-[#42A85D]">Cassatrix Smart Campus Intelligence</p>
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => speakText(messages[messages.length - 1]?.text || '')}
                  className={`p-2 rounded-xl transition-colors cursor-pointer ${
                    isSpeaking ? 'bg-[#42A85D] text-white' : 'text-slate-300 hover:text-white hover:bg-white/10'
                  }`}
                  title={isSpeaking ? 'Mute' : 'Speak latest reply'}
                >
                  {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>

                <button
                  onClick={() => setIsOpen(false)}
                  className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                  title="Close Assistant (Esc)"
                  aria-label="Close"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Conversation Messages */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50/70 text-xs">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[88%] rounded-2xl p-3.5 shadow-2xs leading-relaxed whitespace-pre-line ${
                      m.sender === 'user'
                        ? 'bg-[#1E4D33] text-white rounded-tr-none'
                        : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none'
                    }`}
                  >
                    {m.text}

                    {/* If this message requires authentication, show the inline Sign In button */}
                    {m.requiresAuth && !currentUser && (
                      <div className="mt-3 pt-2.5 border-t border-slate-200/80">
                        <button
                          onClick={() => {
                            setIsOpen(false);
                            if (onOpenRoleLogin) onOpenRoleLogin(m.targetRole || 'student');
                          }}
                          className="w-full py-2 px-3 bg-[#1E4D33] hover:bg-[#2A6647] active:scale-95 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
                        >
                          <LogIn className="w-3.5 h-3.5" />
                          <span>{m.authPromptText || 'Sign In to View Records'}</span>
                          <ArrowRight className="w-3.5 h-3.5 ml-1" />
                        </button>
                      </div>
                    )}
                  </div>
                  <span className="text-[10px] text-slate-400 mt-1 px-1">{m.time}</span>
                </div>
              ))}

              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-white border border-slate-200 rounded-2xl p-3 text-xs text-slate-500 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#42A85D] animate-ping"></span>
                    <span>Icecream is thinking...</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Suggested Quick Question Chips */}
            <div className="p-2 bg-slate-100/90 border-t border-slate-200 flex items-center gap-1.5 overflow-x-auto text-[11px] shrink-0 scrollbar-none">
              {!currentUser ? (
                <>
                  <button
                    onClick={() => handleSend('What is Cassatrix ERP and what does it do?')}
                    className="px-2.5 py-1 bg-white hover:bg-emerald-50 text-slate-700 hover:text-[#1E4D33] border border-slate-200 rounded-full whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1 shrink-0"
                  >
                    🏛️ About Cassatrix
                  </button>
                  <button
                    onClick={() => handleSend('How does 6-digit geofenced OTP attendance work?')}
                    className="px-2.5 py-1 bg-white hover:bg-emerald-50 text-slate-700 hover:text-[#1E4D33] border border-slate-200 rounded-full whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1 shrink-0"
                  >
                    📍 OTP Attendance
                  </button>
                  <button
                    onClick={() => handleSend('What are the 4 user role portals?')}
                    className="px-2.5 py-1 bg-white hover:bg-emerald-50 text-slate-700 hover:text-[#1E4D33] border border-slate-200 rounded-full whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1 shrink-0"
                  >
                    👥 4 Role Portals
                  </button>
                  <button
                    onClick={() => handleSend('Tell me about campus bus routes and transport')}
                    className="px-2.5 py-1 bg-white hover:bg-emerald-50 text-slate-700 hover:text-[#1E4D33] border border-slate-200 rounded-full whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1 shrink-0"
                  >
                    🚌 Bus Routes
                  </button>
                  <button
                    onClick={() => handleSend('How does early dropout prediction work?')}
                    className="px-2.5 py-1 bg-white hover:bg-emerald-50 text-slate-700 hover:text-[#1E4D33] border border-slate-200 rounded-full whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1 shrink-0"
                  >
                    📊 AI Dropout Engine
                  </button>
                  <button
                    onClick={() => handleSend('What is my attendance?')}
                    className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-full whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1 shrink-0 font-medium"
                    title="Requires sign in"
                  >
                    🔒 My Attendance
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => handleSend('What is my attendance status?')}
                    className="px-2.5 py-1 bg-white hover:bg-emerald-50 text-slate-700 hover:text-[#1E4D33] border border-slate-200 rounded-full whitespace-nowrap transition-colors cursor-pointer shrink-0"
                  >
                    📊 My Attendance
                  </button>
                  <button
                    onClick={() => handleSend('What are my pending fee dues?')}
                    className="px-2.5 py-1 bg-white hover:bg-emerald-50 text-slate-700 hover:text-[#1E4D33] border border-slate-200 rounded-full whitespace-nowrap transition-colors cursor-pointer shrink-0"
                  >
                    💳 Fee Status
                  </button>
                  <button
                    onClick={() => handleSend('How do I mark OTP attendance with geofencing?')}
                    className="px-2.5 py-1 bg-white hover:bg-emerald-50 text-slate-700 hover:text-[#1E4D33] border border-slate-200 rounded-full whitespace-nowrap transition-colors cursor-pointer shrink-0"
                  >
                    📍 OTP Attendance
                  </button>
                  <button
                    onClick={() => handleSend('Where is university bus route 04?')}
                    className="px-2.5 py-1 bg-white hover:bg-emerald-50 text-slate-700 hover:text-[#1E4D33] border border-slate-200 rounded-full whitespace-nowrap transition-colors cursor-pointer shrink-0"
                  >
                    🚌 Track Bus 04
                  </button>
                </>
              )}
            </div>

            {/* Input Form Footer */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="p-3 bg-white border-t border-slate-200 flex items-center gap-2"
            >
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={
                  currentUser
                    ? `Ask Icecream as ${currentUser.name.split(' ')[0]}...`
                    : 'Ask any question about Cassatrix campus & features...'
                }
                className="flex-1 bg-slate-100 border border-slate-200 rounded-2xl px-4 py-2.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#1E4D33] focus:bg-white"
              />
              <button
                type="submit"
                disabled={!input.trim()}
                className="p-2.5 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-2xl transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shadow-xs"
                title="Send message"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}
      </div>
    </>
  );
};

export const AskSarthiChatbot = AskIcecreamChatbot;
