import React, { useState } from 'react';
import { STUDENT_RISK_PROFILES, LEARNING_RECOMMENDATIONS } from '../../data/mockData';
import {
  TrendingUp,
  AlertTriangle,
  Lightbulb,
  CheckCircle,
  BrainCircuit,
  Sliders,
  ArrowRight,
  Send,
} from 'lucide-react';

export const PredictiveAnalyticsView: React.FC = () => {
  const [selectedStudentId, setSelectedStudentId] = useState('STU-01');
  const [interventionSent, setInterventionSent] = useState<string | null>(null);

  const [simAttendance, setSimAttendance] = useState(82);
  const [simStudyHours, setSimStudyHours] = useState(14);
  const [simTestAverage, setSimTestAverage] = useState(25);

  const currentStudent =
    STUDENT_RISK_PROFILES.find((s) => s.studentId === selectedStudentId) ||
    STUDENT_RISK_PROFILES[0];

  const calculatedProjectedGpa = Number(
    Math.min(
      10.0,
      Math.max(
        4.0,
        (simAttendance * 0.045) + (simTestAverage * 0.15) + (simStudyHours * 0.08)
      )
    ).toFixed(2)
  );

  const handleSendIntervention = () => {
    setInterventionSent(
      `Intervention alert successfully dispatched to Proctor Dr. Sunita Verma and parent SMS queued for ${currentStudent.name}.`
    );
    setTimeout(() => {
      setInterventionSent(null);
    }, 5000);
  };

  return (
    <div className="space-y-8 animate-fade-in max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Header Banner */}
      <div className="bg-[#0B1B3D] text-white rounded-3xl p-6 sm:p-8 border border-blue-900 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 text-xs font-semibold mb-3 border border-cyan-500/30">
              <BrainCircuit className="w-4 h-4" />
              Machine Learning Core · Team Cassata
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
              AI Academic Forecasting & Early Dropout Prevention
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-2xl leading-relaxed">
              Synthesizing multi-variable student telemetry—attendance, mid-semester trends, fee payments, and LMS engagement—to prevent academic attrition and personalize learning.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/10 text-xs space-y-1 sm:w-64 shrink-0">
            <div className="text-slate-400 font-medium">Model Precision</div>
            <div className="text-xl font-bold text-[#00C2FF] font-mono tabular-nums">94.8% AUC</div>
            <div className="text-[11px] text-slate-300">Trained on historical MP university cohorts</div>
          </div>
        </div>
      </div>

      {/* Cohort Selector */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs">
        <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
          Inspect Student Academic Risk Profile:
        </span>
        <div className="flex flex-wrap gap-2">
          {STUDENT_RISK_PROFILES.map((stu) => {
            const isSelected = stu.studentId === selectedStudentId;
            const badgeColor =
              stu.dropoutRiskLevel === 'High'
                ? 'bg-rose-100 text-rose-700 border-rose-300'
                : stu.dropoutRiskLevel === 'Moderate'
                ? 'bg-amber-100 text-amber-700 border-amber-300'
                : 'bg-emerald-100 text-emerald-700 border-emerald-300';
            return (
              <button
                key={stu.studentId}
                onClick={() => setSelectedStudentId(stu.studentId)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <span>{stu.name}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full border ${badgeColor}`}>
                  {stu.dropoutRiskLevel}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid: Dropout Risk & GPA Simulation */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-2xs space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                  currentStudent.dropoutRiskLevel === 'High'
                    ? 'bg-rose-100 text-rose-600'
                    : currentStudent.dropoutRiskLevel === 'Moderate'
                    ? 'bg-amber-100 text-amber-600'
                    : 'bg-emerald-100 text-emerald-600'
                }`}
              >
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-slate-900">
                  Early Dropout Risk Analysis
                </h3>
                <p className="text-xs text-slate-500">
                  {currentStudent.name} · {currentStudent.enrollmentNo} ({currentStudent.branch} Sem {currentStudent.semester})
                </p>
              </div>
            </div>

            <div className="text-right">
              <div className="text-[11px] font-bold text-slate-400 uppercase">Attrition Risk Index</div>
              <div
                className={`text-2xl font-black font-mono tabular-nums ${
                  currentStudent.dropoutRiskLevel === 'High'
                    ? 'text-rose-600'
                    : currentStudent.dropoutRiskLevel === 'Moderate'
                    ? 'text-amber-600'
                    : 'text-emerald-600'
                }`}
              >
                {currentStudent.dropoutRiskScore}/100
              </div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-600">
              Correlated Risk Drivers
            </div>
            <ul className="space-y-2 text-xs">
              {currentStudent.keyRiskFactors.map((f, i) => (
                <li key={i} className="flex items-start gap-2 text-slate-700">
                  <span className="text-rose-500 font-bold">•</span>
                  <span>{f}</span>
                </li>
              ))}
              {currentStudent.feeDefaulter && (
                <li className="flex items-start gap-2 text-rose-700 font-semibold">
                  <span className="text-rose-500 font-bold">•</span>
                  <span>Flagged as Fee Defaulter (Unpaid End-Semester assessment fees)</span>
                </li>
              )}
            </ul>
          </div>

          <div className="p-4 rounded-2xl bg-blue-50/60 border border-blue-200/70 space-y-2">
            <div className="text-xs font-bold text-blue-900 flex items-center gap-1.5">
              <Lightbulb className="w-4 h-4 text-blue-600" />
              Prescribed Intervention Strategy
            </div>
            <p className="text-xs text-blue-950 leading-relaxed">
              {currentStudent.recommendedAction}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
            <button
              onClick={handleSendIntervention}
              className="w-full sm:w-auto px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors shadow-xs"
            >
              <Send className="w-3.5 h-3.5" />
              Trigger Academic Counseling & Parent Nudge
            </button>
            <span className="text-[11px] text-slate-500">
              Routes priority alert to Proctor & Ward Guardian
            </span>
          </div>

          {interventionSent && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2 animate-fade-in font-medium">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{interventionSent}</span>
            </div>
          )}
        </div>

        <div className="lg:col-span-5 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-2xs space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900">
                Predictive GPA Projection
              </h3>
              <p className="text-xs text-slate-500">
                Semester VI Final Marks Estimator
              </p>
            </div>
          </div>

          <div className="bg-slate-900 text-white p-5 rounded-2xl flex items-center justify-between">
            <div>
              <div className="text-[11px] text-slate-400 font-medium">Current Cumulative CGPA</div>
              <div className="text-2xl font-bold font-mono tabular-nums text-slate-200">
                {currentStudent.currentCgpa}
              </div>
            </div>
            <div className="text-right">
              <div className="text-[11px] text-cyan-300 font-bold uppercase">AI Projected GPA</div>
              <div className="text-3xl font-black font-mono tabular-nums text-[#00C2FF]">
                {calculatedProjectedGpa}
              </div>
            </div>
          </div>

          <div className="space-y-4 pt-2">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5" />
              Adjust Student Parameters (What-If Simulation)
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                <span>Lecture Attendance</span>
                <span className="font-mono text-blue-600">{simAttendance}%</span>
              </div>
              <input
                type="range"
                min="50"
                max="100"
                value={simAttendance}
                onChange={(e) => setSimAttendance(Number(e.target.value))}
                className="w-full accent-blue-600 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                <span>Self-Study / Lab Prep (Hours/Week)</span>
                <span className="font-mono text-blue-600">{simStudyHours} hrs</span>
              </div>
              <input
                type="range"
                min="2"
                max="35"
                value={simStudyHours}
                onChange={(e) => setSimStudyHours(Number(e.target.value))}
                className="w-full accent-blue-600 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                <span>Mid-Semester Test (MST) Average</span>
                <span className="font-mono text-blue-600">{simTestAverage} / 30</span>
              </div>
              <input
                type="range"
                min="10"
                max="30"
                value={simTestAverage}
                onChange={(e) => setSimTestAverage(Number(e.target.value))}
                className="w-full accent-blue-600 cursor-pointer"
              />
            </div>
          </div>
        </div>
      </div>

      {/* FEATURE 3: Personalized Learning Recommendations */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <Lightbulb className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900">
                Personalized Learning Recommendations
              </h3>
              <p className="text-xs text-slate-500">
                Tailored curriculum interventions based on diagnosed knowledge gaps
              </p>
            </div>
          </div>
          <span className="text-xs font-semibold text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
            4 Adaptive Tracks Generated
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {LEARNING_RECOMMENDATIONS.map((rec) => (
            <div
              key={rec.id}
              className="p-5 rounded-2xl border border-slate-200/90 hover:border-blue-400 hover:shadow-xs transition-all bg-white flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-[11px] mb-2">
                  <span className="font-bold text-blue-600">{rec.subject}</span>
                  <span className="px-2 py-0.5 rounded bg-slate-100 font-semibold text-slate-700">
                    {rec.difficulty} · {rec.estimatedHours}h
                  </span>
                </div>
                <h4 className="font-bold text-sm text-slate-900 mb-1.5">
                  {rec.topic}
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed mb-4">
                  <strong>Trigger:</strong> {rec.reason}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] font-semibold text-slate-500">
                  {rec.resourceType}
                </span>
                <button
                  onClick={() => alert(`Launching module: ${rec.topic}`)}
                  className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1 transition-colors"
                >
                  <span>Launch Module</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
