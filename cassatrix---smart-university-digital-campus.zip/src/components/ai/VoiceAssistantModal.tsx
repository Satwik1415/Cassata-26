import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Volume2, X, Sparkles, Lock, LogIn, ArrowRight } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../types';
import icecreamLogo from '../../assets/images/icecream_ai_logo_1790959695348.jpg';

interface VoiceAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenRoleLogin?: (role?: UserRole) => void;
}

export const VoiceAssistantModal: React.FC<VoiceAssistantModalProps> = ({ isOpen, onClose, onOpenRoleLogin }) => {
  const { currentUser } = useAuth();
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [response, setResponse] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [requiresAuth, setRequiresAuth] = useState(false);
  const [authRole, setAuthRole] = useState<UserRole>('student');
  const [statusText, setStatusText] = useState('Tap microphone to speak');

  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = true;
        recognition.lang = 'en-IN';

        recognition.onstart = () => {
          setIsListening(true);
          setStatusText('Listening to your voice command...');
        };

        recognition.onresult = (event: any) => {
          const current = event.resultIndex;
          const text = event.results[current][0].transcript;
          setTranscript(text);
          if (event.results[current].isFinal) {
            handleVoiceQuery(text);
          }
        };

        recognition.onerror = () => {
          setIsListening(false);
          setStatusText('Microphone paused. You can also click any sample question below.');
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognitionRef.current = recognition;
      }
    }
  }, []);

  const startListening = () => {
    if (recognitionRef.current) {
      try {
        setTranscript('');
        setResponse('');
        setRequiresAuth(false);
        recognitionRef.current.start();
      } catch {
        recognitionRef.current.stop();
      }
    } else {
      setStatusText('Speech recognition not available. Please tap any quick query below.');
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  };

  const handleVoiceQuery = (query: string) => {
    setStatusText('Processing Cassatrix campus audio intelligence...');
    const q = query.toLowerCase().trim();
    let reply = '';
    let needsAuth = false;
    let targetRole: UserRole = 'student';

    if (!currentUser) {
      // 1. Personal queries requiring auth
      if (q.includes('my attendance') || q.includes('my percentage') || q.includes('absent')) {
        reply = "To check your personal lecture attendance records, please sign in to your Scholar Portal.";
        needsAuth = true;
        targetRole = 'student';
      } else if (q.includes('my fee') || q.includes('my due') || q.includes('pay fee')) {
        reply = "To view your itemized semester tuition invoice and payment history, please sign in to your account.";
        needsAuth = true;
        targetRole = 'student';
      } else if (q.includes('my grade') || q.includes('my cgpa') || q.includes('my mark')) {
        reply = "To inspect your semester SGPA and DigiLocker grade cards, please sign in to your student account.";
        needsAuth = true;
        targetRole = 'student';
      } else if (q.includes('generate otp') || q.includes('take attendance')) {
        reply = "To generate live 6-digit lecture OTPs, please sign in with your Faculty credentials.";
        needsAuth = true;
        targetRole = 'faculty';
      } else if (q.includes('otp') || q.includes('geofence') || q.includes('attendance')) {
        reply = "Cassatrix uses zero-proxy geofenced OTP attendance. Professors broadcast a 6-digit dynamic OTP, and high-precision GPS confirms students are inside the 50-meter classroom perimeter.";
      } else if (q.includes('cassatrix') || q.includes('website') || q.includes('about')) {
        reply = "Cassatrix is the Unified Smart Campus ERP & AI Governance platform featuring 4 role portals: Student, Faculty, Parent, and Leadership.";
      } else if (q.includes('bus') || q.includes('transport') || q.includes('route')) {
        reply = "Cassatrix operates 4 GPS-tracked university bus routes connecting Bhopal Central, ISBT, Arera Colony, and Indore Junction with live telematics.";
      } else if (q.includes('portal') || q.includes('role')) {
        reply = "Cassatrix has 4 role portals: Scholar Academic ERP, Faculty Instruction & Mentorship, Guardian Transparency, and Executive Leadership.";
      } else if (q.includes('hostel') || q.includes('outpass')) {
        reply = "Hostel outpass requests are submitted online with automated guardian SMS verification and cryptographic QR turnstile passes.";
      } else {
        reply = `I heard: "${query}". Cassatrix connects academic life, OTP attendance, and campus governance across all university departments.`;
      }
    } else {
      // Authenticated personalized answers
      if (q.includes('next class') || q.includes('timetable') || q.includes('schedule')) {
        reply = `Your next scheduled lecture is Advanced Database Systems with Dr. Sunita Verma at 09:30 AM in Smart Hall 301.`;
      } else if (q.includes('attendance') || q.includes('otp')) {
        if (currentUser.role === 'student') {
          reply = `Your overall attendance is 81.3%. Reminder: Mark attendance with the 6-digit lecture OTP within the 50m classroom geofence.`;
        } else if (currentUser.role === 'faculty') {
          reply = `Active lecture CS601 in Hall 301 has 42 of 48 students checked in via dynamic 6-digit OTP.`;
        } else {
          reply = `Ward Aarav Sharma's attendance is 81.3% with zero exam debarment risks.`;
        }
      } else if (q.includes('fee') || q.includes('due') || q.includes('dues')) {
        reply = "Semester VI tuition is paid. Outstanding dues: End-Sem Exam Fee of ₹3,200 due on 30th April 2026.";
      } else if (q.includes('bus') || q.includes('transport')) {
        reply = "Bus Route 04 is currently near Board Office Square, reaching Campus North Gate in 12 minutes.";
      } else if (q.includes('dropout') || q.includes('risk')) {
        reply = "Your AI dropout risk rating is 12 out of 100 (Low Risk) with strong lab performance.";
      } else {
        reply = `Hello ${currentUser.name.split(' ')[0]}, your ${currentUser.roleTitle} services are active and synchronized on Cassatrix.`;
      }
    }

    setRequiresAuth(needsAuth);
    setAuthRole(targetRole);
    setResponse(reply);
    setStatusText('Answer ready');
    speakVoice(reply);
  };

  const speakVoice = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  // Escape key handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (window.speechSynthesis) window.speechSynthesis.cancel();
        onClose();
      }
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md cursor-pointer animate-fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          if (window.speechSynthesis) window.speechSynthesis.cancel();
          onClose();
        }
      }}
    >
      <div className="bg-[#12281A] text-white rounded-3xl max-w-lg w-full p-6 sm:p-8 border border-white/10 shadow-2xl relative overflow-hidden cursor-default">
        {/* Decorative ambient aura */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#42A85D]/15 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex items-center justify-between mb-6 relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/10 border border-[#42A85D]/50 flex items-center justify-center overflow-hidden shrink-0 shadow-sm">
              <img src={icecreamLogo} alt="Icecream AI Logo" className="w-full h-full object-cover" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Cassatrix Voice Assistant</h3>
              <p className="text-[11px] text-[#42A85D] font-medium">Icecream AI Audio Companion</p>
            </div>
          </div>
          <button
            onClick={() => {
              if (window.speechSynthesis) window.speechSynthesis.cancel();
              onClose();
            }}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="Close (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Status banner */}
        <div className="text-center py-2 relative z-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs text-slate-300">
            <span
              className={`w-2 h-2 rounded-full ${
                isListening
                  ? 'bg-rose-500 animate-ping'
                  : isSpeaking
                  ? 'bg-[#42A85D] animate-pulse'
                  : 'bg-emerald-400'
              }`}
            ></span>
            <span>{statusText}</span>
          </div>
        </div>

        {/* Central Pulsing Microphone Trigger */}
        <div className="my-8 flex flex-col items-center justify-center relative z-10">
          <button
            onClick={isListening ? stopListening : startListening}
            className={`w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300 cursor-pointer shadow-2xl ${
              isListening
                ? 'bg-rose-600 hover:bg-rose-700 text-white scale-110 shadow-rose-600/50 animate-pulse'
                : 'bg-gradient-to-tr from-[#1E4D33] via-[#2A6647] to-[#42A85D] text-white hover:scale-105 shadow-[#42A85D]/30'
            }`}
            title={isListening ? 'Stop Listening' : 'Tap to Speak'}
          >
            {isListening ? <MicOff className="w-10 h-10" /> : <Mic className="w-10 h-10" />}
          </button>
          <span className="text-xs text-slate-400 mt-3 font-medium">
            {isListening ? 'Listening... Tap to process' : 'Tap to start voice inquiry'}
          </span>
        </div>

        {/* Realtime Live Transcript */}
        {transcript && (
          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 mb-4 text-xs text-slate-200">
            <span className="text-[#42A85D] font-bold block mb-1">You said:</span>
            <span>"{transcript}"</span>
          </div>
        )}

        {/* Spoken AI Response */}
        {response && (
          <div className="p-4 rounded-2xl bg-[#1E4D33]/40 border border-[#42A85D]/30 mb-4 text-xs text-emerald-100 relative">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[#42A85D] font-bold flex items-center gap-1.5">
                <Volume2 className="w-3.5 h-3.5" /> Icecream Answer:
              </span>
              <button
                onClick={() => speakVoice(response)}
                className="text-[10px] text-slate-300 hover:text-white underline cursor-pointer"
              >
                Replay Audio
              </button>
            </div>
            <p className="leading-relaxed">{response}</p>

            {/* If Auth is required to view personal records */}
            {requiresAuth && !currentUser && (
              <div className="mt-3 pt-2.5 border-t border-white/10">
                <button
                  onClick={() => {
                    if (window.speechSynthesis) window.speechSynthesis.cancel();
                    onClose();
                    if (onOpenRoleLogin) onOpenRoleLogin(authRole);
                  }}
                  className="w-full py-2 px-3 bg-[#42A85D] hover:bg-[#358a4c] text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Sign In as {authRole.charAt(0).toUpperCase() + authRole.slice(1)}</span>
                  <ArrowRight className="w-3.5 h-3.5 ml-1" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* Quick Voice Query Suggestions */}
        <div className="pt-2 border-t border-white/10 relative z-10">
          <div className="text-[11px] text-slate-400 mb-2">Or tap a quick audio query:</div>
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={() => handleVoiceQuery('What is Cassatrix ERP?')}
              className="px-2.5 py-1 rounded-full bg-white/5 hover:bg-white/10 text-[11px] text-slate-300 hover:text-white border border-white/10 transition-colors cursor-pointer"
            >
              🏛️ What is Cassatrix?
            </button>
            <button
              onClick={() => handleVoiceQuery('How does geofenced OTP attendance work?')}
              className="px-2.5 py-1 rounded-full bg-white/5 hover:bg-white/10 text-[11px] text-slate-300 hover:text-white border border-white/10 transition-colors cursor-pointer"
            >
              📍 OTP Attendance
            </button>
            <button
              onClick={() => handleVoiceQuery('Tell me about university bus routes')}
              className="px-2.5 py-1 rounded-full bg-white/5 hover:bg-white/10 text-[11px] text-slate-300 hover:text-white border border-white/10 transition-colors cursor-pointer"
            >
              🚌 Bus Routes
            </button>
            <button
              onClick={() => handleVoiceQuery('What is my attendance?')}
              className="px-2.5 py-1 rounded-full bg-amber-500/20 hover:bg-amber-500/30 text-[11px] text-amber-300 border border-amber-500/30 transition-colors cursor-pointer"
            >
              🔒 My Attendance (Sign-in)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
