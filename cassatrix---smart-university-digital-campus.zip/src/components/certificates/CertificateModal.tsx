import React, { useState, useEffect } from 'react';
import { X, ShieldCheck, Download, Printer, CheckCircle2 } from 'lucide-react';
import { DigitalCertificate } from '../../types';

interface CertificateModalProps {
  certificate: DigitalCertificate | null;
  onClose: () => void;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({ certificate, onClose }) => {
  const [copied, setCopied] = useState(false);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    if (certificate) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [certificate, onClose]);

  if (!certificate) return null;

  const handleCopyHash = () => {
    navigator.clipboard.writeText(certificate.verificationHash);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in cursor-pointer"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-white rounded-3xl max-w-2xl w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[90vh] cursor-default relative">
        {/* Modal Top Controls */}
        <div className="bg-[#12281A] text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#42A85D]" />
            <span className="font-bold text-sm">DigiLocker & National Academic Depository Verified</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="p-1.5 hover:bg-white/10 rounded-lg text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Print Certificate"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 hover:bg-white/20 rounded-lg text-white transition-colors cursor-pointer flex items-center gap-1 text-xs font-semibold"
              title="Close modal (Esc)"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
              <span className="hidden sm:inline">Close</span>
            </button>
          </div>
        </div>

        {/* Certificate Sheet (Printable Canvas) */}
        <div className="p-8 overflow-y-auto flex-1 bg-gradient-to-b from-amber-50/20 via-white to-amber-50/30 border-8 border-slate-100 m-4 rounded-2xl relative">
          {/* Watermark Logo */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5">
            <div className="text-8xl font-black text-slate-900 font-display">CASSATRIX</div>
          </div>

          <div className="text-center space-y-2 mb-6">
            <div className="text-[11px] font-bold tracking-widest uppercase text-[#1E4D33]">
              Cassatrix Smart Campus Infrastructure · National Repository
            </div>
            <h2 className="text-2xl font-bold font-serif-accent text-slate-900 tracking-wide">
              {certificate.title}
            </h2>
            <div className="w-24 h-1 bg-[#1E4D33] mx-auto rounded-full mt-2"></div>
          </div>

          <div className="text-center space-y-4 my-8 text-xs text-slate-700 leading-relaxed max-w-lg mx-auto">
            <p>This is to certify that the digital academic record belonging to</p>
            <div className="text-xl font-extrabold text-slate-900 tracking-tight font-display">
              {certificate.issuedTo}
            </div>
            <p className="font-mono text-xs text-[#1E4D33] font-semibold">
              Enrollment No: {certificate.enrollmentNo}
            </p>
            <p>
              has been cryptographically sealed and anchored into the University Distributed Ledger & DigiLocker with
              institutional authority verification.
            </p>
          </div>

          {/* Signatures & DigiLocker Verification */}
          <div className="mt-8 pt-6 border-t border-dashed border-slate-300 flex items-center justify-between text-xs">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 bg-emerald-50 p-2 rounded-xl border border-emerald-300 shadow-2xs flex items-center justify-center">
                <ShieldCheck className="w-full h-full text-[#1E4D33]" />
              </div>
              <div>
                <div className="font-bold text-[11px] text-slate-900">DigiLocker Verified</div>
                <div className="text-[10px] text-emerald-700 font-semibold">SHA-256 Public Anchor</div>
                <span className="text-[10px] text-slate-400 mt-1 block">Issued: {certificate.issueDate}</span>
              </div>
            </div>

            <div className="text-right space-y-1">
              <div className="w-24 h-8 border-b border-slate-400 ml-auto"></div>
              <div className="font-bold text-[11px] text-slate-900">Dr. Rajeshwar Rao</div>
              <div className="text-[10px] text-slate-500">Registrar & Controller of Examinations</div>
            </div>
          </div>

          {/* Cryptographic Hash Verification footer */}
          <div className="mt-8 pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3 text-[10px]">
            <div className="text-slate-500 font-mono break-all text-left">
              SHA-256: {certificate.verificationHash}
            </div>
            <button
              onClick={handleCopyHash}
              className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-sans font-semibold shrink-0 transition-colors cursor-pointer"
            >
              {copied ? '✓ Copied Hash' : 'Copy Hash'}
            </button>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-500 font-medium">
            Status: <strong className="text-emerald-700">Verified on National Repository</strong>
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            >
              Close
            </button>
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-[#1E4D33] hover:bg-[#2A6647] text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Official PDF</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
