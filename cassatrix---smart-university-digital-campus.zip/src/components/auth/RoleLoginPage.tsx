import React, { useState, useEffect } from 'react';
import { UserRole } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { DEMO_USERS } from '../../data/mockData';
import {
  GraduationCap,
  Briefcase,
  ShieldCheck,
  Users,
  Lock,
  Mail,
  ArrowRight,
  Sparkles,
  Building2,
  KeyRound,
  Check,
  X,
} from 'lucide-react';

interface RoleLoginPageProps {
  initialRole?: UserRole;
  onSuccess: (role?: UserRole) => void;
  onBackToHome: () => void;
}

const ROLE_DETAILS: Record<
  UserRole,
  {
    title: string;
    subtitle: string;
    icon: React.ElementType;
    badgeBg: string;
    accentColor: string;
    portalType: string;
    sampleId: string;
    features: string[];
  }
> = {
  student: {
    title: 'Student Portal Sign In',
    subtitle: 'Access unified academic lifecycle, smart geofenced OTP attendance, fee dues, e-certificates, and AI tutor',
    icon: GraduationCap,
    badgeBg: 'bg-[#1E4D33]',
    accentColor: 'text-[#1E4D33]',
    portalType: 'Scholar Academic ERP',
    sampleId: '0101CS221045 or student@cassatrix.edu',
    features: ['Geofenced 6-Digit OTP Lecture Attendance', 'Digital Tamper-proof Degree Vault', 'Instant Fee Invoicing (UPI/Cards)', 'Out-pass & Bus Seat Booking'],
  },
  faculty: {
    title: 'Faculty & Proctor Sign In',
    subtitle: 'Dynamic 6-digit lecture OTP generator with geofence lock, centralized continuous assessment grading ledger, and early risk intervention',
    icon: Briefcase,
    badgeBg: 'bg-[#1E4D33]',
    accentColor: 'text-[#1E4D33]',
    portalType: 'Academic Instruction & Mentorship',
    sampleId: 'FAC-CS-809 or faculty@cassatrix.edu',
    features: ['Live Lecture 6-Digit OTP Generator', 'Centralized Grading Ledger', 'AI Early Dropout Flags (<75%)', '24-48h SLA Grievance Queue'],
  },
  parent: {
    title: 'Parent & Guardian Sign In',
    subtitle: 'Stay connected with real-time lecture attendance, internal test score cards, direct billing, and official circulars',
    icon: Users,
    badgeBg: 'bg-[#1E4D33]',
    accentColor: 'text-[#1E4D33]',
    portalType: 'Guardian Transparency Dashboard',
    sampleId: 'parent@cassatrix.edu',
    features: ['Ward Attendance Monitor (<75% warning)', 'Direct Fee Settlement & Tax Invoices', 'Semester Internal Test Cards', 'Official Leadership Circulars'],
  },
  admin: {
    title: 'Administrator & Leadership Sign In',
    subtitle: 'Institutional governance analytics, role-based access control (RBAC), batch cryptographic signer, and infrastructure management',
    icon: ShieldCheck,
    badgeBg: 'bg-[#1E4D33]',
    accentColor: 'text-[#1E4D33]',
    portalType: 'Executive Governance & Authority Hub',
    sampleId: 'ADM-GOV-001 or admin@cassatrix.edu',
    features: ['₹42.8 Cr Fee Collection Analytics', 'RBAC Permission Security Matrix', 'Batch SHA-256 DigiLocker Signer', 'Campus Living & Bus Route Dispatch'],
  },
};

export const RoleLoginPage: React.FC<RoleLoginPageProps> = ({
  initialRole = 'student',
  onSuccess,
  onBackToHome,
}) => {
  const { loginRole } = useAuth();
  const [selectedRole, setSelectedRole] = useState<UserRole>(initialRole);
  const [identifier, setIdentifier] = useState(DEMO_USERS[initialRole]?.profile.email || '');
  const [password, setPassword] = useState(DEMO_USERS[initialRole]?.password || '');
  const [error, setError] = useState<string | null>(null);

  // Close modal when pressing Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onBackToHome();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onBackToHome]);

  const roleMeta = ROLE_DETAILS[selectedRole] || ROLE_DETAILS.student;
  const Icon = roleMeta.icon;

  // Ensure selectedRole updates immediately whenever modal is opened with an initialRole
  useEffect(() => {
    if (initialRole && ROLE_DETAILS[initialRole]) {
      setSelectedRole(initialRole);
      setError(null);
      const demo = DEMO_USERS[initialRole];
      if (demo) {
        setIdentifier(demo.profile.email);
        setPassword(demo.password);
      }
    }
  }, [initialRole]);

  const handleRoleSelect = (role: UserRole) => {
    setSelectedRole(role);
    setError(null);
    const demo = DEMO_USERS[role];
    if (demo) {
      setIdentifier(demo.profile.email);
      setPassword(demo.password);
    }
  };

  const handleAutofill = () => {
    const demo = DEMO_USERS[selectedRole];
    if (demo) {
      setIdentifier(demo.profile.email);
      setPassword(demo.password);
      setError(null);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const result = loginRole(selectedRole, identifier, password);
    if (result.success) {
      onSuccess(selectedRole);
    } else {
      setError(result.error || 'Authentication failed');
    }
  };

  return (
    <div className="flex flex-col justify-center py-6 px-4 sm:px-6 lg:px-8 bg-[#FBFAF7] text-[#12281A] relative rounded-3xl shadow-2xl border border-black/10">
      <div className="max-w-4xl mx-auto w-full">
        {/* Top Breadcrumb & Prominent Close Button */}
        <div className="flex items-center justify-between mb-4 bg-white/90 backdrop-blur-sm p-3 rounded-2xl border border-black/10 shadow-2xs">
          <button
            onClick={onBackToHome}
            className="text-xs font-semibold text-[#12281A]/70 hover:text-[#12281A] flex items-center gap-1.5 transition-colors cursor-pointer py-1.5 px-3 rounded-xl hover:bg-slate-100"
          >
            ← Back to Overview
          </button>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-1.5 text-xs text-[#12281A]/60 font-medium">
              <Building2 className="w-3.5 h-3.5 text-[#1E4D33]" />
              <span>Cassatrix Smart Campus Infrastructure</span>
            </div>

            {/* Prominent "✕ Cut / Close" Button */}
            <button
              onClick={onBackToHome}
              className="p-1.5 sm:px-3 sm:py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 hover:text-rose-900 border border-rose-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
              title="Close modal (or press Escape)"
              aria-label="Close modal"
            >
              <X className="w-4 h-4 text-rose-700" />
              <span>Close (Esc)</span>
            </button>
          </div>
        </div>

        {/* Strictly 4 Roles Selector Tabs */}
        <div className="mb-6 bg-white p-2.5 rounded-2xl border border-black/10 shadow-2xs">
          <div className="text-[11px] font-semibold text-[#12281A]/50 px-3 py-1 uppercase tracking-wider">
            Select University Role Portal
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-1">
            {(['student', 'faculty', 'parent', 'admin'] as UserRole[]).map((role) => {
              const info = ROLE_DETAILS[role];
              const RoleIcon = info.icon;
              const isSelected = selectedRole === role;
              return (
                <button
                  key={role}
                  type="button"
                  onClick={() => handleRoleSelect(role)}
                  className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all cursor-pointer ${
                    isSelected
                      ? 'border-[#1E4D33] bg-[#E4EFDA]/50 shadow-xs text-[#12281A]'
                      : 'border-black/10 bg-white hover:bg-slate-50 text-[#12281A]/60 hover:text-[#12281A]'
                  }`}
                >
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center mb-1.5 ${
                      isSelected ? 'bg-[#1E4D33] text-white' : 'bg-[#FBFAF7] text-[#12281A]/70'
                    }`}
                  >
                    <RoleIcon className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-bold capitalize truncate max-w-full">
                    {role === 'admin' ? 'Leadership' : role}
                  </span>
                  <span className="text-[10px] text-[#12281A]/50 font-medium">Portal</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Main Login Card with Split Architecture */}
        <div className="bg-white rounded-3xl border border-black/10 shadow-xl overflow-hidden grid grid-cols-1 md:grid-cols-12 relative">
          {/* Card Close Icon in top corner */}
          <button
            onClick={onBackToHome}
            className="absolute top-4 right-4 z-20 p-2 text-slate-400 hover:text-slate-800 hover:bg-slate-100 rounded-full transition-colors cursor-pointer"
            title="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Left Column: Form */}
          <div className="p-8 md:col-span-7 flex flex-col justify-between space-y-6">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2.5 rounded-xl bg-[#1E4D33] text-white shadow-xs">
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-display font-bold text-xl text-[#12281A]">{roleMeta.title}</h2>
                  <span className="text-xs text-[#42A85D] font-mono font-semibold uppercase tracking-wider">
                    {roleMeta.portalType}
                  </span>
                </div>
              </div>

              <p className="text-xs text-[#12281A]/70 mt-1 mb-6 leading-relaxed">
                {roleMeta.subtitle}
              </p>

              {error && (
                <div className="mb-4 p-3.5 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-start gap-2">
                  <span className="font-bold">•</span>
                  <span>{error}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-[#12281A] mb-1.5">
                    Registered Email or Enrollment ID
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      required
                      value={identifier}
                      onChange={(e) => setIdentifier(e.target.value)}
                      placeholder={roleMeta.sampleId}
                      className="w-full pl-10 pr-3.5 py-2.5 text-xs bg-white border border-black/15 rounded-xl focus:border-[#1E4D33] focus:ring-1 focus:ring-[#1E4D33] outline-none transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#12281A] mb-1.5">
                    Security Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-10 pr-3.5 py-2.5 text-xs bg-white border border-black/15 rounded-xl focus:border-[#1E4D33] focus:ring-1 focus:ring-[#1E4D33] outline-none transition-all font-mono"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs pt-1">
                  <button
                    type="button"
                    onClick={handleAutofill}
                    className="text-xs text-[#1E4D33] hover:underline flex items-center gap-1 font-semibold cursor-pointer"
                  >
                    <KeyRound className="w-3.5 h-3.5" />
                    <span>Auto-Fill Demo Credentials</span>
                  </button>
                  <span className="text-[11px] text-[#12281A]/50 font-mono">
                    Pass: {DEMO_USERS[selectedRole]?.password}
                  </span>
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="submit"
                    className="flex-1 py-3 px-4 bg-[#1E4D33] hover:bg-[#2A6647] active:scale-95 text-white text-xs font-bold rounded-xl transition-all duration-200 flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                  >
                    <span>Authenticate Session</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={onBackToHome}
                    className="py-3 px-4 bg-slate-100 hover:bg-slate-200 text-[#12281A] text-xs font-bold rounded-xl transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Right Column: Key Capabilities Matrix */}
          <div className="p-8 md:col-span-5 bg-[#FBFAF7] border-t md:border-t-0 md:border-l border-black/10 flex flex-col justify-between space-y-6">
            <div>
              <div className="text-xs font-mono text-[#42A85D] uppercase tracking-wider font-bold mb-1">
                Portal Capabilities
              </div>
              <h3 className="font-display font-bold text-base text-[#12281A] mb-4">
                What you can do in this role
              </h3>

              <div className="space-y-3">
                {roleMeta.features.map((feature, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 text-xs text-[#12281A]/80">
                    <Check className="w-4 h-4 text-[#42A85D] shrink-0 mt-0.5" />
                    <span className="leading-snug">{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-black/10 text-[11px] space-y-1">
              <div className="font-bold text-[#12281A] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#42A85D]" />
                <span>Zero-Mock Execution</span>
              </div>
              <p className="text-[#12281A]/60 leading-relaxed">
                All state mutations persist dynamically within the event-driven session state.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
