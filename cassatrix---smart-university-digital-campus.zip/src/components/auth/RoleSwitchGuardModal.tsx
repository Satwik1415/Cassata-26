import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { DEMO_USERS } from '../../data/mockData';
import { UserRole } from '../../types';
import { ShieldAlert, Lock, KeyRound, LogOut, X, CheckCircle2 } from 'lucide-react';

interface RoleSwitchGuardModalProps {
  onSwitchSuccess?: (role: UserRole) => void;
}

export const RoleSwitchGuardModal: React.FC<RoleSwitchGuardModalProps> = ({ onSwitchSuccess }) => {
  const { currentUser, blockedSwitchTarget, setBlockedSwitchTarget, verifyAndSwitchRole, logout } = useAuth();
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  // Close modal on Escape key press
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setBlockedSwitchTarget(null);
      }
    };
    if (blockedSwitchTarget) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [blockedSwitchTarget, setBlockedSwitchTarget]);

  if (!blockedSwitchTarget || !currentUser) return null;

  const targetConfig = DEMO_USERS[blockedSwitchTarget];

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const target = blockedSwitchTarget;
    const res = verifyAndSwitchRole(blockedSwitchTarget, password);
    if (!res.success) {
      setError(res.error || 'Authentication failed');
    } else {
      setPassword('');
      if (onSwitchSuccess) {
        onSwitchSuccess(target);
      }
    }
  };

  const fillDemoPass = () => {
    if (targetConfig) {
      setPassword(targetConfig.password);
      setError(null);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-fade-in cursor-pointer"
      onClick={(e) => {
        if (e.target === e.currentTarget) setBlockedSwitchTarget(null);
      }}
    >
      <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full border border-black/10 overflow-hidden cursor-default">
        {/* Header */}
        <div className="bg-amber-500/10 border-b border-amber-200/80 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500 text-white rounded-xl shadow-xs">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-900 text-base">Role Switch Security Guard</h3>
              <p className="text-xs text-amber-900/80 font-medium">Session Role Immutability Enforced</p>
            </div>
          </div>
          <button
            onClick={() => setBlockedSwitchTarget(null)}
            className="p-1.5 rounded-full hover:bg-amber-100 text-slate-500 hover:text-slate-900 transition-colors cursor-pointer"
            title="Close / Cancel (Esc)"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 text-sm">
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">Current Authenticated Role:</span>
              <span className="font-semibold text-slate-800 capitalize bg-slate-200/80 px-2 py-0.5 rounded">
                {currentUser.roleTitle}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">Target Protected Role:</span>
              <span className="font-semibold text-blue-700 capitalize bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                {targetConfig?.profile.roleTitle}
              </span>
            </div>
          </div>

          <p className="text-slate-600 text-xs leading-relaxed">
            As mandated by university digital security governance, users cannot switch roles without providing the valid credentials of the destination role.
          </p>

          <form onSubmit={handleVerify} className="space-y-3 pt-1">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-medium text-slate-700">
                  Password for {targetConfig?.profile.name} ({targetConfig?.profile.email})
                </label>
                <button
                  type="button"
                  onClick={fillDemoPass}
                  className="text-xs text-blue-600 hover:text-blue-800 underline font-medium cursor-pointer"
                >
                  Autofill Demo Password
                </button>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <KeyRound className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter role security credentials"
                  className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600/30 focus:border-blue-600"
                  autoFocus
                />
              </div>
            </div>

            {error && (
              <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs">
                {error}
              </div>
            )}

            <div className="pt-2 flex flex-col gap-2">
              <button
                type="submit"
                className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-medium text-xs rounded-xl transition-colors flex items-center justify-center gap-2 shadow-xs cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Verify Credentials & Switch Role</span>
              </button>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    logout();
                    setBlockedSwitchTarget(null);
                  }}
                  className="flex-1 py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>

                <button
                  type="button"
                  onClick={() => setBlockedSwitchTarget(null)}
                  className="py-2 px-4 border border-slate-300 hover:bg-slate-50 text-slate-700 font-medium text-xs rounded-xl transition-colors cursor-pointer"
                >
                  Cancel & Close
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
