import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Header } from './components/Header';
import { LandingPage } from './components/LandingPage';
import { RoleLoginPage } from './components/auth/RoleLoginPage';
import { RoleSwitchGuardModal } from './components/auth/RoleSwitchGuardModal';
import { StudentDashboard } from './components/dashboards/StudentDashboard';
import { FacultyDashboard } from './components/dashboards/FacultyDashboard';
import { AdminDashboard } from './components/dashboards/AdminDashboard';
import { ParentDashboard } from './components/dashboards/ParentDashboard';
import { PredictiveAnalyticsView } from './components/ai/PredictiveAnalyticsView';
import { AskIcecreamChatbot } from './components/ai/AskIcecreamChatbot';
import { VoiceAssistantModal } from './components/ai/VoiceAssistantModal';
import { CertificateModal } from './components/certificates/CertificateModal';
import { TechnicalArchitectureView } from './components/docs/TechnicalArchitectureView';
import { UserRole, DigitalCertificate } from './types';
import { Home, LayoutDashboard, Sparkles, Mic, User, Shield } from 'lucide-react';

function AppContent() {
  const { currentUser, currentRole, attemptRoleSwitch } = useAuth();

  // Restore saved activeTab on page refresh or resolve from authenticated user role
  const [activeTab, setActiveTab] = useState<string>(() => {
    try {
      const savedTab = localStorage.getItem('cassata_active_tab');
      if (savedTab && savedTab !== 'landing') return savedTab;
    } catch {
      // ignore
    }

    // Default to authenticated role portal if logged in
    try {
      const savedUserStr = localStorage.getItem('cassata_auth_user_v1');
      if (savedUserStr) {
        const u = JSON.parse(savedUserStr);
        if (u?.role === 'admin') return 'admin_portal';
        if (u?.role === 'faculty') return 'faculty_portal';
        if (u?.role === 'parent') return 'parent_portal';
        if (u?.role === 'student') return 'dashboard';
      }
    } catch {
      // ignore
    }

    return 'landing';
  });

  const [showLoginModal, setShowLoginModal] = useState<boolean>(false);
  const [targetLoginRole, setTargetLoginRole] = useState<UserRole>('student');
  const [showVoiceAssistant, setShowVoiceAssistant] = useState<boolean>(false);
  const [activeCertificate, setActiveCertificate] = useState<DigitalCertificate | null>(null);

  // Save activeTab in localStorage on every tab change
  useEffect(() => {
    try {
      localStorage.setItem('cassata_active_tab', activeTab);
    } catch {
      // ignore
    }
  }, [activeTab]);

  // Global escape key listener to cut/close any open modal immediately
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (showLoginModal) setShowLoginModal(false);
        if (showVoiceAssistant) setShowVoiceAssistant(false);
        if (activeCertificate) setActiveCertificate(null);
      }
    };
    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [showLoginModal, showVoiceAssistant, activeCertificate]);

  // Ensure logged in users are directed to their correct portal view on reload/login
  useEffect(() => {
    if (currentUser) {
      if (activeTab === 'landing' || activeTab === 'overview') {
        if (currentUser.role === 'admin') setActiveTab('admin_portal');
        else if (currentUser.role === 'faculty') setActiveTab('faculty_portal');
        else if (currentUser.role === 'parent') setActiveTab('parent_portal');
        else if (currentUser.role === 'student') setActiveTab('dashboard');
      } else {
        // Correct cross-role tab discrepancies
        if (currentUser.role === 'admin' && (activeTab === 'parent_portal' || activeTab === 'faculty_portal' || activeTab === 'dashboard')) {
          setActiveTab('admin_portal');
        } else if (currentUser.role === 'faculty' && (activeTab === 'parent_portal' || activeTab === 'admin_portal' || activeTab === 'dashboard')) {
          setActiveTab('faculty_portal');
        } else if (currentUser.role === 'parent' && (activeTab === 'admin_portal' || activeTab === 'faculty_portal' || activeTab === 'dashboard')) {
          setActiveTab('parent_portal');
        } else if (currentUser.role === 'student' && (activeTab === 'admin_portal' || activeTab === 'faculty_portal' || activeTab === 'parent_portal')) {
          setActiveTab('dashboard');
        }
      }
    }
  }, [currentUser, activeTab]);

  // When a user selects a role login from the landing page or header
  const handleOpenRoleLogin = (role: UserRole = 'student') => {
    // Check if another role is currently logged in!
    if (currentUser && currentUser.role !== role) {
      const allowed = attemptRoleSwitch(role);
      if (!allowed) {
        // Intercepted by RoleSwitchGuardModal!
        return;
      }
    }
    setTargetLoginRole(role);
    setShowLoginModal(true);
  };

  const handleLoginSuccess = (authenticatedRole?: UserRole) => {
    setShowLoginModal(false);
    const target = authenticatedRole || currentUser?.role || targetLoginRole;
    if (target === 'student') setActiveTab('dashboard');
    else if (target === 'faculty') setActiveTab('faculty_portal');
    else if (target === 'admin') setActiveTab('admin_portal');
    else if (target === 'parent') setActiveTab('parent_portal');
  };

  const handleOpenIcecream = () => {
    const botBtn = document.querySelector('[title="Open Ask Icecream AI Assistant"]') as HTMLElement;
    if (botBtn) botBtn.click();
  };

  const handleExploreModule = (module: string) => {
    if (module === 'predictive_performance' || module === 'early_dropout' || module === 'learning_recs') {
      setActiveTab('ai_analytics');
    } else if (module === 'chat_assistant') {
      handleOpenIcecream();
    } else if (module === 'parent_portal') {
      if (currentUser?.role === 'parent') {
        setActiveTab('parent_portal');
      } else {
        handleOpenRoleLogin('parent');
      }
    } else if (module === 'faculty_portal') {
      if (currentUser?.role === 'faculty') {
        setActiveTab('faculty_portal');
      } else {
        handleOpenRoleLogin('faculty');
      }
    } else if (module === 'admin_portal') {
      if (currentUser?.role === 'admin') {
        setActiveTab('admin_portal');
      } else {
        handleOpenRoleLogin('admin');
      }
    } else {
      // Student ERP module
      if (currentUser?.role === 'student') {
        setActiveTab('dashboard');
      } else {
        handleOpenRoleLogin('student');
      }
    }
  };

  // Get active role tab name for mobile bottom bar
  const getRoleTabForCurrentRole = () => {
    if (!currentUser) return 'landing';
    if (currentUser.role === 'admin') return 'admin_portal';
    if (currentUser.role === 'faculty') return 'faculty_portal';
    if (currentUser.role === 'parent') return 'parent_portal';
    return 'dashboard';
  };

  return (
    <div className="min-h-screen bg-[#FBFAF7] text-[#12281A] flex flex-col selection:bg-[#42A85D] selection:text-white pb-16 lg:pb-0">
      {/* Top Bar with Navigation Contract */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenLogin={handleOpenRoleLogin}
        onOpenVoiceAssistant={() => setShowVoiceAssistant(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {activeTab === 'landing' && (
          <LandingPage
            onOpenRoleLogin={handleOpenRoleLogin}
            onExploreModule={handleExploreModule}
            onOpenVoiceAssistant={() => setShowVoiceAssistant(true)}
            onOpenAskSarthi={handleOpenIcecream}
          />
        )}

        {activeTab === 'dashboard' && (
          currentUser?.role === 'student' ? (
            <StudentDashboard
              onOpenVoiceAssistant={() => setShowVoiceAssistant(true)}
              onOpenAskSarthi={handleOpenIcecream}
              onOpenCertificateModal={(cert) => setActiveCertificate(cert)}
            />
          ) : (
            <div className="max-w-md mx-auto my-16 p-8 bg-white rounded-3xl border border-black/10 shadow-xl text-center space-y-4">
              <div className="w-16 h-16 rounded-3xl bg-[#1E4D33]/10 text-[#1E4D33] flex items-center justify-center mx-auto">
                <Shield className="w-8 h-8" />
              </div>
              <h2 className="text-xl font-bold text-[#12281A]">Student Sign-In Required</h2>
              <p className="text-xs text-slate-600 leading-relaxed">
                Please sign in with your student credentials to view your academic lifecycle, submit 6-digit lecture OTP attendance, and access fee invoices.
              </p>
              <button
                onClick={() => handleOpenRoleLogin('student')}
                className="w-full py-3 bg-[#1E4D33] hover:bg-[#2A6647] text-white font-bold text-xs rounded-xl shadow-md cursor-pointer transition-colors"
              >
                Sign In to Student Portal
              </button>
            </div>
          )
        )}

        {activeTab === 'faculty_portal' && (
          currentUser?.role === 'faculty' ? (
            <FacultyDashboard />
          ) : (
            <div className="max-w-md mx-auto my-16 p-8 bg-white rounded-3xl border border-black/10 shadow-xl text-center space-y-4">
              <div className="w-16 h-16 rounded-3xl bg-[#1E4D33]/10 text-[#1E4D33] flex items-center justify-center mx-auto">
                <Shield className="w-8 h-8" />
              </div>
              <h2 className="text-xl font-bold text-[#12281A]">Faculty Sign-In Required</h2>
              <p className="text-xs text-slate-600 leading-relaxed">
                Please sign in with your faculty credentials to generate lecture OTPs, record grades, and monitor student risk profiles.
              </p>
              <button
                onClick={() => handleOpenRoleLogin('faculty')}
                className="w-full py-3 bg-[#1E4D33] hover:bg-[#2A6647] text-white font-bold text-xs rounded-xl shadow-md cursor-pointer transition-colors"
              >
                Sign In to Faculty Portal
              </button>
            </div>
          )
        )}

        {activeTab === 'admin_portal' && (
          currentUser?.role === 'admin' ? (
            <AdminDashboard />
          ) : (
            <div className="max-w-md mx-auto my-16 p-8 bg-white rounded-3xl border border-black/10 shadow-xl text-center space-y-4">
              <div className="w-16 h-16 rounded-3xl bg-[#1E4D33]/10 text-[#1E4D33] flex items-center justify-center mx-auto">
                <Shield className="w-8 h-8" />
              </div>
              <h2 className="text-xl font-bold text-[#12281A]">Leadership Sign-In Required</h2>
              <p className="text-xs text-slate-600 leading-relaxed">
                Please sign in with administrator credentials to access institutional governance analytics and RBAC security controls.
              </p>
              <button
                onClick={() => handleOpenRoleLogin('admin')}
                className="w-full py-3 bg-[#1E4D33] hover:bg-[#2A6647] text-white font-bold text-xs rounded-xl shadow-md cursor-pointer transition-colors"
              >
                Sign In to Leadership Portal
              </button>
            </div>
          )
        )}

        {activeTab === 'parent_portal' && (
          currentUser?.role === 'parent' ? (
            <ParentDashboard />
          ) : (
            <div className="max-w-md mx-auto my-16 p-8 bg-white rounded-3xl border border-black/10 shadow-xl text-center space-y-4">
              <div className="w-16 h-16 rounded-3xl bg-[#1E4D33]/10 text-[#1E4D33] flex items-center justify-center mx-auto">
                <Shield className="w-8 h-8" />
              </div>
              <h2 className="text-xl font-bold text-[#12281A]">Parent Sign-In Required</h2>
              <p className="text-xs text-slate-600 leading-relaxed">
                Please sign in with guardian credentials to monitor ward attendance, view report cards, and pay semester dues.
              </p>
              <button
                onClick={() => handleOpenRoleLogin('parent')}
                className="w-full py-3 bg-[#1E4D33] hover:bg-[#2A6647] text-white font-bold text-xs rounded-xl shadow-md cursor-pointer transition-colors"
              >
                Sign In to Parent Portal
              </button>
            </div>
          )
        )}

        {activeTab === 'ai_analytics' && <PredictiveAnalyticsView />}
        {activeTab === 'tech_architecture' && <TechnicalArchitectureView />}
      </main>

      {/* Strict Role Switch Interception Guard */}
      <RoleSwitchGuardModal
        onSwitchSuccess={(role) => {
          if (role === 'student') setActiveTab('dashboard');
          else if (role === 'faculty') setActiveTab('faculty_portal');
          else if (role === 'admin') setActiveTab('admin_portal');
          else if (role === 'parent') setActiveTab('parent_portal');
        }}
      />

      {/* Dedicated Role Login Modal / Page with multiple intuitive close options */}
      {showLoginModal && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 cursor-pointer"
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowLoginModal(false);
          }}
        >
          {/* Always Visible Fixed Floating Cut / Close Button */}
          <button
            onClick={() => setShowLoginModal(false)}
            className="fixed top-4 right-4 z-[70] px-4 py-2 rounded-full bg-white hover:bg-rose-50 text-slate-900 hover:text-rose-700 text-xs font-bold transition-all shadow-2xl flex items-center gap-2 cursor-pointer border border-black/15 hover:scale-105 active:scale-95"
            title="Cut / Close Modal (Esc)"
            aria-label="Close Modal"
          >
            <span className="w-5 h-5 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center text-xs font-black">✕</span>
            <span>Close (Esc)</span>
          </button>

          <div className="relative w-full max-w-4xl cursor-default my-auto">
            <RoleLoginPage
              initialRole={targetLoginRole}
              onSuccess={handleLoginSuccess}
              onBackToHome={() => setShowLoginModal(false)}
            />
          </div>
        </div>
      )}

      {/* Voice Assistant Modal */}
      <VoiceAssistantModal
        isOpen={showVoiceAssistant}
        onClose={() => setShowVoiceAssistant(false)}
        onOpenRoleLogin={handleOpenRoleLogin}
      />

      {/* Verifiable Certificate Modal */}
      <CertificateModal
        certificate={activeCertificate}
        onClose={() => setActiveCertificate(null)}
      />

      {/* Floating Ask Icecream AI Assistant with Auth Gating */}
      <AskIcecreamChatbot onOpenRoleLogin={handleOpenRoleLogin} />

      {/* ========================================================================= */}
      {/* NATIVE-FEEL MOBILE BOTTOM NAVIGATION DOCK (VISIBLE ON MOBILE ONLY) */}
      {/* ========================================================================= */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-black/10 py-1.5 px-3 flex items-center justify-around shadow-2xl safe-area-bottom">
        <button
          onClick={() => setActiveTab('landing')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer ${
            activeTab === 'landing' ? 'text-[#1E4D33] font-bold' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Home className="w-4 h-4" />
          <span className="text-[10px] mt-0.5">Overview</span>
        </button>

        <button
          onClick={() => {
            const roleTab = getRoleTabForCurrentRole();
            if (currentUser) {
              setActiveTab(roleTab);
            } else {
              handleOpenRoleLogin('student');
            }
          }}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer ${
            activeTab === 'dashboard' || activeTab === 'faculty_portal' || activeTab === 'parent_portal' || activeTab === 'admin_portal'
              ? 'text-[#1E4D33] font-bold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span className="text-[10px] mt-0.5">
            {currentUser ? currentUser.roleTitle.split(' ')[0] : 'Portal'}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('ai_analytics')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer ${
            activeTab === 'ai_analytics' ? 'text-[#1E4D33] font-bold' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4 text-[#42A85D]" />
          <span className="text-[10px] mt-0.5">AI Risk</span>
        </button>

        <button
          onClick={() => setShowVoiceAssistant(true)}
          className="flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all text-slate-500 hover:text-slate-800 cursor-pointer"
        >
          <Mic className="w-4 h-4 text-[#1E4D33]" />
          <span className="text-[10px] mt-0.5">Voice</span>
        </button>

        <button
          onClick={() => handleOpenRoleLogin(currentUser?.role || 'student')}
          className="flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all text-slate-500 hover:text-slate-800 cursor-pointer"
        >
          {currentUser ? <Shield className="w-4 h-4 text-[#1E4D33]" /> : <User className="w-4 h-4" />}
          <span className="text-[10px] mt-0.5">{currentUser ? 'Switch' : 'Sign In'}</span>
        </button>
      </nav>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
