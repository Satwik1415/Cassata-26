import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, UserRole } from '../types';
import { DEMO_USERS } from '../data/mockData';

interface AuthContextType {
  currentUser: UserProfile | null;
  currentRole: UserRole | null;
  isAuthenticated: boolean;
  loginRole: (role: UserRole, emailOrId: string, pass: string) => { success: boolean; error?: string };
  logout: () => void;
  // Role Guarding:
  attemptRoleSwitch: (targetRole: UserRole) => boolean; // Returns true if allowed, false if blocked
  blockedSwitchTarget: UserRole | null;
  setBlockedSwitchTarget: (role: UserRole | null) => void;
  verifyAndSwitchRole: (targetRole: UserRole, pass: string) => { success: boolean; error?: string };
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const AUTH_STORAGE_KEY = 'cassata_auth_user_v1';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem(AUTH_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    // Unauthenticated by default until user signs into their role portal
    return null;
  });

  const [blockedSwitchTarget, setBlockedSwitchTarget] = useState<UserRole | null>(null);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(AUTH_STORAGE_KEY);
    }
  }, [currentUser]);

  const loginRole = (role: UserRole, emailOrId: string, pass: string) => {
    const roleConfig = DEMO_USERS[role];
    if (!roleConfig) {
      return { success: false, error: 'Unknown university role' };
    }

    const cleanInput = emailOrId.trim().toLowerCase();
    const expectedEmail = roleConfig.profile.email.toLowerCase();
    const expectedEnroll = roleConfig.profile.enrollmentId?.toLowerCase() || '';

    const matchesId = cleanInput === expectedEmail || cleanInput === expectedEnroll;

    if (!matchesId) {
      return {
        success: false,
        error: `Invalid credentials for ${roleConfig.profile.roleTitle}. Please enter registered email or ID (${roleConfig.profile.email}).`,
      };
    }

    if (pass !== roleConfig.password) {
      return {
        success: false,
        error: 'Incorrect security password. (Demo password: ' + roleConfig.password + ')',
      };
    }

    // Role authorized & locked!
    setCurrentUser(roleConfig.profile);
    setBlockedSwitchTarget(null);
    return { success: true };
  };

  const logout = () => {
    setCurrentUser(null);
    setBlockedSwitchTarget(null);
  };

  // Guard: If already logged in as role A, cannot switch to role B without credentials
  const attemptRoleSwitch = (targetRole: UserRole): boolean => {
    if (!currentUser) {
      // Not logged in; can go straight to that role's login page
      return true;
    }

    if (currentUser.role === targetRole) {
      // Already this role
      return true;
    }

    // Attempting to switch without changing credentials: BLOCK IT!
    setBlockedSwitchTarget(targetRole);
    return false;
  };

  const verifyAndSwitchRole = (targetRole: UserRole, pass: string) => {
    const roleConfig = DEMO_USERS[targetRole];
    if (!roleConfig) {
      return { success: false, error: 'Role not found' };
    }

    if (pass !== roleConfig.password) {
      return {
        success: false,
        error: `Verification failed. Incorrect password for ${roleConfig.profile.roleTitle}. (Hint: ${roleConfig.password})`,
      };
    }

    // Authorized switch!
    setCurrentUser(roleConfig.profile);
    setBlockedSwitchTarget(null);
    return { success: true };
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        currentRole: currentUser?.role || null,
        isAuthenticated: !!currentUser,
        loginRole,
        logout,
        attemptRoleSwitch,
        blockedSwitchTarget,
        setBlockedSwitchTarget,
        verifyAndSwitchRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
